# -*- coding: utf-8 -*-
"""
Created on Sat Aug 17 21:24:08 2019

@author: Zhenlin
"""

print('hello')