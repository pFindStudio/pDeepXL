# -*- coding: utf-8 -*-
"""
Created on Thu Jun 27 08:37:18 2019

@author: Zhenlin
"""

def load_pfind3(pfind3_path, FDR, MODS):
    mpPSM = {}
    
    fin=open(pfind3_path)
    lines=fin.readlines()
    fin.close()
    
    for i in range(1,len(lines)):
        contents=lines[i].split('\t')
        title=contents[0].strip()
        scan=int(contents[1])
        exp_mh=float(contents[2])
        charge=int(contents[3])
        qvalue=float(contents[4])
        
        if qvalue > FDR:
            break
        
        seq=contents[5].strip()
        ms=contents[10].strip().split(';')
        mods2={}
        invalid=False
        for m in ms:
            if m=='':
                continue
            pos,name=m.split(',')
            pos=int(pos)-1 # 转换，修饰的下标从0开始
            name=name.strip()
            mods2[pos]=name
            if name.strip() not in MODS:
                invalid=True
                break
        if invalid:
            continue
        
        mpPSM[title]=[scan,exp_mh,charge,seq,mods2]
        
    return mpPSM
    
if __name__ == '__main__':
    pfind3_path = r'E:\DataAnalysis\DeepLearning\pDeepPeak\dataset\01748a_BF4-TUM_second_pool_64_01_01-3xHCD-1h-R1\output\pFindTask1\result\pFind-Filtered.spectra'
    FDR=0.001
    MODS=set(['Carbamidomethyl[C]','Oxidation[M]'])
    
    mpPSM=load_pfind3(pfind3_path, FDR, MODS)