# -*- coding: utf-8 -*-
"""
Created on Thu Jun 27 08:22:48 2019

@author: Zhenlin
"""

import load_pf2
import load_pfind3
import math
import pickle
import copy
import numpy as np

pf2_path = r'E:\DataAnalysis\DeepLearning\pDeepPeak\dataset\01748a_BF4-TUM_second_pool_64_01_01-3xHCD-1h-R1\data\01748a_BF4-TUM_second_pool_64_01_01-3xHCD-1h-R1_HCDFT.pf2'
pfind3_path = r'E:\DataAnalysis\DeepLearning\pDeepPeak\dataset\01748a_BF4-TUM_second_pool_64_01_01-3xHCD-1h-R1\output\pFindTask1\result\pFind-Filtered.spectra'
dataset_path = r'E:\DataAnalysis\DeepLearning\pDeepPeak\dataset\01748a_BF4-TUM_second_pool_64_01_01-3xHCD-1h-R1\data\01748a_BF4-TUM_second_pool_64_01_01-3xHCD-1h-R1.pDeepXL.bin'

FDR=0.001
MODS=set(['Carbamidomethyl[C]','Oxidation[M]'])
bin_size=0.1 # mz
min_mz=100.0
max_mz=2000.0
N=int((max_mz-min_mz)/bin_size)
max_neu_mass=10000.0

# 修饰元素组成：{'H':3,'C':2,'N':1,'O':1,'S':0,'P':0,'M':0,'T':0}
E=8 #修饰的元素组成分为8类，同pDeep2
mpModInfo={'Carbamidomethyl[C]':[57.021464,0.0,[3,2,1,1,0,0,0,0]],
           'Oxidation[M]':[15.994915,63.998285,[0,0,0,1,0,0,0,0]]} # 添加的修饰名称及质量

mpMassTable={'A':71.037114,'R':156.101111,'N':114.042927,'D':115.026943,'C':103.009185, \
'E':129.042593,'Q':128.058578,'G':57.021464,'H':137.058912,'I':113.084064, \
'L':113.084064,'K':128.094963,'M':131.040485,'F':147.068414,'P':97.052764, \
'S':87.032028,'T':101.047679,'W':186.079313,'Y':163.06332,'V':99.068414, \
'H2O':18.01056,'Proton':1.0072766,'CO':27.99491,'NH3':17.02655}

mpAA2id={}
M=0 # 有效的氨基酸数目20
for aa in sorted(list(mpMassTable.keys())):
    if len(aa) == 1:
        mpAA2id[aa]=M
        M+=1


# 确保exp_mz在[min_mz, max_mz]
def get_bin_id(exp_mz):
    return math.floor((exp_mz-min_mz)/bin_size)

def is_valid_peak(exp_mz):
    return exp_mz>=min_mz and exp_mz<=max_mz

#返回某一位置的特征编码向量
def get_pos_embedding(seq, pos):
    
    return



# 谱峰的mz已按从小到大排序
# 数据格式 mpSpec[specname]=[spec_info,peaks]
pf2title, mpSpec = load_pf2.load_pf2(pf2_path)

print(pf2title)

# 数据格式 mpPSM[title]=[scan,exp_mh,charge,seq,mods2]
# mods2格式{pos:name}，pos下标从0开始
mpPSM=load_pfind3.load_pfind3(pfind3_path, FDR, MODS)

title_vec=[]
seq_vec=[]
spec_vec=[]

for i, (title, psm) in enumerate(mpPSM.items()):
    print('%d/%d'%(i,len(mpPSM)))
    title_vec.append(title)
    
    # -------- 生成谱图向量 -------------
    peaks_vec=[0]*N
    spec_info,peaks=mpSpec[title]
    specname, prec_charge, prec_mz,max_peak_inten=spec_info
    
    for exp_mz, inten in peaks:
        if not is_valid_peak(exp_mz):
            continue
        bid=get_bin_id(exp_mz)
        peaks_vec[bid] += inten

    peaks_vec = [inten / max_peak_inten for inten in peaks_vec]
    spec_vec.append(peaks_vec)
    # -------- 生成谱图向量 -------------

    # -------- 生成输入序列矩阵 -------------
    scan,exp_mh,charge,seq,mods = psm
    l=len(seq)
    
    left_aa_mass=[0.0]
    left_aa_count=[np.zeros(M,dtype=int)]
    left_mod_mass=[0.0]
    left_mod_mass_loss=[0.0]
    left_mod_ele_count=[np.zeros(E,dtype=int)]
    for j in range(1,l):
        left_aa_mass.append(left_aa_mass[-1]+mpMassTable[seq[j-1]])
        cur=np.zeros(M)
        cur[mpAA2id[seq[j-1]]]=1
        left_aa_count.append(left_aa_count[-1]+cur)
        
        if j-1 in mods:
            curm=mods[j-1]
            mm,mmloss,mvec=mpModInfo[curm]
            left_mod_mass.append(left_mod_mass[-1]+mm)
            left_mod_mass_loss.append(left_mod_mass_loss[-1]+mmloss)
            left_mod_ele_count.append(left_mod_ele_count[-1]+np.array(mvec))
        else:
            left_mod_mass.append(left_mod_mass[-1])
            left_mod_mass_loss.append(left_mod_mass_loss[-1])
            left_mod_ele_count.append(copy.deepcopy(left_mod_ele_count[-1]))
        
    
    right_aa_mass=[0.0]
    right_aa_count=[np.zeros(M,dtype=int)]
    right_mod_mass=[0.0]
    right_mod_mass_loss=[0.0]
    right_mod_ele_count=[np.zeros(E,dtype=int)]
    for j in range(l-2,-1,-1):
        right_aa_mass.append(right_aa_mass[-1]+mpMassTable[seq[j+1]])
        cur=np.zeros(M)
        cur[mpAA2id[seq[j+1]]]=1
        right_aa_count.append(right_aa_count[-1]+cur)
        
        if j+1 in mods:
            curm=mods[j+1]
            mm,mmloss,mvec=mpModInfo[curm]
            right_mod_mass.append(right_mod_mass[-1]+mm)
            right_mod_mass_loss.append(right_mod_mass_loss[-1]+mmloss)
            right_mod_ele_count.append(right_mod_ele_count[-1]+np.array(mvec))
        else:
            right_mod_mass.append(right_mod_mass[-1])
            right_mod_mass_loss.append(right_mod_mass_loss[-1])
            right_mod_ele_count.append(copy.deepcopy(right_mod_ele_count[-1]))
    
#    left_aa_count=np.array(left_aa_count,dtype=int)
#    right_aa_count=np.array(right_aa_count,dtype=int)
    
    
    aa_matrix=[]
    for j,aa in enumerate(seq):
        aa_one_hot=np.zeros(M)
        aa_one_hot[mpAA2id[aa]]=1
        aa_mass=mpMassTable[aa]/max_neu_mass
        mod_ele_one_hot=np.zeros(E)
        mod_mass=0.0
        mod_mass_loss=0.0
        if j in mods:
            mm,mmloss,mvec=mpModInfo[mods[j]]
            mod_ele_one_hot=np.array(mvec)
            mod_mass=mm/max_neu_mass
            mod_mass_loss=mmloss/max_neu_mass
        
        
        leftaa_one_hot=np.zeros(M)
        leftaa_mass=0
        leftmod_ele_one_hot=np.zeros(E)
        leftmod_mass=0.0
        leftmod_mass_loss=0.0
        if j>0:
            leftaa=seq[j-1]
            leftaa_one_hot[mpAA2id[leftaa]]=1
            leftaa_mass=mpMassTable[leftaa]/max_neu_mass
            if j-1 in mods:
                mm,mmloss,mvec=mpModInfo[mods[j-1]]
                leftmod_ele_one_hot=np.array(mvec)
                leftmod_mass=mm/max_neu_mass
                leftmod_mass_loss=mmloss/max_neu_mass
        
        rightaa_one_hot=np.zeros(M)
        rightaa_mass=0
        rightmod_ele_one_hot=np.zeros(E)
        rightmod_mass=0.0
        rightmod_mass_loss=0.0
        if j+1<l:
            rightaa=seq[j+1]
            rightaa_one_hot[mpAA2id[rightaa]]=1
            rightaa_mass=mpMassTable[rightaa]/max_neu_mass
            if j+1 in mods:
                mm,mmloss,mvec=mpModInfo[mods[j+1]]
                rightmod_ele_one_hot=np.array(mvec)
                rightmod_mass=mm/max_neu_mass
                rightmod_mass_loss=mmloss/max_neu_mass
    
        leftsumaa_one_hot=copy.deepcopy(left_aa_count[j])
        leftsumaa_mass=left_aa_mass[j]/max_neu_mass
        leftsummod_ele_one_hot=copy.deepcopy(left_mod_ele_count[j])
        leftsummod_mass=left_mod_mass[j]/max_neu_mass
        leftsummod_mass_loss=left_mod_mass_loss[j]/max_neu_mass
        
        ridx=l-j-1
        rightsumaa_one_hot=copy.deepcopy(right_aa_count[ridx])
        rightsumaa_mass=right_aa_mass[ridx]/max_neu_mass
        rightsummod_ele_one_hot=copy.deepcopy(right_mod_ele_count[ridx])
        rightsummod_mass=right_mod_mass[ridx]/max_neu_mass
        rightsummod_mass_loss=right_mod_mass_loss[ridx]/max_neu_mass
        
        cur_aa_vec=[]
        # cur aa
        cur_aa_vec=cur_aa_vec+aa_one_hot.tolist()
        cur_aa_vec.append(aa_mass)
        cur_aa_vec=cur_aa_vec+mod_ele_one_hot.tolist()
        cur_aa_vec.append(mod_mass)
        cur_aa_vec.append(mod_mass_loss)
        
        # left aa
        cur_aa_vec=cur_aa_vec+leftaa_one_hot.tolist()
        cur_aa_vec.append(leftaa_mass)
        cur_aa_vec=cur_aa_vec+leftmod_ele_one_hot.tolist()
        cur_aa_vec.append(leftmod_mass)
        cur_aa_vec.append(leftmod_mass_loss)
        
        # right aa
        cur_aa_vec=cur_aa_vec+rightaa_one_hot.tolist()
        cur_aa_vec.append(rightaa_mass)
        cur_aa_vec=cur_aa_vec+rightmod_ele_one_hot.tolist()
        cur_aa_vec.append(rightmod_mass)
        cur_aa_vec.append(rightmod_mass_loss)
        
        # left sum aa
        cur_aa_vec=cur_aa_vec+leftsumaa_one_hot.tolist()
        cur_aa_vec.append(leftsumaa_mass)
        cur_aa_vec=cur_aa_vec+leftsummod_ele_one_hot.tolist()
        cur_aa_vec.append(leftsummod_mass)
        cur_aa_vec.append(leftsummod_mass_loss)
        
        # right sum aa
        cur_aa_vec=cur_aa_vec+rightsumaa_one_hot.tolist()
        cur_aa_vec.append(rightsumaa_mass)
        cur_aa_vec=cur_aa_vec+rightsummod_ele_one_hot.tolist()
        cur_aa_vec.append(rightsummod_mass)
        cur_aa_vec.append(rightsummod_mass_loss)
        
        ncterm=0 # 0 for mid, 1 for N-term, 2 for C-term
        if j==0:
            ncterm=1
        elif j==l-1:
            ncterm=2
        pre_neu_mass=(exp_mh-mpMassTable['Proton'])/max_neu_mass
        
        # other info
        cur_aa_vec.append(ncterm)
        cur_aa_vec.append(pre_neu_mass)
        cur_aa_vec.append(charge)
        cur_aa_vec.append(mpMassTable['Proton']/max_neu_mass)
        cur_aa_vec.append(mpMassTable['H2O']/max_neu_mass)
        cur_aa_vec.append(mpMassTable['NH3']/max_neu_mass)
        cur_aa_vec.append(mpMassTable['CO']/max_neu_mass)
        
        aa_matrix.append(cur_aa_vec)
    
    seq_vec.append(aa_matrix)
    # -------- 生成输入序列矩阵 -------------
    if i==99:
        break

dataset=[title_vec,seq_vec,spec_vec]
with open(dataset_path, 'wb') as fp:
    pickle.dump(dataset, fp)
