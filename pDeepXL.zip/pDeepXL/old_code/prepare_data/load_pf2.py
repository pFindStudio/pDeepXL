# -*- coding: utf-8 -*-
"""
Created on Thu May 30 10:56:26 2019

@author: Zhenlin
"""

import os
import struct

def load_pf2(pf2_path):

    f = open(pf2_path, "rb")
    
    spec_title = os.path.basename(pf2_path)[:-10]
    
    nSpec,lenTitle = struct.unpack("2i", f.read(8))
    
    pf2title = struct.unpack("%ds" %lenTitle, f.read(lenTitle))
    
    #print(pf2title)
    
    mpSpec = {}
    
    for __i__ in range(nSpec):
        scan_no, = struct.unpack("i",f.read(4))
    #    print(">>Spectrum NO = %d" %scan_no)
        nPeak, = struct.unpack("i", f.read(4))
        peaks = []
        mz_int = struct.unpack(str(nPeak*2)+"d", f.read(nPeak*2*8))
        for i in range(nPeak):
            mz = mz_int[i*2]
            inten = mz_int[i*2 + 1]
            peaks.append( (mz, inten) )
        
        peaks=sorted(peaks,key=lambda x:x[0]) # 按mz从小到大排序，也许pf2默认已经排过序了。
        max_inten=max(peaks,key=lambda x:x[1])[1]
        
        nMix, = struct.unpack("i", f.read(4))
        nMaxCharge = 0
        for i in range(nMix):
            precursor, = struct.unpack("d", f.read(8))
            nCharge, = struct.unpack("i", f.read(4))
            if nCharge > nMaxCharge: nMaxCharge = nCharge
            specname = "%s.%d.%d.%d.%d.dta" %(spec_title, scan_no, scan_no, nCharge, i)
            spec_info=(specname, nCharge, precursor,max_inten)
            mpSpec[specname]=[spec_info,peaks]
    f.close()
    
    return pf2title, mpSpec

if __name__ == '__main__':
    pf2_path=r'E:\TestData\raw\RD_pH_8point3_step1_HCDFT.pf2'
    pf2title, mpSpec = load_pf2(pf2_path)