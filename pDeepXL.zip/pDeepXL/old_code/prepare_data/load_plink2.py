# -*- coding: utf-8 -*-
"""
Created on Thu Jun 27 08:37:18 2019

@author: Zhenlin
"""

def load_plink2(plink2_path, FDR, MODS):
    mpPSM = {}
    
    fin=open(plink2_path)
    lines=fin.readlines()
    fin.close()
    
    for i in range(1,len(lines)):
        contents=lines[i].split(',')
        title=contents[1].strip()
        charge=int(contents[2])
        exp_mh=float(contents[3])
        pep_type=int(contents[4])
        pep_pair=contents[5].strip()
        mods_str=contents[7].strip()
        td=int(contents[14])
        qvalue=float(contents[15])
        iscomplex=int(contents[19])
        isfilterin=int(contents[20])
        
        if pep_type!=3 or td!=2 or iscomplex!=1 or isfilterin!=1:
            continue
        
        if qvalue>FDR:
            break
        
        ms=mods_str.split(';')
        invalid=False
        for m in ms:
            if m=='null':
                continue
            name,pos=m.split('(')
            pos=int(pos[:-1])
            name=name.strip()
            if name not in MODS:
                invalid=True
                break
        if invalid:
            continue
        
        mpPSM[title]=[title,exp_mh,pep_pair,charge,mods_str]
        
    return mpPSM
    
if __name__ == '__main__':
    plink2_path = r'\\10.29.0.9\zlchen\SUMO\2019mid_evaluation\PXD008003\pLink2\QE4_LC12_IAH_SUMO_R3_HEK-M_AspN_E1\reports\HUMAN_2019.07.04.csv'
    FDR=0.001
#    MODS=set(['Carbamidomethyl[C]','Oxidation[M]','Acetyl[ProteinN-term]','Phospho[S]','Phospho[T]','Phospho[Y]'])
    MODS=set(['Carbamidomethyl[C]','Oxidation[M]'])
    
    mpPSM=load_plink2(plink2_path, FDR, MODS)