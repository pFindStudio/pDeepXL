# -*- coding: utf-8 -*-
"""
Created on Sat Aug 17 21:39:50 2019

@author: Zhenlin
"""

# 读取Fasta中的蛋白列表
def load_fasta(strPath):
    fin=open(strPath)
    lines=fin.readlines()
    fin.close()
    
    names=[]
    seqs=[]
    i=0
    n=len(lines)
    while i < n:
        while i <n and lines[i][0] != '>':
            i+=1
        if i>=n:
            break
        
        names.append(lines[i].strip())
        
        curseq=''
        j=i+1
        while j<n and lines[j][0] != '>':
            curseq+=lines[j].strip()
            j+=1
        
        curseq=''.join([a for a in curseq if a.isupper()])
        seqs.append(curseq)        
        i=j
    return names, seqs

if __name__ == '__main__':
    strPath=r'\\10.29.0.9\Datasets\chenzhenlin_Cross-Linked_Peptides_DataSets\PXD008003\HUMAN.fasta'
    names, seqs = load_fasta(strPath)