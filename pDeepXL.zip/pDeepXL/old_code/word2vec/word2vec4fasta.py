# -*- coding: utf-8 -*-
"""
Created on Sat Aug 17 21:55:36 2019

@author: Zhenlin
"""

from gensim.models import Word2Vec
from load_fasta import load_fasta
import numpy as np
import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt

fasta_path=r'\\10.29.0.9\Datasets\chenzhenlin_Cross-Linked_Peptides_DataSets\PXD008003\HUMAN.fasta'
names, seqs = load_fasta(fasta_path)

pro_seqs=[]

for seq in seqs:
    pro_seqs.append([a for a in seq])


model = Word2Vec(pro_seqs, window=5, min_count=1, size=100, workers=6)

# model.wv.vocab # 字母表
# model.wv.index2word # 词向量矩阵和单词的对应关系

model.init_sims() # must be call to generate `model.wv.vectors_norm`
matrix = np.dot(model.wv.vectors_norm, model.wv.vectors_norm.T)

df=pd.DataFrame(matrix,columns=model.wv.index2word,index=model.wv.index2word)

sns.set_context("notebook", font_scale=5, rc={"lines.linewidth": 5})
with sns.axes_style("white"):
    f=plt.figure(figsize=(50,50))
    ax = sns.heatmap(df, robust=True, square=True,  cmap="YlGnBu")
    plt.show()
    f.savefig(r'E:\DataAnalysis\DeepLearning\pDeepXL\code\pDeepXL\word2vec\similarity_full.png')
    
mask = np.zeros_like(df)
mask[np.triu_indices_from(mask, k=1)] = True
with sns.axes_style("white"):
    f=plt.figure(figsize=(50,50))
    ax = sns.heatmap(df, mask=mask,robust=True, square=True,  cmap="YlGnBu")
    plt.show()
    f.savefig(r'E:\DataAnalysis\DeepLearning\pDeepXL\code\pDeepXL\word2vec\similarity_half.png')
    