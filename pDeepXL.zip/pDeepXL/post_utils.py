
# 获取每个数据集中包含的raw的标题

import os
import numpy as np
import sys
sys.path.append("..")
import utils


def sub_get_data_raw_mp(data_name, path_data):
    mpData2Raw,mpRaw2Data={},{}
    path_pf2_folder=r'%s/pf2'%path_data
    files=os.listdir(path_pf2_folder)
    for f in files:
        fname, fext = os.path.splitext(f)
        if fext=='.pf2':
            rawname=fname[:-6]
            mpRaw2Data[rawname]=data_name
            if data_name not in mpData2Raw:
                mpData2Raw[data_name]=[]
            mpData2Raw[data_name].append(rawname)
    return mpData2Raw,mpRaw2Data


def get_data_raw_mp():
    # 不包含ecoli-leiker，因为这个数据集的raw有重名的。。。
    path_data_homes=[r'/data/zlchen/pDeepXL/data/PXD017620',
                    r'/data/zlchen/pDeepXL/data/PXD016554/DSS/B_subtilis',
                    r'/data/zlchen/pDeepXL/data/PXD016554/DSS/B_cereus',
                    r'/data/zlchen/pDeepXL/data/PXD019926/DSS/HEK293',
                    r'/data/zlchen/pDeepXL/data/PXD017695',
                    r'/data/zlchen/pDeepXL/data/PXD014675',
                    r'/data/zlchen/pDeepXL/data/lili',
                    r'/data/zlchen/pDeepXL/data/PXD019926/DSSO/HEK293',
                    r'/data/zlchen/pDeepXL/data/PXD017711',
                    r'/data/zlchen/pDeepXL/data/PXD012546',
                    r'/data/zlchen/pDeepXL/data/PXD001468',
                    r'/data/zlchen/pDeepXL/data/PXD001250',
                    r'/data/zlchen/pDeepXL/data/PXD014877',
                    r'/data/zlchen/pDeepXL/data/PXD004732/3xHCD',
                    r'/data/zlchen/pDeepXL/data/PXD009384/MEL',
                    r'/data/zlchen/pDeepXL/data/PXD008252']
    data_names=['Yeast-Urlaub-Linear',
                'B.subtilis-Urlaub-Linear',
                'B.cereus-Urlaub-Linear',
                'HEK293T-Liu-Linear1',
                'M.pneumoniae-Rappsilber-Linear1',
                'K562-Rappsilber-Linear1',
                'E.coli-Zhang-Linear',
                'HEK293T-Liu-Linear2',
                'M.pneumoniae-Rappsilber-Linear2',
                'D.melanogaster-Sinz-Linear',
                'HEK293T-Gygi-Linear',
                'Mouse-Mann-Linear',
                'Arabidopsis-Mann-Linear',
                'Synthesis-Kuster-Linear',
                'Mouse-Mayeux-Linear',
                'Human-Cantoni-Linear']

    mpData2Raw,mpRaw2Data={},{}

    for data_name, path_data in zip(data_names, path_data_homes):
        sub_mpData2Raw,sub_mpRaw2Data=sub_get_data_raw_mp(data_name, path_data)
        mpData2Raw = {**mpData2Raw, **sub_mpData2Raw}
        mpRaw2Data = {**mpRaw2Data, **sub_mpRaw2Data}
    
    return mpData2Raw,mpRaw2Data



# mpData2Raw,mpRaw2Data=get_raw_list()
# print(len(mpData2Raw))
# print(len(mpRaw2Data))





def get_data_pcc(path_test_ans):

    mpData2Raw,mpRaw2Data=get_data_raw_mp()
    print('num_data=%d,num_raw=%d'%(len(mpData2Raw),len(mpRaw2Data)))

    fin=open(path_test_ans)
    lines=fin.readlines()
    fin.close()

    mpData2PCCs={}

    for line in lines:
        title,pcc=line.strip().split(',')
        pcc=float(pcc)
        rawname=title.split('.')[0]
        if rawname not in mpRaw2Data:
            dataname='NotFound'
        else:
            dataname=mpRaw2Data[rawname]
        if dataname not in mpData2PCCs:
            mpData2PCCs[dataname]=[]
        mpData2PCCs[dataname].append(pcc)

    for dataname,pccs in mpData2PCCs.items():
        print('dataname=%s,num=%d'%(dataname,len(pccs)))

    return mpData2PCCs




def cal_metrics(in_sims):
    sims_nan = np.array(in_sims)
    sims = sims_nan[np.isnan(sims_nan) == False]
    med = np.median(sims)
    avg = np.mean(sims)
    std = np.std(sims)

    wanted_pccs=sorted([0.75,0.90])
    ppcc75,ppcc90=0,0
    pccs, percentages=[],[]
    if len(sims) > 0:
        pccs, percentages = utils.CountAccuPercentage(sims)
        ppcc75,ppcc90=utils.BatchBSWantedPccs(pccs, percentages, wanted_pccs)
    
    return sims, med, avg, std,ppcc75,ppcc90,pccs,percentages



def read_test_ans(path_test_ans):

    fin=open(path_test_ans)
    lines=fin.readlines()
    fin.close()

    ans=[]

    for line in lines:
        title,pcc=line.strip().split(',')
        pcc=float(pcc)
        ans.append([title,pcc])
    
    return ans