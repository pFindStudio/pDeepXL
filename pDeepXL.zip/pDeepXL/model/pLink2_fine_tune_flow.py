# pLink2 测试全流程外壳

import os
import time

#############################################################################################
# 1. 不可碎裂数据集fine tune

path_pretrained=r'/data/zlchen/pDeepXL/code/pDeepXL/pt/XL-non-clv-1123-163938-transfer30/epoch56-valloss0.0097-valmedianpcc0.9669.pt'

path_data_home=r'/data/zlchen/pDeepXL/data/PXD008550/HumanFOMix_BS3/pLink2_data/fine-tune4'
data_name='K562'

# path_data_home=r'/data/zlchen/pDeepXL/data/Leiker_elife/6.C.elegans_lysates/N2/pLink2_data/fine-tune'
# data_name='worm'

# train_nums=[10,50,100,150,200,250,300,500]
# train_nums=[350,400,450]
# train_nums=[i*0.01 for i in range(5,80,10)]
train_nums=[i*0.01 for i in range(55,70,10)]

path_py='linear_train.py'

for m in train_nums:
    n=m*100
    path_train_pkl=r'%s/pLink2_filtered-1-yes-xlink_train_%d.pkl'%(path_data_home,n)
    path_val_pkl=r'%s/pLink2_filtered-1-yes-xlink_val_%d.pkl'%(path_data_home,n)
    path_result_home=r'/data/zlchen/pDeepXL/code/pDeepXL/pt/XL-ft-non-clv-%s-%s-n%d'%(data_name,time.strftime("%m%d-%H%M%S", time.localtime()),n)
    if not os.path.exists(path_result_home):
        os.makedirs(path_result_home)
    os.system('echo data_name=%s, train_num=%d begin'%(data_name,n))
    os.system('CUDA_VISIBLE_DEVICES=2 python %s %s %s %s %s'%(path_py, path_train_pkl,path_val_pkl,path_result_home,path_pretrained))
    os.system('echo data_name=%s, train_num=%d end'%(data_name,n))
    os.system('echo ----------------------------------------------')

#############################################################################################
