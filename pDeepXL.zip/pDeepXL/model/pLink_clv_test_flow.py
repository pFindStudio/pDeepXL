# pLink2 测试全流程外壳

import os
import time

#############################################################################################
# 1. 可碎裂数据集测试

model_paths=[r"/data/zlchen/pDeepXL/code/pDeepXL/pt/Linear-1121-222812-final/epoch30-valloss0.0109-valmedianpcc0.9857.pt",
            r"/data/zlchen/pDeepXL/code/pDeepXL/pt/Linear-1121-222812-final/epoch49-valloss0.0108-valmedianpcc0.9857.pt",
            r"/data/zlchen/pDeepXL/code/pDeepXL/pt/Linear-1121-222812-final/epoch51-valloss0.0108-valmedianpcc0.9858.pt",
            r"/data/zlchen/pDeepXL/code/pDeepXL/pt/Linear-1121-222812-final/epoch82-valloss0.0107-valmedianpcc0.9860.pt",
            r"/data/zlchen/pDeepXL/code/pDeepXL/pt/XL-clv-1121-222341-no-transfer/epoch85-valloss0.0076-valmedianpcc0.9634.pt",
            r"/data/zlchen/pDeepXL/code/pDeepXL/pt/XL-clv-1123-164209-transfer30/epoch89-valloss0.0075-valmedianpcc0.9638.pt",
            r"/data/zlchen/pDeepXL/code/pDeepXL/pt/XL-clv-1123-185004-transfer49/epoch82-valloss0.0076-valmedianpcc0.9618.pt",
            r"/data/zlchen/pDeepXL/code/pDeepXL/pt/XL-clv-1123-115438-transfer51/epoch87-valloss0.0075-valmedianpcc0.9629.pt",
            r"/data/zlchen/pDeepXL/code/pDeepXL/pt/XL-clv-1123-142236-transfer82/epoch85-valloss0.0077-valmedianpcc0.9610.pt"
            ]
model_names=["pretrained30","pretrained49","pretrained51","pretrained82","no_transfer","transfer30","transfer49","transfer51","transfer82"]


path_datas=[r'/data/zlchen/pDeepXL/data/pLink_clv_data/pLink2_filtered-2-no-xlink_test.pkl',
                 r'/data/zlchen/pDeepXL/data/PXD011861/Ecoli/pLink2_data/pLink2_filtered-2-no-xlink_test.pkl']
data_names=['overall-test','Ecoli']


path_py='linear_test.py'
for data_name, path_data in zip(data_names, path_datas):
    for model_name, model_path in zip(model_names,model_paths):
        path_result_home=r'/data/zlchen/pDeepXL/code/pDeepXL/pt/XL-test-clv-%s-%s-%s'%(time.strftime("%m%d-%H%M%S", time.localtime()),data_name,model_name)
        if not os.path.exists(path_result_home):
            os.makedirs(path_result_home)
        os.system('echo data_name=%s, model_name=%s begin'%(data_name,model_name))
        os.system('CUDA_VISIBLE_DEVICES=3 python %s %s %s %s'%(path_py, path_data,path_result_home,model_path))
        os.system('echo data_name=%s, model_name=%s end'%(data_name,model_name))
        os.system('echo ----------------------------------------------')
#############################################################################################
