# pLink2 测试全流程外壳

import os
import time

#############################################################################################

model_paths=[r"/data/zlchen/pDeepXL/code/pDeepXL/pt/Linear-1121-222812-final/epoch30-valloss0.0109-valmedianpcc0.9857.pt",
            r"/data/zlchen/pDeepXL/code/pDeepXL/pt/XL-clv-1121-222341-no-transfer/epoch85-valloss0.0076-valmedianpcc0.9634.pt",
            r"/data/zlchen/pDeepXL/code/pDeepXL/pt/XL-clv-1123-164209-transfer30/epoch89-valloss0.0075-valmedianpcc0.9638.pt",
            r'/data/zlchen/pDeepXL/code/pDeepXL/pt/XL-ft-clv-Ecoli-1129-105343-n35/epoch10-valloss0.0080-valmedianpcc0.9614.pt',
            r'/data/zlchen/pDeepXL/code/pDeepXL/pt/XL-no2-clv-1129-191433-Ecoli-n35/epoch10-valloss0.0182-valmedianpcc0.5820.pt'
            ]

model_names=["pretrained30","no_transfer","transfer30","fine_tune","no_transfer_no_fine_tune"]

path_data_homes=[r'/data/zlchen/pDeepXL/data/PXD011861/Ecoli/pLink2_data/fine-tune2']
data_names=['Ecoli']


path_py='linear_test.py'
for data_name, path_data_home in zip(data_names, path_data_homes):
    for model_name, model_path in zip(model_names,model_paths):
        path_match_formatted_pkl=r'%s/pLink2_filtered-2-no-xlink_val_35.pkl'%path_data_home
        path_result_home=r'/data/zlchen/pDeepXL/code/pDeepXL/pt/XL-ft-test-clv-%s-%s-%s'%(time.strftime("%m%d-%H%M%S", time.localtime()),data_name,model_name)
        if not os.path.exists(path_result_home):
            os.makedirs(path_result_home)
        os.system('echo data_name=%s, model_name=%s begin'%(data_name,model_name))
        os.system('CUDA_VISIBLE_DEVICES=1 python %s %s %s %s'%(path_py, path_match_formatted_pkl,path_result_home,model_path))
        os.system('echo data_name=%s, model_name=%s end'%(data_name,model_name))
        os.system('echo ----------------------------------------------')
#############################################################################################
