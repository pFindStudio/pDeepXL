from linear_model import BiLSTMLinearPredictor

import sys
sys.path.append("..")
import utils
import configparser
from tqdm import tqdm
import time
import os
import torch
torch.set_printoptions(profile="full")
import torch.autograd as autograd
import torch.nn as nn
import torch.optim as optim
import torch.nn.utils.rnn as rnn_utils
import logging
import numpy as np


if len(sys.argv) == 4:
    print('有命令行参数')
    print('参数个数为:', len(sys.argv), '个参数。')
    print('参数列表:', str(sys.argv))
    path_match_formatted_pkl,path_result_home,path_model=sys.argv[1:]
    print('path_match_formatted_pkl=%s'%path_match_formatted_pkl)
    print('path_result_home=%s'%path_result_home)
    print('path_model=%s'%path_model)
else:
    print('无命令行参数，或参数个数不等于4')

    # path_match_formatted_pkl = r'/data/zlchen/pDeepXL/data/pFind3_data/pFind3_filtered_test.pkl'
    # path_result_home=r'/data/zlchen/pDeepXL/code/pDeepXL/pt/Linear-test-%s'%time.strftime("%m%d-%H%M%S", time.localtime())
    # # path_model='/data/zlchen/pDeepXL/code/pDeepXL/pt/Linear-1117-180611-output-8dim/epoch49-valloss0.0054-valmedianpcc0.9856.pt'
    # path_model='/data/zlchen/pDeepXL/code/pDeepXL/pt/Linear-1121-222812-final/epoch30-valloss0.0109-valmedianpcc0.9857.pt'

    path_match_formatted_pkl = r'/data/zlchen/pDeepXL/data/PXD014337/QEx-HFX_DSS/pLink2_data/pLink2_filtered-1-yes-xlink_test.pkl'
    path_result_home=r'/data/zlchen/pDeepXL/code/pDeepXL/pt/XL-test-non-clv-%s'%time.strftime("%m%d-%H%M%S", time.localtime())
    # path_model='/data/zlchen/pDeepXL/code/pDeepXL/pt/XL-non-clv-1121-152209-M-DSS-FT/epoch8-valloss0.0139-valmedianpcc0.9563.pt' # old
    path_model='/data/zlchen/pDeepXL/code/pDeepXL/pt/XL-ft-non-clv-M-DSS-1129-204446-rep1/epoch10-valloss0.0164-valmedianpcc0.9536.pt' # new

    # path_match_formatted_pkl = r'/data/zlchen/pDeepXL/data/pLink_clv_data/pLink2_filtered-2-no-xlink_test.pkl'
    # path_result_home=r'/data/zlchen/pDeepXL/code/pDeepXL/pt/XL-test-clv-%s'%time.strftime("%m%d-%H%M%S", time.localtime())
    # path_model='/data/zlchen/pDeepXL/code/pDeepXL/pt/XL-clv-1117-172140-no-transfer/epoch81-valloss0.0076-valmedianpcc0.9632.pt'


if not os.path.exists(path_result_home):
    os.makedirs(path_result_home)

device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')

logging.basicConfig(
    level=logging.INFO,
    format="[%(asctime)s][%(filename)s][line:%(lineno)d][%(levelname)s] %(message)s",
    handlers=[
        logging.FileHandler(r"%s/exp.log"%path_result_home),
        logging.StreamHandler()
    ]
)

logging.info('Start testing...')
logging.info('path_match_formatted_pkl=%s'%path_match_formatted_pkl)
logging.info('path_result_home=%s'%path_result_home)
logging.info('path_model=%s'%path_model)

def TestModel(model, iterator):
    epoch_loss = 0
    model.eval()
    titles,sims=[],[]
    with torch.no_grad():
    
        for batch_x, batch_y, batch_length,batch_title,batch_pt,batch_l1,batch_l2,batch_s1,batch_s2 in iterator:

            batch_x_pack = rnn_utils.pack_padded_sequence(batch_x, batch_length, batch_first=True)
            batch_x_pack, batch_y = batch_x_pack.to(device), batch_y.to(device)

            predictions, loss = model(batch_x_pack, batch_y, batch_pt)
            
            cursims=utils.CalSim(predictions,batch_y,batch_length,batch_pt,batch_l1,batch_l2,batch_s1,batch_s2)
            sims+=cursims
            titles+=batch_title

            epoch_loss += loss.item() # 多卡loss必须loss.sum()

        sims_nan = np.array(sims)
        sims = sims_nan[np.isnan(sims_nan) == False]
        med = np.median(sims)
        avg = np.mean(sims)
        std = np.std(sims)

        wanted_pccs=sorted([0.75,0.90])
        ppcc75,ppcc90=0,0
        if len(sims) > 0:
            pccs, percentages = utils.CountAccuPercentage(sims)
            ppcc75,ppcc90=utils.BatchBSWantedPccs(pccs, percentages, wanted_pccs)

    return epoch_loss / len(iterator), sims, med, avg, std,ppcc75,ppcc90,titles,sims_nan


def WriteTestAns(pAns, test_titles, test_sims_nan):
    pairs=list(zip(test_titles,test_sims_nan))
    pairs=sorted(pairs,key=lambda x:x[1],reverse=True)
    fout=open(pAns,'w')
    for title,pcc in pairs:
        fout.write('%s,%f\n'%(title,pcc))
    fout.close()


def Test():

    BATCH_SIZE=1024

    logging.info('Loading testing data...')
    test_loader=utils.LoadDataSet(path_match_formatted_pkl,BATCH_SIZE)

    INPUT_DIM = 130
    HIDDEN_DIM = 256
    OUTPUT_DIM = 8
    N_LAYERS = 2
    BIDIRECTIONAL = True
    DROPOUT = 0.5
    
    model = BiLSTMLinearPredictor(INPUT_DIM, HIDDEN_DIM, OUTPUT_DIM, N_LAYERS, BIDIRECTIONAL, DROPOUT)
    logging.info(f'The model has {utils.count_parameters(model):,} trainable parameters')

    logging.info('loading pretrained model from %s...'%path_model)
    model.load_state_dict(torch.load(path_model))

    model = model.to(device)

    start_time = time.time()
    test_loss, test_sims, test_med, test_avg, test_std, test_ppcc75, test_ppcc90, test_titles, test_sims_nan = TestModel(model, test_loader)
    end_time = time.time()
    epoch_mins, epoch_secs = utils.epoch_time(start_time, end_time)
    
    logging.info(f'Test Time: {epoch_mins}m {epoch_secs}s')
    logging.info(f'\t Test. Loss: {test_loss:.6f}, pcc: #non-nan=%d, median=%f, avg=%f, std=%f, ppcc75=%f, ppcc90=%f'%(len(test_sims), test_med, test_avg, test_std, test_ppcc75, test_ppcc90))
    logging.info(f'output table, easy to paste to excel: %f, %f, %f, %f, %f'%(test_med, test_avg, test_std, test_ppcc75, test_ppcc90))

    test_pccs,test_percentages=utils.CountAccuPercentage(test_sims)
    utils.PloSingleSimPercentage(test_pccs, test_percentages, path_result_home, 'Test pcc')
    WriteTestAns(r'%s/test_ans.csv'%path_result_home, test_titles, test_sims_nan)
    logging.info('finish testing!')


if __name__ == "__main__":
    Test()