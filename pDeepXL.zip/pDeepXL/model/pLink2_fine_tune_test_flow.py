# pLink2 测试全流程外壳

import os
import time

#############################################################################################

model_paths=[r"/data/zlchen/pDeepXL/code/pDeepXL/pt/Linear-1121-222812-final/epoch30-valloss0.0109-valmedianpcc0.9857.pt",
            r"/data/zlchen/pDeepXL/code/pDeepXL/pt/XL-non-clv-1121-222121-no-transfer/epoch94-valloss0.0109-valmedianpcc0.9579.pt",
            r"/data/zlchen/pDeepXL/code/pDeepXL/pt/XL-non-clv-1123-163938-transfer30/epoch56-valloss0.0097-valmedianpcc0.9669.pt",
            r'/data/zlchen/pDeepXL/code/pDeepXL/pt/XL-ft-non-clv-K562-1129-103958-n35/epoch10-valloss0.0126-valmedianpcc0.9584.pt',
            r'/data/zlchen/pDeepXL/code/pDeepXL/pt/XL-no2-non-clv-1129-191340-K562-n35/epoch10-valloss0.0288-valmedianpcc0.6259.pt'
            ]

model_names=["pretrained30","no_transfer","transfer30","fine_tune","no_transfer_no_fine_tune"]

path_data_homes=[r'/data/zlchen/pDeepXL/data/PXD008550/HumanFOMix_BS3/pLink2_data/fine-tune2']
data_names=['K562']


path_py='linear_test.py'
for data_name, path_data_home in zip(data_names, path_data_homes):
    for model_name, model_path in zip(model_names,model_paths):
        path_match_formatted_pkl=r'%s/pLink2_filtered-1-yes-xlink_val_35.pkl'%path_data_home
        path_result_home=r'/data/zlchen/pDeepXL/code/pDeepXL/pt/XL-ft-test-non-clv-%s-%s-%s'%(time.strftime("%m%d-%H%M%S", time.localtime()),data_name,model_name)
        if not os.path.exists(path_result_home):
            os.makedirs(path_result_home)
        os.system('echo data_name=%s, model_name=%s begin'%(data_name,model_name))
        os.system('CUDA_VISIBLE_DEVICES=2 python %s %s %s %s'%(path_py, path_match_formatted_pkl,path_result_home,model_path))
        os.system('echo data_name=%s, model_name=%s end'%(data_name,model_name))
        os.system('echo ----------------------------------------------')
#############################################################################################
