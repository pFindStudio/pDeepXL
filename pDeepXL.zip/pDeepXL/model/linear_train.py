from linear_model import BiLSTMLinearPredictor

import sys
sys.path.append("..")
import utils
import configparser
from tqdm import tqdm
import time
import os
import torch
torch.set_printoptions(profile="full")
import torch.autograd as autograd
import torch.nn as nn
import torch.optim as optim
import torch.nn.utils.rnn as rnn_utils
import logging
import numpy as np


if len(sys.argv) == 5:
    print('有命令行参数')
    print('参数个数为:', len(sys.argv), '个参数。')
    print('参数列表:', str(sys.argv))
    path_train_pkl,path_val_pkl,path_result_home,path_pretrained=sys.argv[1:]
    print('path_train_pkl=%s'%path_train_pkl)
    print('path_val_pkl=%s'%path_val_pkl)
    print('path_result_home=%s'%path_result_home)
    print('path_pretrained=%s'%path_pretrained)
else:
    print('无命令行参数，或参数个数不等于5')

    # train pDeep
    # path_data_home = r'/data/zlchen/pDeepXL/data'
    # path_train_pkl = r'%s/pFind3_data/pFind3_filtered_train.pkl'%path_data_home
    # path_val_pkl = r'%s/pFind3_data/pFind3_filtered_val.pkl'%path_data_home
    # path_result_home=r'/data/zlchen/pDeepXL/code/pDeepXL/pt/Linear-%s'%time.strftime("%m%d-%H%M%S", time.localtime())
    # path_pretrained=''

    # train pDeepXL
    path_data_home = r'/data/zlchen/pDeepXL/data/PXD014337/QEx-HFX_DSS/pLink2_data/fine-tune'
    path_train_pkl = r'%s/pLink2_filtered-1-yes-xlink_train_100.pkl'%path_data_home
    path_val_pkl = r'%s/pLink2_filtered-1-yes-xlink_val_100.pkl'%path_data_home
    path_result_home=r'/data/zlchen/pDeepXL/code/pDeepXL/pt/XL-%s'%time.strftime("%m%d-%H%M%S", time.localtime())
    path_pretrained=r"/data/zlchen/pDeepXL/code/pDeepXL/pt/XL-non-clv-1123-163938-transfer30/epoch56-valloss0.0097-valmedianpcc0.9669.pt"
    # path_pretrained=''



if not os.path.exists(path_result_home):
    os.makedirs(path_result_home)

device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')

logging.basicConfig(
    level=logging.INFO,
    format="[%(asctime)s][%(filename)s][line:%(lineno)d][%(levelname)s] %(message)s",
    handlers=[
        logging.FileHandler(r"%s/exp.log"%path_result_home),
        logging.StreamHandler()
    ]
)

logging.info('Start training...')


def TrainModel(model, iterator, optimizer):
    epoch_loss = 0
    model.train()
    sims=[]
    for batch_x, batch_y, batch_length,batch_title,batch_pt,batch_l1,batch_l2,batch_s1,batch_s2 in iterator:

        batch_x_pack = rnn_utils.pack_padded_sequence(batch_x, batch_length, batch_first=True)
        batch_x_pack, batch_y = batch_x_pack.to(device), batch_y.to(device)

        optimizer.zero_grad()
        predictions,loss = model(batch_x_pack, batch_y, batch_pt)

        cursims=utils.CalSim(predictions,batch_y,batch_length,batch_pt,batch_l1,batch_l2,batch_s1,batch_s2)
        sims+=cursims

        epoch_loss += loss.item() # 多卡loss必须loss.sum()
        loss.backward()
        optimizer.step()
        
    sims_nan = np.array(sims)
    sims = sims_nan[np.isnan(sims_nan) == False]
    med = np.median(sims)
    avg = np.mean(sims)
    std = np.std(sims)

    wanted_pccs=sorted([0.75,0.90])
    ppcc75,ppcc90=0,0
    if len(sims) > 0:
        pccs, percentages = utils.CountAccuPercentage(sims)
        ppcc75,ppcc90=utils.BatchBSWantedPccs(pccs, percentages, wanted_pccs)

    return epoch_loss / len(iterator), sims, med, avg, std,ppcc75,ppcc90

def EvaluateModel(model, iterator):
    epoch_loss = 0
    model.eval()
    sims=[]
    with torch.no_grad():
    
        for batch_x, batch_y, batch_length,batch_title,batch_pt,batch_l1,batch_l2,batch_s1,batch_s2 in iterator:

            batch_x_pack = rnn_utils.pack_padded_sequence(batch_x, batch_length, batch_first=True)
            batch_x_pack, batch_y = batch_x_pack.to(device), batch_y.to(device)

            predictions, loss = model(batch_x_pack, batch_y, batch_pt)
            
            cursims=utils.CalSim(predictions,batch_y,batch_length,batch_pt,batch_l1,batch_l2,batch_s1,batch_s2)
            sims+=cursims

            epoch_loss += loss.item() # 多卡loss必须loss.sum()

        sims_nan = np.array(sims)
        sims = sims_nan[np.isnan(sims_nan) == False]
        med = np.median(sims)
        avg = np.mean(sims)
        std = np.std(sims)

        wanted_pccs=sorted([0.75,0.90])
        ppcc75,ppcc90=0,0
        if len(sims) > 0:
            pccs, percentages = utils.CountAccuPercentage(sims)
            ppcc75,ppcc90=utils.BatchBSWantedPccs(pccs, percentages, wanted_pccs)

    return epoch_loss / len(iterator), sims, med, avg, std,ppcc75,ppcc90
        

def Train():

    BATCH_SIZE=1024

    logging.info('Loading training data...')
    train_loader=utils.LoadDataSet(path_train_pkl,BATCH_SIZE)
    logging.info('Loading validation data...')
    validation_loader=utils.LoadDataSet(path_val_pkl,BATCH_SIZE)

    INPUT_DIM = 130
    HIDDEN_DIM = 256
    OUTPUT_DIM = 8
    N_LAYERS = 2
    BIDIRECTIONAL = True
    DROPOUT = 0.5
    N_EPOCHS = 50
    LR=0.001
    
    model = BiLSTMLinearPredictor(INPUT_DIM, HIDDEN_DIM, OUTPUT_DIM, N_LAYERS, BIDIRECTIONAL, DROPOUT)
    logging.info(f'The model has {utils.count_parameters(model):,} trainable parameters')

    if os.path.exists(path_pretrained):
        logging.info('loading pretrained model from %s...'%path_pretrained)
        model.load_state_dict(torch.load(path_pretrained))
    else:
        logging.info('no pretrained model.')

    optimizer = optim.Adam(model.parameters(), lr=LR)
    scheduler = optim.lr_scheduler.StepLR(optimizer, step_size=80, gamma=0.1) # 每80个epoch，lr衰减0.1

    # model = nn.DataParallel(model, device_ids = [0,1,2,3]) # multi-GPU, 这样可以。
    # 同时loss.item()和loss.backward()改为loss.sum().item()和loss.sum().backward()
    model = model.to(device)

    best_valid_loss = float('inf')
    train_losses, valid_losses = [], []
    train_sim_meds, train_sim_avg, train_sim_std = [], [], []
    valid_sim_meds, valid_sim_avg, valid_sim_std = [], [], []
    train_ppcc75s,train_ppcc90s=[],[]
    valid_ppcc75s,valid_ppcc90s=[],[]
    train_sims, valid_sims=[], []
    for epoch in range(N_EPOCHS):

        start_time = time.time()
        
        train_loss, train_sims, train_med, train_avg, train_std, train_ppcc75, train_ppcc90 = TrainModel(model, train_loader, optimizer)
        valid_loss, valid_sims, valid_med, valid_avg, valid_std, valid_ppcc75, valid_ppcc90 = EvaluateModel(model, validation_loader)

        train_losses.append(train_loss)
        valid_losses.append(valid_loss)

        train_sim_meds.append(train_med)
        train_sim_avg.append(train_avg)
        train_sim_std.append(train_std)

        valid_sim_meds.append(valid_med)
        valid_sim_avg.append(valid_avg)
        valid_sim_std.append(valid_std)

        train_ppcc75s.append(train_ppcc75)
        train_ppcc90s.append(train_ppcc90)

        valid_ppcc75s.append(valid_ppcc75)
        valid_ppcc90s.append(valid_ppcc90)

        end_time = time.time()

        epoch_mins, epoch_secs = utils.epoch_time(start_time, end_time)
        
        # 常规版本
        # if valid_loss < best_valid_loss:
        #     best_valid_loss = valid_loss
        #     logging.info('saving new best model...')
        #     torch.save(model.state_dict(), r'%s/epoch%d-valloss%.4f-valmedianpcc%.4f.pt'%(path_result_home,epoch,valid_loss,valid_med))

        # fine tune时每一步的模型都保留
        if valid_loss < best_valid_loss:
            best_valid_loss = valid_loss
            logging.info('getting new best model...')
        torch.save(model.state_dict(), r'%s/epoch%d-valloss%.4f-valmedianpcc%.4f.pt'%(path_result_home,epoch,valid_loss,valid_med))
        #############


        logging.info(f'Epoch: {epoch+1:02} | Epoch Time: {epoch_mins}m {epoch_secs}s')
        logging.info(f'\tTrain Loss: {train_loss:.6f}, pcc: #non-nan=%d, median=%f, avg=%f, std=%f, ppcc75=%f, ppcc90=%f, lr=%f'%(len(train_sims), train_med, train_avg, train_std, train_ppcc75, train_ppcc90,optimizer.param_groups[0]['lr']))
        logging.info(f'\t Val. Loss: {valid_loss:.6f}, pcc: #non-nan=%d, median=%f, avg=%f, std=%f, ppcc75=%f, ppcc90=%f'%(len(valid_sims), valid_med, valid_avg, valid_std, valid_ppcc75, valid_ppcc90))

        scheduler.step()
        
    utils.PlotWithEpoch(train_losses, valid_losses, path_result_home, 'loss')
    utils.PlotWithEpoch(train_sim_meds, valid_sim_meds, path_result_home, 'pcc median')
    utils.PlotWithEpoch(train_sim_avg, valid_sim_avg, path_result_home, 'pcc average')
    utils.PlotWithEpoch(train_sim_std, valid_sim_std, path_result_home, 'pcc std')

    utils.PlotWithEpoch(train_ppcc75s, valid_ppcc75s, path_result_home, 'percentage of pcc0.75')
    utils.PlotWithEpoch(train_ppcc90s, valid_ppcc90s, path_result_home, 'percentage of pcc0.9')

    utils.PlotSimPercentage(train_sims, valid_sims, path_result_home, 'pcc at the last epoch')
    logging.info('finish training!')


if __name__ == "__main__":
    Train()