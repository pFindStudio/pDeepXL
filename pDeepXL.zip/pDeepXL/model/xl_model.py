import torch
import torch.autograd as autograd
import torch.nn as nn
import torch.optim as optim
import torch.nn.utils.rnn as rnn_utils
import torch.nn.functional as F

device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')

class BiLSTMXLPredictor(nn.Module):
    def __init__(self, input_dim, hidden_dim, output_dim, n_layers, bidirectional, dropout):
        super().__init__()
        
        self.lstm = nn.LSTM(input_dim, hidden_dim, num_layers = n_layers, bidirectional = bidirectional, dropout = dropout, batch_first = True)
        self.fc1 = nn.Linear(hidden_dim * 2 if bidirectional else hidden_dim, output_dim)
        self.fc2 = nn.ReLU(inplace=True)

    # https://blog.csdn.net/Mr_green_bean/article/details/104713382
    def mask_mae_loss(self, padded_y_truth1, y_pred1, y_length1, padded_y_truth2, y_pred2, y_length2):
        mask1 = torch.zeros(padded_y_truth1.shape)
        for i,l in enumerate(y_length1):
            mask1[i,:l,:]=1
        mask1 = mask1.to(device)
        masked_y_pred1 = y_pred1.mul(mask1)

        mask2 = torch.zeros(padded_y_truth2.shape)
        for i,l in enumerate(y_length2):
            mask2[i,:l,:]=1
        mask2 = mask2.to(device)
        masked_y_pred2 = y_pred2.mul(mask2)

        return (F.l1_loss(masked_y_pred1, padded_y_truth1) + F.l1_loss(masked_y_pred2, padded_y_truth2)) / 2.0

    def work(self, packed_peptides):
        outputs, (hidden, cell) = self.lstm(packed_peptides)
        out_unpack, out_len = rnn_utils.pad_packed_sequence(outputs, batch_first=True)
        predictions = self.fc2(self.fc1(out_unpack))
        
        mask = torch.zeros(predictions.shape)
        for i,l in enumerate(out_len):
            mask[i,:l,:]=1
        mask = mask.to(device)
        masked_y_pred = predictions.mul(mask)

        return masked_y_pred,out_len
    
    def forward(self, padded_peptides1, padded_intensities1, packed_lens1, padded_peptides2, padded_intensities2, packed_lens2):

        # padded_peptides shape: [batch size, peptide len, input dim]
        outputs1, (hidden1, cell1) = self.lstm(padded_peptides1)
        outputs2, (hidden2, cell2) = self.lstm(padded_peptides2)
        
        # predictions shape: [batch size, peptide len,  output dim]
        predictions1 = self.fc2(self.fc1(outputs1))
        predictions2 = self.fc2(self.fc1(outputs2))

        loss = self.mask_mae_loss(padded_intensities1,predictions1,packed_lens1,padded_intensities2,predictions2,packed_lens2)
        
        return predictions1,predictions2,loss