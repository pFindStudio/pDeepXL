#! /bin/sh


cd /data/zlchen/pDeepXL/code/pDeepXL/model

# CUDA_VISIBLE_DEVICES=2 python /data/zlchen/pDeepXL/code/pDeepXL/model/linear_train_non_clv_1e_2.py
CUDA_VISIBLE_DEVICES=1 python /data/zlchen/pDeepXL/code/pDeepXL/model/linear_train_non_clv30.py
CUDA_VISIBLE_DEVICES=1 python /data/zlchen/pDeepXL/code/pDeepXL/model/linear_train_non_clv49.py
