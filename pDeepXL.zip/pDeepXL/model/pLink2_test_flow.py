# pLink2 测试全流程外壳

import os
import time

#############################################################################################
# 1. 不可碎裂数据集测试

model_paths=[r"/data/zlchen/pDeepXL/code/pDeepXL/pt/Linear-1121-222812-final/epoch30-valloss0.0109-valmedianpcc0.9857.pt",
            r"/data/zlchen/pDeepXL/code/pDeepXL/pt/Linear-1121-222812-final/epoch49-valloss0.0108-valmedianpcc0.9857.pt",
            r"/data/zlchen/pDeepXL/code/pDeepXL/pt/Linear-1121-222812-final/epoch51-valloss0.0108-valmedianpcc0.9858.pt",
            r"/data/zlchen/pDeepXL/code/pDeepXL/pt/Linear-1121-222812-final/epoch82-valloss0.0107-valmedianpcc0.9860.pt",
            r"/data/zlchen/pDeepXL/code/pDeepXL/pt/XL-non-clv-1121-222121-no-transfer/epoch94-valloss0.0109-valmedianpcc0.9579.pt",
            r"/data/zlchen/pDeepXL/code/pDeepXL/pt/XL-non-clv-1123-163938-transfer30/epoch56-valloss0.0097-valmedianpcc0.9669.pt",
            r"/data/zlchen/pDeepXL/code/pDeepXL/pt/XL-non-clv-1123-175345-transfer49/epoch56-valloss0.0099-valmedianpcc0.9653.pt",
            r"/data/zlchen/pDeepXL/code/pDeepXL/pt/XL-non-clv-1123-115257-transfer51/epoch77-valloss0.0099-valmedianpcc0.9651.pt",
            r"/data/zlchen/pDeepXL/code/pDeepXL/pt/XL-non-clv-1123-132101-transfer82/epoch50-valloss0.0099-valmedianpcc0.9647.pt"
            ]
model_names=["pretrained30","pretrained49","pretrained51","pretrained82","no_transfer","transfer30","transfer49","transfer51","transfer82"]

path_data_homes=[r'/data/zlchen/pDeepXL/data',
                 r'/data/zlchen/pDeepXL/data/PXD008550/HumanFOMix_BS3',
                 r'/data/zlchen/pDeepXL/data/Leiker_elife/6.C.elegans_lysates/N2']
data_names=['overall-test','K562','worm']


# model_paths=[r"/data/zlchen/pDeepXL/code/pDeepXL/pt/XL-non-clv-1121-153314-M-DSS-FT/epoch8-valloss0.0140-valmedianpcc0.9546.pt"]
# model_names=["fine_tune"]
# path_data_homes=[r'/data/zlchen/pDeepXL/data/PXD014337/QEx-HFX_DSS']
# data_names=['M-DSS']


path_py='linear_test.py'
for data_name, path_data_home in zip(data_names, path_data_homes):
    for model_name, model_path in zip(model_names,model_paths):
        path_match_formatted_pkl=r'%s/pLink2_data/pLink2_filtered-1-yes-xlink_test.pkl'%path_data_home
        path_result_home=r'/data/zlchen/pDeepXL/code/pDeepXL/pt/XL-test-non-clv-%s-%s-%s'%(time.strftime("%m%d-%H%M%S", time.localtime()),data_name,model_name)
        if not os.path.exists(path_result_home):
            os.makedirs(path_result_home)
        os.system('echo data_name=%s, model_name=%s begin'%(data_name,model_name))
        os.system('CUDA_VISIBLE_DEVICES=2 python %s %s %s %s'%(path_py, path_match_formatted_pkl,path_result_home,model_path))
        os.system('echo data_name=%s, model_name=%s end'%(data_name,model_name))
        os.system('echo ----------------------------------------------')
#############################################################################################
