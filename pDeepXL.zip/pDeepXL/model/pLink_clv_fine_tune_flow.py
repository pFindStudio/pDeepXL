# pLink2 测试全流程外壳

import os
import time

#############################################################################################
# 1. 可碎裂数据集fine tune

path_pretrained=r'/data/zlchen/pDeepXL/code/pDeepXL/pt/XL-clv-1123-164209-transfer30/epoch89-valloss0.0075-valmedianpcc0.9638.pt'

path_data_home=r'/data/zlchen/pDeepXL/data/PXD011861/Ecoli/pLink2_data/fine-tune2'
data_name='Ecoli'

# train_nums=[10,50,100,150,200,250,300,500]
# train_nums=[350,400,450]
train_nums=[i*0.01 for i in range(5,80,10)]

path_py='linear_train.py'

for m in train_nums:
    n=m*100
    path_train_pkl=r'%s/pLink2_filtered-2-no-xlink_train_%d.pkl'%(path_data_home,n)
    path_val_pkl=r'%s/pLink2_filtered-2-no-xlink_val_%d.pkl'%(path_data_home,n)
    path_result_home=r'/data/zlchen/pDeepXL/code/pDeepXL/pt/XL-ft-clv-%s-%s-n%d'%(data_name,time.strftime("%m%d-%H%M%S", time.localtime()),n)
    if not os.path.exists(path_result_home):
        os.makedirs(path_result_home)
    os.system('echo data_name=%s, train_num=%d begin'%(data_name,n))
    os.system('CUDA_VISIBLE_DEVICES=0 python %s %s %s %s %s'%(path_py, path_train_pkl,path_val_pkl,path_result_home,path_pretrained))
    os.system('echo data_name=%s, train_num=%d end'%(data_name,n))
    os.system('echo ----------------------------------------------')

#############################################################################################
