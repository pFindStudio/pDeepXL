#! /bin/sh


cd /data/zlchen/pDeepXL/code/pDeepXL/model

# CUDA_VISIBLE_DEVICES=1 python linear_test.py path_match_formatted_pkl,path_result_home,path_model


CUDA_VISIBLE_DEVICES=1 python linear_test.py /data/zlchen/pDeepXL/data/PXD019926/DSS/8PM/pLink2_data/pLink2_filtered-1-yes-xlion.pkl /data/zlchen/pDeepXL/code/pDeepXL/pt/XL-test-1031-1-yes-xion-8PM-pretrained /data/zlchen/pDeepXL/code/pDeepXL/pt/Linear-1027-165109-big-linear4/epoch93-valloss0.0110-valmedianpcc0.9857.pt
CUDA_VISIBLE_DEVICES=1 python linear_test.py /data/zlchen/pDeepXL/data/PXD019926/DSS/8PM/pLink2_data/pLink2_filtered-1-yes-xlion.pkl /data/zlchen/pDeepXL/code/pDeepXL/pt/XL-test-1031-1-yes-xion-8PM-no-transfer /data/zlchen/pDeepXL/code/pDeepXL/pt/XL-1027-164332-1-yes-xlion-no-transfer/epoch49-valloss0.0142-valmedianpcc0.9393.pt
CUDA_VISIBLE_DEVICES=1 python linear_test.py /data/zlchen/pDeepXL/data/PXD019926/DSS/8PM/pLink2_data/pLink2_filtered-1-yes-xlion.pkl /data/zlchen/pDeepXL/code/pDeepXL/pt/XL-test-1031-1-yes-xion-8PM-transfer /data/zlchen/pDeepXL/code/pDeepXL/pt/XL-1030-223830-1-yes-xlion-transfer-pretrained100/epoch49-valloss0.0108-valmedianpcc0.9646.pt



CUDA_VISIBLE_DEVICES=1 python linear_test.py /data/zlchen/pDeepXL/data/Leiker_elife/6.C.elegans_lysates/N2/pLink2_data/pLink2_filtered-1-yes-xlion.pkl /data/zlchen/pDeepXL/code/pDeepXL/pt/XL-test-1031-1-yes-xion-leiker-worm-pretrained /data/zlchen/pDeepXL/code/pDeepXL/pt/Linear-1027-165109-big-linear4/epoch93-valloss0.0110-valmedianpcc0.9857.pt
CUDA_VISIBLE_DEVICES=1 python linear_test.py /data/zlchen/pDeepXL/data/Leiker_elife/6.C.elegans_lysates/N2/pLink2_data/pLink2_filtered-1-yes-xlion.pkl /data/zlchen/pDeepXL/code/pDeepXL/pt/XL-test-1031-1-yes-xion-leiker-worm-no-transfer /data/zlchen/pDeepXL/code/pDeepXL/pt/XL-1027-164332-1-yes-xlion-no-transfer/epoch49-valloss0.0142-valmedianpcc0.9393.pt
CUDA_VISIBLE_DEVICES=1 python linear_test.py /data/zlchen/pDeepXL/data/Leiker_elife/6.C.elegans_lysates/N2/pLink2_data/pLink2_filtered-1-yes-xlion.pkl /data/zlchen/pDeepXL/code/pDeepXL/pt/XL-test-1031-1-yes-xion-leiker-worm-transfer /data/zlchen/pDeepXL/code/pDeepXL/pt/XL-1030-223830-1-yes-xlion-transfer-pretrained100/epoch49-valloss0.0108-valmedianpcc0.9646.pt


CUDA_VISIBLE_DEVICES=1 python linear_test.py /data/zlchen/pDeepXL/data/PXD014337/QEx-HFX_DSS/pLink2_data/pLink2_filtered-1-yes-xlion.pkl /data/zlchen/pDeepXL/code/pDeepXL/pt/XL-test-1031-1-yes-xion-M-DSS-pretrained /data/zlchen/pDeepXL/code/pDeepXL/pt/Linear-1027-165109-big-linear4/epoch93-valloss0.0110-valmedianpcc0.9857.pt
CUDA_VISIBLE_DEVICES=1 python linear_test.py /data/zlchen/pDeepXL/data/PXD014337/QEx-HFX_DSS/pLink2_data/pLink2_filtered-1-yes-xlion.pkl /data/zlchen/pDeepXL/code/pDeepXL/pt/XL-test-1031-1-yes-xion-M-DSS-no-transfer /data/zlchen/pDeepXL/code/pDeepXL/pt/XL-1027-164332-1-yes-xlion-no-transfer/epoch49-valloss0.0142-valmedianpcc0.9393.pt
CUDA_VISIBLE_DEVICES=1 python linear_test.py /data/zlchen/pDeepXL/data/PXD014337/QEx-HFX_DSS/pLink2_data/pLink2_filtered-1-yes-xlion.pkl /data/zlchen/pDeepXL/code/pDeepXL/pt/XL-test-1031-1-yes-xion-M-DSS-transfer /data/zlchen/pDeepXL/code/pDeepXL/pt/XL-1030-223830-1-yes-xlion-transfer-pretrained100/epoch49-valloss0.0108-valmedianpcc0.9646.pt




CUDA_VISIBLE_DEVICES=1 python linear_test.py /data/zlchen/pDeepXL/data/pLink2_data/pLink2_filtered-1-yes-xlion_test.pkl /data/zlchen/pDeepXL/code/pDeepXL/pt/XL-test-1031-1-yes-xion-overall-test-pretrained /data/zlchen/pDeepXL/code/pDeepXL/pt/Linear-1027-165109-big-linear4/epoch93-valloss0.0110-valmedianpcc0.9857.pt
CUDA_VISIBLE_DEVICES=1 python linear_test.py /data/zlchen/pDeepXL/data/pLink2_data/pLink2_filtered-1-yes-xlion_test.pkl /data/zlchen/pDeepXL/code/pDeepXL/pt/XL-test-1031-1-yes-xion-overall-test-no-transfer /data/zlchen/pDeepXL/code/pDeepXL/pt/XL-1027-164332-1-yes-xlion-no-transfer/epoch49-valloss0.0142-valmedianpcc0.9393.pt
CUDA_VISIBLE_DEVICES=1 python linear_test.py /data/zlchen/pDeepXL/data/pLink2_data/pLink2_filtered-1-yes-xlion_test.pkl /data/zlchen/pDeepXL/code/pDeepXL/pt/XL-test-1031-1-yes-xion-overall-test-transfer /data/zlchen/pDeepXL/code/pDeepXL/pt/XL-1030-223830-1-yes-xlion-transfer-pretrained100/epoch49-valloss0.0108-valmedianpcc0.9646.pt





CUDA_VISIBLE_DEVICES=1 python linear_test.py /data/zlchen/pDeepXL/data/PXD008550/HumanFOMix_BS3/pLink2_data/pLink2_filtered-1-yes-xlion.pkl /data/zlchen/pDeepXL/code/pDeepXL/pt/XL-test-1031-1-yes-xion-Juri-K562-pretrained /data/zlchen/pDeepXL/code/pDeepXL/pt/Linear-1027-165109-big-linear4/epoch93-valloss0.0110-valmedianpcc0.9857.pt
CUDA_VISIBLE_DEVICES=1 python linear_test.py /data/zlchen/pDeepXL/data/PXD008550/HumanFOMix_BS3/pLink2_data/pLink2_filtered-1-yes-xlion.pkl /data/zlchen/pDeepXL/code/pDeepXL/pt/XL-test-1031-1-yes-xion-Juri-K562-no-transfer /data/zlchen/pDeepXL/code/pDeepXL/pt/XL-1027-164332-1-yes-xlion-no-transfer/epoch49-valloss0.0142-valmedianpcc0.9393.pt
CUDA_VISIBLE_DEVICES=1 python linear_test.py /data/zlchen/pDeepXL/data/PXD008550/HumanFOMix_BS3/pLink2_data/pLink2_filtered-1-yes-xlion.pkl /data/zlchen/pDeepXL/code/pDeepXL/pt/XL-test-1031-1-yes-xion-Juri-K562-transfer /data/zlchen/pDeepXL/code/pDeepXL/pt/XL-1030-223830-1-yes-xlion-transfer-pretrained100/epoch49-valloss0.0108-valmedianpcc0.9646.pt




CUDA_VISIBLE_DEVICES=1 python linear_test.py /data/zlchen/pDeepXL/data/PXD006626/pLink2_data/pLink2_filtered-1-yes-xlion.pkl /data/zlchen/pDeepXL/code/pDeepXL/pt/XL-test-1031-1-yes-xion-Juri-C-pretrained /data/zlchen/pDeepXL/code/pDeepXL/pt/Linear-1027-165109-big-linear4/epoch93-valloss0.0110-valmedianpcc0.9857.pt
CUDA_VISIBLE_DEVICES=1 python linear_test.py /data/zlchen/pDeepXL/data/PXD006626/pLink2_data/pLink2_filtered-1-yes-xlion.pkl /data/zlchen/pDeepXL/code/pDeepXL/pt/XL-test-1031-1-yes-xion-Juri-C-no-transfer /data/zlchen/pDeepXL/code/pDeepXL/pt/XL-1027-164332-1-yes-xlion-no-transfer/epoch49-valloss0.0142-valmedianpcc0.9393.pt
CUDA_VISIBLE_DEVICES=1 python linear_test.py /data/zlchen/pDeepXL/data/PXD006626/pLink2_data/pLink2_filtered-1-yes-xlion.pkl /data/zlchen/pDeepXL/code/pDeepXL/pt/XL-test-1031-1-yes-xion-Juri-C-transfer /data/zlchen/pDeepXL/code/pDeepXL/pt/XL-1030-223830-1-yes-xlion-transfer-pretrained100/epoch49-valloss0.0108-valmedianpcc0.9646.pt
