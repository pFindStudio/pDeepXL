from linear_model import BiLSTMLinearPredictor

import configparser
import pickle
from tqdm import tqdm
import numpy as np
import time

import torch
import torch.autograd as autograd
import torch.nn as nn
import torch.optim as optim
import torch.utils.data
from torch.utils.data import DataLoader

import matplotlib
matplotlib.use('AGG')#或者PDF, SVG或PS
import matplotlib.pyplot as plt
import seaborn as sns
from matplotlib.ticker import MaxNLocator
from sklearn.model_selection import train_test_split
import torch.nn.utils.rnn as rnn_utils

import sys
sys.path.append("..")
import utils


if len(sys.argv) == 5:
    print('have command arguments')
    print('have:', len(sys.argv), ' args')
    print('arg list:', str(sys.argv))
    path_predict_file,path_predict_ans_file,path_model,consider=sys.argv[1:]
    print('path_predict_file=%s'%path_predict_file)
    print('path_predict_ans_file=%s'%path_predict_ans_file)
    print('path_model=%s'%path_model)
    print('consider=%s'%consider)
    consider=int(consider.strip())
    consider_xlink_ion = True if consider==1 else False
    print('consider_xlink_ion=%d'%consider_xlink_ion)
else:
    print('no command arguments, or #args !=5')
    path_predict_file = r'/data/zlchen/pDeepXL/data/pLink2_data/pLink2_match_info_filtered_test_small.txt'
    path_predict_ans_file = r'/data/zlchen/pDeepXL/data/pLink2_data/pLink2_match_info_filtered_test_small_ans.txt'
    path_model = r"/data/zlchen/pDeepXL/code/pDeepXL/pt/XL-non-clv-1123-163938-transfer30/epoch56-valloss0.0097-valmedianpcc0.9669.pt"
    consider_xlink_ion=True

    # path_predict_file = r'/data/zlchen/pDeepXL/data/pLink_clv_data/pLink2_match_info_filtered_test.txt'
    # path_predict_ans_file = r'/data/zlchen/pDeepXL/data/pLink_clv_data/pLink2_match_info_filtered_test_ans.txt'
    # path_model = r"/data/zlchen/pDeepXL/code/pDeepXL/pt/XL-clv-1123-164209-transfer30/epoch89-valloss0.0075-valmedianpcc0.9638.pt"
    # consider_xlink_ion=False


device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')

config = configparser.ConfigParser()
# config.read(r'/data/zlchen/pDeepXL/code/pDeepXL/config.ini') # 1212
config.read(r'../config.ini', encoding='UTF-8')

MIN_PREC_CHARGE=int(config['DEFAULT']['min_prec_charge'])
MAX_PREC_CHARGE=int(config['DEFAULT']['max_prec_charge'])
MIN_PEPTIDE_LEN=int(config['DEFAULT']['min_peptide_len'])
MAX_PEPTIDE_LEN=int(config['DEFAULT']['max_peptide_len'])

from preprocess.peptide_featurer import PeptideFeaturer
pf = PeptideFeaturer(config)


def GetPeptideFeatures(CSMs, consider_xlink_ion):
    T,L,X=[],[],[] # L表示总长度
    PT=[] # 肽段类型peptide type，0 for linear, 1 for non-clv, 2 for clv
    L1,L2,S1,S2=[],[],[],[] # α和β的长度，及交联位点，如果是单肽（P=0），则这几个值都是-1（无效）

    cur_pt=1 if consider_xlink_ion else 2

    num_invalid=0
    for csm in tqdm(CSMs):
        title,scan,prec_charge,instrument,NCE_low, NCE_medium, NCE_high,LinkerName,seq1,mods1,linksite1,seq2,mods2,linksite2=csm
        l1,l2 = len(seq1),len(seq2)

        if not (prec_charge >= MIN_PREC_CHARGE and prec_charge <= MAX_PREC_CHARGE \
                and l1 >= MIN_PEPTIDE_LEN and l1 <= MAX_PEPTIDE_LEN \
                and l2 >= MIN_PEPTIDE_LEN and l2 <= MAX_PEPTIDE_LEN): # 电荷与长度的约束
            num_invalid+=1
            continue

        seq1_vec,seq1_aa_mod_sum = pf.Sequence2Vec(seq1,mods1,prec_charge,instrument,NCE_low, NCE_medium, NCE_high,LinkerName,linksite1,False)
        seq2_vec,seq2_aa_mod_sum = pf.Sequence2Vec(seq2,mods2,prec_charge,instrument,NCE_low, NCE_medium, NCE_high,LinkerName,linksite2,False)

        # 对于不可碎裂交联剂，累加和需要考虑互补肽段
        if consider_xlink_ion:
            seq1_vec = pf.AddAnotherSeq(seq1_vec, linksite1, seq2_aa_mod_sum)
            seq2_vec = pf.AddAnotherSeq(seq2_vec, linksite2, seq1_aa_mod_sum)

        linker_symbol_vec = [pf.LinkerSymbol2Vec()]

        X.append(seq1_vec+linker_symbol_vec+seq2_vec)
        L.append(l1-1+l2-1+1)
        T.append(title)

        PT.append(cur_pt)
        L1.append(l1-1)
        L2.append(l2-1)
        S1.append(linksite1)
        S2.append(linksite2)

    print('collected %d valid samples, discard %d invalid samples'%(len(T),num_invalid))
    return T,PT,L,L1,L2,S1,S2,X


def LoadPredictDataSet(BATCH_SIZE, consider_xlink_ion):
    CSMs,mpTitleLines,header = utils.ReadpLink2PredictFile(path_predict_file)
    T,PT,L,L1,L2,S1,S2,X=GetPeptideFeatures(CSMs, consider_xlink_ion)
    predict_data_loader=utils.ConvertPredictDataToDataLoader(BATCH_SIZE, X, T, PT, L1, L2, S1, S2)
    return predict_data_loader,mpTitleLines,header


def PredictMS2(model, iterator):
    model.eval()
    mpPeaks={}
    mpSpecInfo={}

    for batch_x, batch_length,batch_title,batch_pt,batch_l1,batch_l2,batch_s1,batch_s2 in iterator:

        batch_x_pack = rnn_utils.pack_padded_sequence(batch_x, batch_length, batch_first=True)
        batch_x_pack = batch_x_pack.to(device)
        masked_y_pred,out_len = model.work(batch_x_pack)

        for title, pred, lseq, pt,l1,l2,s1,s2 in zip(batch_title,masked_y_pred,out_len, batch_pt,batch_l1,batch_l2,batch_s1,batch_s2):
            peaks=[]
            for i in range(lseq):
                peaks.append(pred[i].cpu().detach().numpy())
            peaks=np.array(peaks)
            peaks=np.transpose(peaks)
            mpPeaks[title]=peaks
            mpSpecInfo[title]=[pt,l1,l2,s1,s2]
    print('prediction done')
    return mpPeaks, mpSpecInfo


def WriteResultsToFile(path, mpPeaks, mpTitleLines, header, mpSpecInfo):
    fout=open(path,'w')
    fout.write(header+'\t')
    fout.write('seq1_pred_b1b2y1y2\tseq2_pred_b1b2y1y2\n')
    for title, peaks in mpPeaks.items():
        fout.write(mpTitleLines[title]+'\t')
        pt,l1,l2,s1,s2=mpSpecInfo[title] # 这里记录的l1和l2是序列的真实长度-1
        alpha_peaks=peaks[:,:l1].tolist()
        beta_peaks=peaks[:,l1+1:].tolist() # 跳过中间的交联剂输出

        # 与dta的格式一致，补齐无效的b离子和y离子，使得离子长度和肽段长度一致
        for idx in range(8):
            if idx%4<=1: # b ion
                alpha_peaks[idx].append(0.0) 
                beta_peaks[idx].append(0.0)
            else: # y ion
                alpha_peaks[idx].insert(0,0.0)
                beta_peaks[idx].insert(0,0.0)

        fout.write('\t'.join(map(str,[alpha_peaks]))+'\t')
        fout.write('\t'.join(map(str,[beta_peaks]))+'\n')
    fout.close()
    print('write done')

def Predict():

    BATCH_SIZE=1024

    print('Loading predicting data...')
    predict_data_loader,mpTitleLines,header=LoadPredictDataSet(BATCH_SIZE, consider_xlink_ion)

    INPUT_DIM = 130
    HIDDEN_DIM = 256
    OUTPUT_DIM = 8
    N_LAYERS = 2
    BIDIRECTIONAL = True
    DROPOUT = 0.5

    print('Loading pretrained model...')
    model = BiLSTMLinearPredictor(INPUT_DIM, HIDDEN_DIM, OUTPUT_DIM, N_LAYERS, BIDIRECTIONAL, DROPOUT)
    model.load_state_dict(torch.load(path_model,map_location=device))
    model = model.to(device)

    print('Predicting...')
    mpPeaks, mpSpecInfo=PredictMS2(model, predict_data_loader)

    print('Writing...')
    WriteResultsToFile(path_predict_ans_file, mpPeaks, mpTitleLines, header, mpSpecInfo)

if __name__ == "__main__":
    Predict()