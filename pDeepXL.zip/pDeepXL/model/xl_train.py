from xl_model import BiLSTMXLPredictor

import sys
sys.path.append("..")
import utils
import configparser
from tqdm import tqdm
import time
import os
import torch
torch.set_printoptions(profile="full")
import torch.autograd as autograd
import torch.nn as nn
import torch.optim as optim
import torch.nn.utils.rnn as rnn_utils
import logging
import numpy as np


path_data_home = r'/data/zlchen/pDeepXL/data/PXD008550/HumanFOMix_BS3'
path_match_formatted_pkl = r'%s/pLink2_data/pLink2.pkl'%path_data_home

path_result_home=r'/data/zlchen/pDeepXL/code/pDeepXL/pt/XL-%s'%time.strftime("%m%d-%H%M%S", time.localtime())
if not os.path.exists(path_result_home):
    os.makedirs(path_result_home)

device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')

logging.basicConfig(
    level=logging.INFO,
    format="[%(asctime)s][%(filename)s][line:%(lineno)d][%(levelname)s] %(message)s",
    handlers=[
        logging.FileHandler(r"%s/exp.log"%path_result_home),
        logging.StreamHandler()
    ]
)

logging.info('Start training...')


def TrainModel(model, iterator, optimizer):
    epoch_loss = 0
    model.train()
    sims=[]
    for batch_x1, batch_y1, batch_len1, batch_x2, batch_y2, batch_len2 in iterator:
        batch_x1, batch_y1, batch_len1 = batch_x1.to(device), batch_y1.to(device), batch_len1.to(device)
        batch_x2, batch_y2, batch_len2 = batch_x2.to(device), batch_y2.to(device), batch_len2.to(device)
        
        optimizer.zero_grad()
        predictions1, predictions2, loss = model(batch_x1, batch_y1, batch_len1, batch_x2, batch_y2, batch_len2)

        cursims=utils.CalXLSim(predictions1,batch_y1,batch_len1,predictions2,batch_y2,batch_len2)
        sims+=cursims

        epoch_loss += loss.item() # 多卡loss必须loss.sum()
        loss.backward()
        optimizer.step()
        
    sims_nan = np.array(sims)
    sims = sims_nan[np.isnan(sims_nan) == False]
    med = np.median(sims)
    avg = np.mean(sims)
    std = np.std(sims)

    return epoch_loss / len(iterator), sims, med, avg, std

def EvaluateModel(model, iterator):
    epoch_loss = 0
    model.eval()
    sims=[]
    with torch.no_grad():
    
        for batch_x1, batch_y1, batch_len1, batch_x2, batch_y2, batch_len2 in iterator:
            batch_x1, batch_y1, batch_len1 = batch_x1.to(device), batch_y1.to(device), batch_len1.to(device)
            batch_x2, batch_y2, batch_len2 = batch_x2.to(device), batch_y2.to(device), batch_len2.to(device)

            predictions1, predictions2, loss = model(batch_x1, batch_y1, batch_len1, batch_x2, batch_y2, batch_len2)
            
            cursims=utils.CalXLSim(predictions1,batch_y1,batch_len1,predictions2,batch_y2,batch_len2)
            sims+=cursims

            epoch_loss += loss.item() # 多卡loss必须loss.sum()

        sims_nan = np.array(sims)
        sims = sims_nan[np.isnan(sims_nan) == False]
        med = np.median(sims)
        avg = np.mean(sims)
        std = np.std(sims)

    return epoch_loss / len(iterator), sims, med, avg, std
        

def Train():

    BATCH_SIZE=1024

    logging.info('Loading training data...')
    train_loader, validation_loader=utils.LoadXLDataSet(path_match_formatted_pkl,BATCH_SIZE)

    INPUT_DIM = 119
    HIDDEN_DIM = 256
    OUTPUT_DIM = 4
    N_LAYERS = 2
    BIDIRECTIONAL = True
    DROPOUT = 0.5
    N_EPOCHS = 100
    
    model = BiLSTMXLPredictor(INPUT_DIM, HIDDEN_DIM, OUTPUT_DIM, N_LAYERS, BIDIRECTIONAL, DROPOUT)
    logging.info(f'The model has {utils.count_parameters(model):,} trainable parameters')

    path_pretrained='/data/zlchen/pDeepXL/code/pDeepXL/pt/Linear-0930-192737/epoch98-valloss0.0206-valmedianpcc0.9467.pt'
    # model.load_state_dict(torch.load(path_pretrained))

    lr=0.001
    optimizer = optim.Adam(model.parameters(), lr=lr)

    # model = nn.DataParallel(model, device_ids = [0,1,2,3]) # multi-GPU, 这样可以。
    # 同时loss.item()和loss.backward()改为loss.sum().item()和loss.sum().backward()
    model = model.to(device)

    best_valid_loss = float('inf')
    train_losses, valid_losses = [], []
    train_sim_meds, train_sim_avg, train_sim_std = [], [], []
    valid_sim_meds, valid_sim_avg, valid_sim_std = [], [], []
    train_sims, valid_sims=[], []
    for epoch in range(N_EPOCHS):

        start_time = time.time()
        
        train_loss, train_sims, train_med, train_avg, train_std = TrainModel(model, train_loader, optimizer)
        valid_loss, valid_sims, valid_med, valid_avg, valid_std = EvaluateModel(model, validation_loader)

        train_losses.append(train_loss)
        valid_losses.append(valid_loss)

        train_sim_meds.append(train_med)
        train_sim_avg.append(train_avg)
        train_sim_std.append(train_std)

        valid_sim_meds.append(valid_med)
        valid_sim_avg.append(valid_avg)
        valid_sim_std.append(valid_std)

        end_time = time.time()

        epoch_mins, epoch_secs = utils.epoch_time(start_time, end_time)
        
        if valid_loss < best_valid_loss:
            best_valid_loss = valid_loss
            logging.info('saving new best model...')
            torch.save(model.state_dict(), r'%s/epoch%d-valloss%.4f-valmedianpcc%.4f.pt'%(path_result_home,epoch,valid_loss,valid_med))

        logging.info(f'Epoch: {epoch+1:02} | Epoch Time: {epoch_mins}m {epoch_secs}s')
        logging.info(f'\tTrain Loss: {train_loss:.6f}, pcc: #non-nan=%d, median=%f, avg=%f, std=%f, lr=%f'%(len(train_sims), train_med, train_avg, train_std, optimizer.param_groups[0]['lr']))
        logging.info(f'\t Val. Loss: {valid_loss:.6f}, pcc: #non-nan=%d, median=%f, avg=%f, std=%f'%(len(valid_sims), valid_med, valid_avg, valid_std))

    utils.PlotWithEpoch(train_losses, valid_losses, path_result_home, 'loss')
    utils.PlotWithEpoch(train_sim_meds, valid_sim_meds, path_result_home, 'pcc median')
    utils.PlotWithEpoch(train_sim_avg, valid_sim_avg, path_result_home, 'pcc average')
    utils.PlotWithEpoch(train_sim_std, valid_sim_std, path_result_home, 'pcc std')

    utils.PlotSimPercentage(train_sims, valid_sims, path_result_home, 'pcc at the last epoch')
    logging.info('finish training!')


if __name__ == "__main__":
    Train()