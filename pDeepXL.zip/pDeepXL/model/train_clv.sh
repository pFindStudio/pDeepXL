#! /bin/sh


cd /data/zlchen/pDeepXL/code/pDeepXL/model

# CUDA_VISIBLE_DEVICES=3 python /data/zlchen/pDeepXL/code/pDeepXL/model/linear_train_clv_1e_2.py
CUDA_VISIBLE_DEVICES=2 python /data/zlchen/pDeepXL/code/pDeepXL/model/linear_train_clv30.py
CUDA_VISIBLE_DEVICES=2 python /data/zlchen/pDeepXL/code/pDeepXL/model/linear_train_clv49.py