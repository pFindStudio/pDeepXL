#! /bin/sh


cd /data/zlchen/pDeepXL/code/pDeepXL/model

# CUDA_VISIBLE_DEVICES=2 python linear_test.py path_match_formatted_pkl,path_result_home,path_model


CUDA_VISIBLE_DEVICES=2 python linear_test.py /data/zlchen/pDeepXL/data/PXD019926/DSS/8PM/pLink2_data/pLink2_filtered-2-no-xlion.pkl /data/zlchen/pDeepXL/code/pDeepXL/pt/XL-test-1031-2-no-xion-8PM-pretrained /data/zlchen/pDeepXL/code/pDeepXL/pt/Linear-1027-165109-big-linear4/epoch93-valloss0.0110-valmedianpcc0.9857.pt
CUDA_VISIBLE_DEVICES=2 python linear_test.py /data/zlchen/pDeepXL/data/PXD019926/DSS/8PM/pLink2_data/pLink2_filtered-2-no-xlion.pkl /data/zlchen/pDeepXL/code/pDeepXL/pt/XL-test-1031-2-no-xion-8PM-no-transfer /data/zlchen/pDeepXL/code/pDeepXL/pt/XL-1027-164724-2-no-xlion-no-transfer/epoch48-valloss0.0144-valmedianpcc0.9334.pt
CUDA_VISIBLE_DEVICES=2 python linear_test.py /data/zlchen/pDeepXL/data/PXD019926/DSS/8PM/pLink2_data/pLink2_filtered-2-no-xlion.pkl /data/zlchen/pDeepXL/code/pDeepXL/pt/XL-test-1031-2-no-xion-8PM-transfer /data/zlchen/pDeepXL/code/pDeepXL/pt/XL-1030-224347-2-no-xlion-transfer-pretrained100/epoch48-valloss0.0110-valmedianpcc0.9615.pt



CUDA_VISIBLE_DEVICES=2 python linear_test.py /data/zlchen/pDeepXL/data/Leiker_elife/6.C.elegans_lysates/N2/pLink2_data/pLink2_filtered-2-no-xlion.pkl /data/zlchen/pDeepXL/code/pDeepXL/pt/XL-test-1031-2-no-xion-leiker-worm-pretrained /data/zlchen/pDeepXL/code/pDeepXL/pt/Linear-1027-165109-big-linear4/epoch93-valloss0.0110-valmedianpcc0.9857.pt
CUDA_VISIBLE_DEVICES=2 python linear_test.py /data/zlchen/pDeepXL/data/Leiker_elife/6.C.elegans_lysates/N2/pLink2_data/pLink2_filtered-2-no-xlion.pkl /data/zlchen/pDeepXL/code/pDeepXL/pt/XL-test-1031-2-no-xion-leiker-worm-no-transfer /data/zlchen/pDeepXL/code/pDeepXL/pt/XL-1027-164724-2-no-xlion-no-transfer/epoch48-valloss0.0144-valmedianpcc0.9334.pt
CUDA_VISIBLE_DEVICES=2 python linear_test.py /data/zlchen/pDeepXL/data/Leiker_elife/6.C.elegans_lysates/N2/pLink2_data/pLink2_filtered-2-no-xlion.pkl /data/zlchen/pDeepXL/code/pDeepXL/pt/XL-test-1031-2-no-xion-leiker-worm-transfer /data/zlchen/pDeepXL/code/pDeepXL/pt/XL-1030-224347-2-no-xlion-transfer-pretrained100/epoch48-valloss0.0110-valmedianpcc0.9615.pt


CUDA_VISIBLE_DEVICES=2 python linear_test.py /data/zlchen/pDeepXL/data/PXD014337/QEx-HFX_DSS/pLink2_data/pLink2_filtered-2-no-xlion.pkl /data/zlchen/pDeepXL/code/pDeepXL/pt/XL-test-1031-2-no-xion-M-DSS-pretrained /data/zlchen/pDeepXL/code/pDeepXL/pt/Linear-1027-165109-big-linear4/epoch93-valloss0.0110-valmedianpcc0.9857.pt
CUDA_VISIBLE_DEVICES=2 python linear_test.py /data/zlchen/pDeepXL/data/PXD014337/QEx-HFX_DSS/pLink2_data/pLink2_filtered-2-no-xlion.pkl /data/zlchen/pDeepXL/code/pDeepXL/pt/XL-test-1031-2-no-xion-M-DSS-no-transfer /data/zlchen/pDeepXL/code/pDeepXL/pt/XL-1027-164724-2-no-xlion-no-transfer/epoch48-valloss0.0144-valmedianpcc0.9334.pt
CUDA_VISIBLE_DEVICES=2 python linear_test.py /data/zlchen/pDeepXL/data/PXD014337/QEx-HFX_DSS/pLink2_data/pLink2_filtered-2-no-xlion.pkl /data/zlchen/pDeepXL/code/pDeepXL/pt/XL-test-1031-2-no-xion-M-DSS-transfer /data/zlchen/pDeepXL/code/pDeepXL/pt/XL-1030-224347-2-no-xlion-transfer-pretrained100/epoch48-valloss0.0110-valmedianpcc0.9615.pt




CUDA_VISIBLE_DEVICES=2 python linear_test.py /data/zlchen/pDeepXL/data/pLink2_data/pLink2_filtered-2-no-xlion_test.pkl /data/zlchen/pDeepXL/code/pDeepXL/pt/XL-test-1031-2-no-xion-overall-test-pretrained /data/zlchen/pDeepXL/code/pDeepXL/pt/Linear-1027-165109-big-linear4/epoch93-valloss0.0110-valmedianpcc0.9857.pt
CUDA_VISIBLE_DEVICES=2 python linear_test.py /data/zlchen/pDeepXL/data/pLink2_data/pLink2_filtered-2-no-xlion_test.pkl /data/zlchen/pDeepXL/code/pDeepXL/pt/XL-test-1031-2-no-xion-overall-test-no-transfer /data/zlchen/pDeepXL/code/pDeepXL/pt/XL-1027-164724-2-no-xlion-no-transfer/epoch48-valloss0.0144-valmedianpcc0.9334.pt
CUDA_VISIBLE_DEVICES=2 python linear_test.py /data/zlchen/pDeepXL/data/pLink2_data/pLink2_filtered-2-no-xlion_test.pkl /data/zlchen/pDeepXL/code/pDeepXL/pt/XL-test-1031-2-no-xion-overall-test-transfer /data/zlchen/pDeepXL/code/pDeepXL/pt/XL-1030-224347-2-no-xlion-transfer-pretrained100/epoch48-valloss0.0110-valmedianpcc0.9615.pt





CUDA_VISIBLE_DEVICES=2 python linear_test.py /data/zlchen/pDeepXL/data/PXD008550/HumanFOMix_BS3/pLink2_data/pLink2_filtered-2-no-xlion.pkl /data/zlchen/pDeepXL/code/pDeepXL/pt/XL-test-1031-2-no-xion-Juri-K562-pretrained /data/zlchen/pDeepXL/code/pDeepXL/pt/Linear-1027-165109-big-linear4/epoch93-valloss0.0110-valmedianpcc0.9857.pt
CUDA_VISIBLE_DEVICES=2 python linear_test.py /data/zlchen/pDeepXL/data/PXD008550/HumanFOMix_BS3/pLink2_data/pLink2_filtered-2-no-xlion.pkl /data/zlchen/pDeepXL/code/pDeepXL/pt/XL-test-1031-2-no-xion-Juri-K562-no-transfer /data/zlchen/pDeepXL/code/pDeepXL/pt/XL-1027-164724-2-no-xlion-no-transfer/epoch48-valloss0.0144-valmedianpcc0.9334.pt
CUDA_VISIBLE_DEVICES=2 python linear_test.py /data/zlchen/pDeepXL/data/PXD008550/HumanFOMix_BS3/pLink2_data/pLink2_filtered-2-no-xlion.pkl /data/zlchen/pDeepXL/code/pDeepXL/pt/XL-test-1031-2-no-xion-Juri-K562-transfer /data/zlchen/pDeepXL/code/pDeepXL/pt/XL-1030-224347-2-no-xlion-transfer-pretrained100/epoch48-valloss0.0110-valmedianpcc0.9615.pt




CUDA_VISIBLE_DEVICES=2 python linear_test.py /data/zlchen/pDeepXL/data/PXD006626/pLink2_data/pLink2_filtered-2-no-xlion.pkl /data/zlchen/pDeepXL/code/pDeepXL/pt/XL-test-1031-2-no-xion-Juri-C-pretrained /data/zlchen/pDeepXL/code/pDeepXL/pt/Linear-1027-165109-big-linear4/epoch93-valloss0.0110-valmedianpcc0.9857.pt
CUDA_VISIBLE_DEVICES=2 python linear_test.py /data/zlchen/pDeepXL/data/PXD006626/pLink2_data/pLink2_filtered-2-no-xlion.pkl /data/zlchen/pDeepXL/code/pDeepXL/pt/XL-test-1031-2-no-xion-Juri-C-no-transfer /data/zlchen/pDeepXL/code/pDeepXL/pt/XL-1027-164724-2-no-xlion-no-transfer/epoch48-valloss0.0144-valmedianpcc0.9334.pt
CUDA_VISIBLE_DEVICES=2 python linear_test.py /data/zlchen/pDeepXL/data/PXD006626/pLink2_data/pLink2_filtered-2-no-xlion.pkl /data/zlchen/pDeepXL/code/pDeepXL/pt/XL-test-1031-2-no-xion-Juri-C-transfer /data/zlchen/pDeepXL/code/pDeepXL/pt/XL-1030-224347-2-no-xlion-transfer-pretrained100/epoch48-valloss0.0110-valmedianpcc0.9615.pt
