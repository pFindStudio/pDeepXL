import torch
import torch.nn as nn

batch_size = 2 # 批量长度
max_length = 3 # 序列最大长度
hidden_size = 4 # 隐藏层大小
n_layers = 1 # 层数

input_in = torch.tensor([[1., 2., 3.], [1., 0., 0.]]).unsqueeze(-1)
print(input_in.shape)

seq_length = [3, 1] # 序列实际长度

# pack it
input_pack = nn.utils.rnn.pack_padded_sequence(input_in, seq_length, batch_first=True)
print(input_pack)

# initialize
rnn = nn.RNN(1, hidden_size, n_layers, batch_first = True)
h0 = torch.randn(n_layers, batch_size, hidden_size)

# forward
out, hn = rnn(input_pack, h0)
print(out)
print(hn)

# unpack
out_unpack = nn.utils.rnn.pad_packed_sequence(out, batch_first=True)
print(out_unpack)

# 结果
# torch.Size([2, 3, 1])
# PackedSequence(data=tensor([[1.],
#         [1.],
#         [2.],
#         [3.]]), batch_sizes=tensor([2, 1, 1]), sorted_indices=None, unsorted_indices=None)
# PackedSequence(data=tensor([[ 0.4749,  0.7611,  0.4408, -0.2111],
#         [ 0.6702,  0.8201,  0.8219, -0.2639],
#         [-0.0240,  0.8901,  0.7451, -0.6310],
#         [ 0.0154,  0.9178,  0.8382, -0.7264]], grad_fn=<CatBackward>), batch_sizes=tensor([2, 1, 1]), sorted_indices=None, unsorted_indices=None)
# tensor([[[ 0.0154,  0.9178,  0.8382, -0.7264],
#          [ 0.6702,  0.8201,  0.8219, -0.2639]]], grad_fn=<StackBackward>)
# (tensor([[[ 0.4749,  0.7611,  0.4408, -0.2111],
#          [-0.0240,  0.8901,  0.7451, -0.6310],
#          [ 0.0154,  0.9178,  0.8382, -0.7264]],

#         [[ 0.6702,  0.8201,  0.8219, -0.2639],
#          [ 0.0000,  0.0000,  0.0000,  0.0000],
#          [ 0.0000,  0.0000,  0.0000,  0.0000]]], grad_fn=<TransposeBackward0>), tensor([3, 1]))