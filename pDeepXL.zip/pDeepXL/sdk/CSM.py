
class CSM:
    title=''
    scan=0
    charge=0
    instrument=0
    NCE_low,NCE_medium,NCE_high=0,0,0
    crosslinker=''
    seq1=''
    mods1={}
    linksite1=0
    seq2=''
    mods2={}
    linksite2=0
    seq1_matched_b1b2y1y2,seq2_matched_b1b2y1y2=[],[]
    def __init__(self, title,scan,charge,instrument,NCE_low,NCE_medium,NCE_high,crosslinker,
                seq1,mods1,linksite1,seq2,mods2,linksite2,
                seq1_matched_b1b2y1y2=[],seq2_matched_b1b2y1y2=[]):
                
        self.title = title
        self.scan = scan
        self.charge = charge
        self.instrument = instrument
        self.NCE_low = NCE_low
        self.NCE_medium = NCE_medium
        self.NCE_high = NCE_high
        self.crosslinker = crosslinker
        self.seq1 = seq1
        self.mods1 = mods1
        self.linksite1 = linksite1
        self.seq2 = seq2
        self.mods2 = mods2
        self.linksite2 = linksite2
        self.seq1_matched_b1b2y1y2 = seq1_matched_b1b2y1y2
        self.seq2_matched_b1b2y1y2 = seq2_matched_b1b2y1y2
    