
class PSM:
    title=''
    scan=0
    charge=0
    seq=''
    mods={}
    instrument=0
    NCE_low,NCE_medium,NCE_high=0,0,0
    matched_b1b2y1y2=[],[]
    def __init__(self, title,scan,charge,seq,mods,
                instrument,NCE_low,NCE_medium,NCE_high,
                matched_b1b2y1y2=[]):
                
        self.title = title
        self.scan = scan
        self.charge = charge
        self.seq = seq
        self.mods = mods
        self.instrument = instrument
        self.NCE_low = NCE_low
        self.NCE_medium = NCE_medium
        self.NCE_high = NCE_high
        self.matched_b1b2y1y2 = matched_b1b2y1y2
    