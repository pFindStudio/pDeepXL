# 把多个模型的测试结果放到一起画一个PCC曲线
import sys
sys.path.append("..")
import utils
import matplotlib
matplotlib.use('AGG')#或者PDF, SVG或PS
import matplotlib.pyplot as plt
import seaborn as sns
from matplotlib.ticker import MaxNLocator
import bisect
import post_utils

# non-clv
# pcsvs=[r'/data/zlchen/pDeepXL/code/pDeepXL/pt/XL-test-non-clv-1123-212434-overall-test-pretrained30/test_ans.csv',
#        r'/data/zlchen/pDeepXL/code/pDeepXL/pt/XL-test-non-clv-1123-212727-overall-test-no_transfer/test_ans.csv',
#        r'/data/zlchen/pDeepXL/code/pDeepXL/pt/XL-test-non-clv-1123-212811-overall-test-transfer30/test_ans.csv']

# clv
pcsvs=[r'/data/zlchen/pDeepXL/code/pDeepXL/pt/XL-test-clv-1123-212739-overall-test-pretrained30/test_ans.csv',
       r'/data/zlchen/pDeepXL/code/pDeepXL/pt/XL-test-clv-1123-213107-overall-test-no_transfer/test_ans.csv',
       r'/data/zlchen/pDeepXL/code/pDeepXL/pt/XL-test-clv-1123-213200-overall-test-transfer30/test_ans.csv']


csv_names=['linear','no transfer','transfer']
csv_colors=['r','g','b']

### non-clv
# pfig=r'/data/zlchen/pDeepXL/data/Leiker_elife/5.E.coli_lysates/pLink2_data/compare1210.svg'
# dataname='NotFound'
# fig_title='test set of E.coli-Dong-Leiker'

# pfig=r'/data/zlchen/pDeepXL/data/PXD019926/DSS/HEK293/pLink2_data/compare1210.svg'
# dataname='HEK293T-Liu-Linear1'
# fig_title='test set of HEK293T-Liu-DSS'


### clv
# pfig=r'/data/zlchen/pDeepXL/data/PXD019926/DSSO/HEK293/pLink2_data/compare1210.svg'
# dataname='HEK293T-Liu-Linear2'
# fig_title='test set of HEK293T-Liu-DSSO'


pfig=r'/data/zlchen/pDeepXL/data/PXD012546/pLink2_data/compare1210.svg'
dataname='D.melanogaster-Sinz-Linear'
fig_title='test set of D.melanogaster-Sinz-DSBU'


#----------fine tune test-------
#non clv
# pcsvs=[r'/data/zlchen/pDeepXL/code/pDeepXL/pt/XL-ft-test-non-clv-1129-194704-K562-pretrained30/test_ans.csv',
#        r'/data/zlchen/pDeepXL/code/pDeepXL/pt/XL-ft-test-non-clv-1129-194851-K562-transfer30/test_ans.csv',
#        r'/data/zlchen/pDeepXL/code/pDeepXL/pt/XL-ft-test-non-clv-1129-194946-K562-fine_tune/test_ans.csv',
#        r'/data/zlchen/pDeepXL/code/pDeepXL/pt/XL-ft-test-non-clv-1129-195035-K562-no_transfer_no_fine_tune/test_ans.csv']


# csv_names=['linear','transfer','fine-tune','no transfer & no fine-tune']
# csv_colors=['r','b','m','y']

# pfig=r'/data/zlchen/pDeepXL/code/pDeepXL/imgs/non-clv-fine-tune-test-compare1129.svg'
# dataname='NotFound'
# fig_title='test set of K562-Rappsilber-BS3'


#clv
# pcsvs=[r'/data/zlchen/pDeepXL/code/pDeepXL/pt/XL-ft-test-clv-1129-195102-Ecoli-pretrained30/test_ans.csv',
#        r'/data/zlchen/pDeepXL/code/pDeepXL/pt/XL-ft-test-clv-1129-195253-Ecoli-transfer30/test_ans.csv',
#        r'/data/zlchen/pDeepXL/code/pDeepXL/pt/XL-ft-test-clv-1129-195347-Ecoli-fine_tune/test_ans.csv',
#        r'/data/zlchen/pDeepXL/code/pDeepXL/pt/XL-ft-test-clv-1129-195442-Ecoli-no_transfer_no_fine_tune/test_ans.csv']


# csv_names=['linear','transfer','fine-tune','no transfer & no fine-tune']
# csv_colors=['r','b','m','y']

# pfig=r'/data/zlchen/pDeepXL/code/pDeepXL/imgs/clv-fine-tune-test-compare1129.svg'
# dataname='NotFound'
# fig_title='test set of E.coli-Mechtler-DSSO'

#----------

pccs_vec,percentages_vec=[],[]
min_pcc=0.0

for pcsv,name in zip(pcsvs,csv_names):
    print('path_test_ans=%s'%pcsv)
    mpData2PCCs=post_utils.get_data_pcc(pcsv)
    rawpccs=mpData2PCCs[dataname]

    filtered_sims, med, avg, std,ppcc75,ppcc90,pccs,percentages=post_utils.cal_metrics(rawpccs)
    min_pcc=min(min_pcc,min(pccs))
    pccs_vec.append(pccs)
    percentages_vec.append(percentages)
    print('dataname=%s, csvname=%s, #non-nan=%d, median=%f, avg=%f, std=%f, ppcc75=%f, ppcc90=%f'%(dataname, name,len(filtered_sims), med,avg,std,ppcc75,ppcc90))
    print(ppcc75,ppcc90,med)


plt.figure(figsize=(6, 4.8))
for name,color,pccs,percentages in zip(csv_names,csv_colors,pccs_vec,percentages_vec):
    pccs.insert(0,min_pcc)
    percentages.insert(0,1.0)

    pccs.append(1.0)
    percentages.append(0.0)
    ls='solid'
    if name=='transfer':   # 对于clv，transfer和no-transfer两条线几乎重合的情况
        ls='dotted'
    plt.plot(pccs, [p*100 for p in percentages],color,label=name,linestyle=ls)


plt.title(fig_title)
plt.legend(loc = 'lower left')

plt.xlabel('PCC = x')
# plt.ylabel('Percentage of PCCs >= x (%)')
plt.ylabel('P(PCC > x) (%)')
plt.savefig(pfig, format='svg', dpi=1200)
plt.savefig(pfig+'.png')