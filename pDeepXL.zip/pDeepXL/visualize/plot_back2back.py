# CSM匹配的背靠背图

import sys
sys.path.append("..")
import utils
import matplotlib
matplotlib.use('AGG')#或者PDF, SVG或PS
import matplotlib.pyplot as plt
import seaborn as sns
from matplotlib.ticker import MaxNLocator
import bisect
import post_utils
import mass_util
import configparser
import numpy as np

# title='B170523_09_Lumos_PR_IN_90_mito-DSS_14-15B17.18141.18141.3.0.dta'
# path_data_home=r'/data/zlchen/pDeepXL/data/PXD014675'
# path_pf2=r'%s/pf2/B170523_09_Lumos_PR_IN_90_mito-DSS_14-15B17_HCDFT.pf2'%path_data_home
# path_pred_ans=r'%s/pLink2_data/pLink2_match_info_filtered_test_ans.txt'%path_data_home
# path_fig=r'%s/pLink2_data/%s_back2back.png'%(path_data_home,title)


# title='B170110_05_Lumos_PR_IN_190_mito-DSS_18A18.22010.22010.4.0.dta'
# path_data_home=r'/data/zlchen/pDeepXL/data/PXD014675'
# path_pf2=r'%s/pf2/B170110_05_Lumos_PR_IN_190_mito-DSS_18A18_HCDFT.pf2'%path_data_home
# path_pred_ans=r'%s/pLink2_data/pLink2_match_info_filtered_test_ans.txt'%path_data_home
# path_fig=r'%s/pLink2_data/%s_back2back.png'%(path_data_home,title)


# title='B170110_03_Lumos_PR_IN_190_mito-DSS_18A16.22166.22166.4.1.dta'
# path_data_home=r'/data/zlchen/pDeepXL/data/PXD014675'
# path_pf2=r'%s/pf2/B170110_03_Lumos_PR_IN_190_mito-DSS_18A16_HCDFT.pf2'%path_data_home
# path_pred_ans=r'%s/pLink2_data/pLink2_match_info_filtered_test_ans.txt'%path_data_home
# path_fig=r'%s/pLink2_data/%s_back2back.png'%(path_data_home,title)


# title='HEK293_DSS_FAIMS_405060_Fr1.38722.38722.4.0.dta'
# path_data_home=r'/data/zlchen/pDeepXL/data/PXD019926/DSS/HEK293'
# path_pf2=r'%s/pf2/HEK293_DSS_FAIMS_405060_Fr1_HCDFT.pf2'%path_data_home
# path_pred_ans=r'%s/pLink2_data/pLink2_match_info_filtered_test_ans.txt'%path_data_home
# path_fig=r'%s/pLink2_data/%s_back2back.svg'%(path_data_home,title)


# title='E_bin3_7ul_re.14243.14243.4.0.dta'
# path_data_home=r'/data/zlchen/pDeepXL/data/Leiker_elife/5.E.coli_lysates/enri0228'
# path_pf2=r'%s/pf2/E_bin3_7ul_re_HCDFT.pf2'%path_data_home
# path_pred_ans=r'/data/zlchen/pDeepXL/data/pLink2_data/pLink2_match_info_filtered_test_ans.txt'
# path_fig=r'%s/pLink2_data/%s_back2back.svg'%(path_data_home,title)


# title='HEK293_DSS_FAIMS_4055_Fr1.37414.37414.4.0.dta'
# path_data_home=r'/data/zlchen/pDeepXL/data/PXD019926/DSS/HEK293'
# path_pf2=r'%s/pf2/HEK293_DSS_FAIMS_4055_Fr1_HCDFT.pf2'%path_data_home
# path_pred_ans=r'%s/pLink2_data/pLink2_match_info_filtered_test_ans.txt'%path_data_home
# path_fig=r'%s/pLink2_data/%s_back2back.png'%(path_data_home,title)


# title='C_Lee_010916_ymitos_BS3_XL_B3_B4_13_Rep2.9691.9691.3.0.dta'
# path_data_home=r'/data/zlchen/pDeepXL/data/PXD017620'
# path_pf2=r'%s/pf2/C_Lee_010916_ymitos_BS3_XL_B3_B4_13_Rep2_HCDFT.pf2'%path_data_home
# path_pred_ans=r'/data/zlchen/pDeepXL/data/pLink2_data/pLink2_match_info_filtered_test_ans.txt'
# path_fig=r'%s/pLink2_data/%s_back2back.png'%(path_data_home,title)



# title='IParfentev_030718_Ecoli_XL_DSS1_F24.12594.12594.3.0.dta'
# path_data_home=r'/data/zlchen/pDeepXL/data/PXD016554/DSS/B_cereus'
# path_pf2=r'%s/pf2/IParfentev_030718_Ecoli_XL_DSS1_F24_HCDFT.pf2'%path_data_home
# path_pred_ans=r'/data/zlchen/pDeepXL/data/pLink2_data/pLink2_match_info_filtered_test_ans.txt'
# path_fig=r'%s/pLink2_data/%s_back2back.png'%(path_data_home,title)


#----------------------可碎裂------------

title='HEK293_FAIMS_506075_Fr2_BioRep2.15511.15511.4.0.dta'
path_data_home=r'/data/zlchen/pDeepXL/data/PXD019926/DSSO/HEK293'
path_pf2=r'%s/pf2/HEK293_FAIMS_506075_Fr2_BioRep2_HCDFT.pf2'%path_data_home
path_pred_ans=r'/data/zlchen/pDeepXL/data/pLink_clv_data/pLink2_match_info_filtered_test_ans.txt'
path_fig=r'%s/pLink2_data/%s_back2back.svg'%(path_data_home,title)


# title='R1_A12.20952.20952.4.0.dta'
# path_data_home=r'/data/zlchen/pDeepXL/data/PXD012546'
# path_pf2=r'%s/pf2/R1_A12_HCDFT.pf2'%path_data_home
# path_pred_ans=r'/data/zlchen/pDeepXL/data/pLink_clv_data/pLink2_match_info_filtered_test_ans.txt'
# path_fig=r'%s/pLink2_data/%s_back2back.svg'%(path_data_home,title)

#----------------------可碎裂------------





config = configparser.ConfigParser()
config.read('/data/zlchen/pDeepXL/code/pDeepXL/config.ini')


# 不可碎裂
def pLink2_single_back2back(spec,pep_pair,pred_matrix, path_fig):
    spec_info,peaks=spec
    specname, prec_charge, precursor,max_inten=spec_info
    LinkerName,seq1,mods1,linksite1,seq2,mods2,linksite2=pep_pair
    alpha_preds,beta_preds=pred_matrix
    alpha_preds,beta_preds=alpha_preds[:4],beta_preds[:4]

    alpha_max_int=max([max(i) for i in alpha_preds])
    beta_max_int=max([max(i) for i in beta_preds])
    max_pred_int=max(alpha_max_int,beta_max_int)
    
    l1,l2=len(seq1),len(seq2)

    b1mass1,b2mass1,y1mass1,y2mass1,b1mass2,b2mass2,y1mass2,y2mass2=mass_util.calfragmass4xl(seq1,mods1,linksite1,seq2,mods2,linksite2,LinkerName)

    alpha_ions=[b1mass1,b2mass1,y1mass1,y2mass1]
    beta_ions=[b1mass2,b2mass2,y1mass2,y2mass2]

    ion_charges=(1,2,1,2)
    ion_names=('b+','b++','y+','y++')
    ion_colors=('green','blue','red','orange')

    plt.figure(figsize=(15,8))
    # plt.figure(figsize=(10,8))

    max_exp_intensity=max(peaks, key=lambda x:x[1])[1]
    max_exp_relative_intensity=0
    non_matched_pids=set()
    for pid,(exp_mz,intensity) in enumerate(peaks):
        matched=False
        # match alpha
        for ion_mzs, ion_charge, ion_name, ion_color in zip(alpha_ions, ion_charges, ion_names, ion_colors):
            if prec_charge == 2 and ion_charge == 2:
                continue
            for pos,theo_mz in enumerate(ion_mzs):
                if utils.calppm(theo_mz*ion_charge,exp_mz*ion_charge)<=float(config['DEFAULT']['ppm_ms2']):
                    relative_intensity=intensity/max_exp_intensity
                    max_exp_relative_intensity=max(max_exp_relative_intensity,relative_intensity)
                    ion_pos= pos+1 if ion_name[0]=='b' else l1-pos
                    ion_txt='α%s%d%s'%(ion_name[0],ion_pos,ion_name[1:])
                    plt.plot([theo_mz,theo_mz], [0, relative_intensity], color=ion_color, lw=2)
                    plt.text(theo_mz, relative_intensity + 0.05, ion_txt, rotation = 90, color=ion_color, horizontalalignment="center",verticalalignment='bottom')
                    matched=True

        # match beta
        for ion_mzs, ion_charge, ion_name, ion_color in zip(beta_ions, ion_charges, ion_names, ion_colors):
            if prec_charge == 2 and ion_charge == 2:
                continue
            for pos,theo_mz in enumerate(ion_mzs):
                if utils.calppm(theo_mz*ion_charge,exp_mz*ion_charge)<=float(config['DEFAULT']['ppm_ms2']):
                    relative_intensity=intensity/max_exp_intensity
                    max_exp_relative_intensity=max(max_exp_relative_intensity,relative_intensity)
                    ion_pos= pos+1 if ion_name[0]=='b' else l2-pos
                    ion_txt='β%s%d%s'%(ion_name[0],ion_pos,ion_name[1:])
                    plt.plot([theo_mz,theo_mz], [0, relative_intensity], color=ion_color, lw=2)
                    plt.text(theo_mz, relative_intensity + 0.05, ion_txt, rotation = 90, color=ion_color, horizontalalignment="center",verticalalignment='bottom')
                    matched=True
        
        if not matched:
            non_matched_pids.add(pid)
    
    for pid in non_matched_pids:
        exp_mz,intensity=peaks[pid]
        relative_intensity=intensity/max_exp_intensity
        plt.plot([exp_mz,exp_mz], [0, relative_intensity], color='lightgray', lw=0.5)



    # plot pred spec

    # match alpha
    for ion_mzs, ion_charge, ion_name, ion_color,pred_intens in zip(alpha_ions, ion_charges, ion_names, ion_colors, alpha_preds):
        if prec_charge == 2 and ion_charge == 2:
            continue
        for pos,(theo_mz,pred_inten) in enumerate(zip(ion_mzs,pred_intens)):
            if pred_inten==0.0 or pred_inten==0:
                continue
            relative_intensity=max_exp_relative_intensity*pred_inten/max_pred_int
            ion_pos= pos+1 if ion_name[0]=='b' else l1-pos
            ion_txt='α%s%d%s'%(ion_name[0],ion_pos,ion_name[1:])
            plt.plot([theo_mz,theo_mz], [0, -relative_intensity], color=ion_color, lw=2)
            plt.text(theo_mz, -relative_intensity - 0.25, ion_txt, rotation = 90, color=ion_color, horizontalalignment="center",verticalalignment='bottom')

    # match beta
    for ion_mzs, ion_charge, ion_name, ion_color,pred_intens in zip(beta_ions, ion_charges, ion_names, ion_colors, beta_preds):
        if prec_charge == 2 and ion_charge == 2:
            continue
        for pos,(theo_mz,pred_inten) in enumerate(zip(ion_mzs,pred_intens)):
            if pred_inten==0.0 or pred_inten==0:
                continue
            relative_intensity=max_exp_relative_intensity*pred_inten/max_pred_int
            ion_pos= pos+1 if ion_name[0]=='b' else l2-pos
            ion_txt='β%s%d%s'%(ion_name[0],ion_pos,ion_name[1:])
            plt.plot([theo_mz,theo_mz], [0, -relative_intensity], color=ion_color, lw=2)
            plt.text(theo_mz, -relative_intensity - 0.25, ion_txt, rotation = 90, color=ion_color, horizontalalignment="center",verticalalignment='bottom')


    # minx,maxx=150,1600
    minx,maxx=100,900
    plt.plot([0,maxx],[0,0],color='black',lw=0.5)

    # plt.title(fig_title)
    # plt.legend()

    plt.xlim(minx,maxx)
    plt.ylim(-1.5, 1.5)

    # 修改纵坐标
    ax = plt.gca()
    labels = ['150%','100%','50%','0','50%','100%','150%']
    ax.set_yticklabels(labels)


    plt.xlabel('m/z')
    plt.ylabel('Relative Abundance')
    plt.savefig(path_fig, format='svg', dpi=1200)
    plt.savefig(path_fig+'.png')




# 可碎裂
def pLink_clv_single_back2back(spec,pep_pair,pred_matrix, path_fig):
    spec_info,peaks=spec
    specname, prec_charge, precursor,max_inten=spec_info
    LinkerName,seq1,mods1,linksite1,seq2,mods2,linksite2=pep_pair
    alpha_preds,beta_preds=pred_matrix

    alpha_max_int=max([max(i) for i in alpha_preds])
    beta_max_int=max([max(i) for i in beta_preds])
    max_pred_int=max(alpha_max_int,beta_max_int)
    
    l1,l2=len(seq1),len(seq2)

    # 把8维拆开为12维，和下面的ion_names对应
    alpha_preds=np.array(alpha_preds)
    alpha_preds_expended=np.zeros([12,l1])
    alpha_preds_expended[0:2,0:linksite1]=alpha_preds[0:2,0:linksite1] # regular b
    alpha_preds_expended[2:4,linksite1+1:]=alpha_preds[2:4,linksite1+1:] # regular y
    alpha_preds_expended[4:6,linksite1:]=alpha_preds[0:2,linksite1:] # clv-long b
    alpha_preds_expended[6:8,0:linksite1+1]=alpha_preds[2:4,0:linksite1+1] # clv-long y
    alpha_preds_expended[8:12,:]=alpha_preds[4:8,:] # clv-short
    alpha_preds=alpha_preds_expended.tolist()

    beta_preds=np.array(beta_preds)
    beta_preds_expended=np.zeros([12,l2])
    beta_preds_expended[0:2,0:linksite2]=beta_preds[0:2,0:linksite2] # regular b
    beta_preds_expended[2:4,linksite2+1:]=beta_preds[2:4,linksite2+1:] # regular y
    beta_preds_expended[4:6,linksite2:]=beta_preds[0:2,linksite2:] # clv-long b
    beta_preds_expended[6:8,0:linksite2+1]=beta_preds[2:4,0:linksite2+1] # clv-long y
    beta_preds_expended[8:12,:]=beta_preds[4:8,:] # clv-short
    beta_preds=beta_preds_expended.tolist()
    #################################


    alpha_ions=mass_util.calfragmass4clv(seq1,LinkerName,linksite1,mods1)
    beta_ions=mass_util.calfragmass4clv(seq2,LinkerName,linksite2,mods2)

    ion_charges=(1,2,1,2,1,2,1,2,1,2,1,2)
    #ion_names=('linear_b1','linear_b2','linear_y1','linear_y2','clv_long_b1','clv_long_b2','clv_long_y1','clv_long_y2','clv_short_b1','clv_short_b2','clv_short_y1','clv_short_y2')
    ion_names=('b+','b++','y+','y++','Lb+','Lb++','Ly+','Ly++','Sb+','Sb++','Sy+','Sy++')
    ion_colors=('green','blue','red','orange','green','blue','red','orange','green','blue','red','orange')

    plt.figure(figsize=(15,8))
    # plt.figure(figsize=(10,8))

    max_exp_intensity=max(peaks, key=lambda x:x[1])[1]
    max_exp_relative_intensity=0
    non_matched_pids=set()
    for pid,(exp_mz,intensity) in enumerate(peaks):
        matched=False
        # match alpha
        for ion_mzs, ion_charge, ion_name, ion_color in zip(alpha_ions, ion_charges, ion_names, ion_colors):
            if prec_charge == 2 and ion_charge == 2:
                continue
            for pos,theo_mz in enumerate(ion_mzs):
                if utils.calppm(theo_mz*ion_charge,exp_mz*ion_charge)<=float(config['DEFAULT']['ppm_ms2']):
                    relative_intensity=intensity/max_exp_intensity
                    max_exp_relative_intensity=max(max_exp_relative_intensity,relative_intensity)
                    ion_pos= pos+1 if 'b' in ion_name else l1-pos
                    ion_txt='α%s%d%s'%(ion_name.split('+')[0],ion_pos,'+'*ion_charge)
                    plt.plot([theo_mz,theo_mz], [0, relative_intensity], color=ion_color, lw=2)
                    plt.text(theo_mz, relative_intensity + 0.05, ion_txt, rotation = 90, color=ion_color, horizontalalignment="center",verticalalignment='bottom')
                    matched=True

        # match beta
        for ion_mzs, ion_charge, ion_name, ion_color in zip(beta_ions, ion_charges, ion_names, ion_colors):
            if prec_charge == 2 and ion_charge == 2:
                continue
            for pos,theo_mz in enumerate(ion_mzs):
                if utils.calppm(theo_mz*ion_charge,exp_mz*ion_charge)<=float(config['DEFAULT']['ppm_ms2']):
                    relative_intensity=intensity/max_exp_intensity
                    max_exp_relative_intensity=max(max_exp_relative_intensity,relative_intensity)
                    ion_pos= pos+1 if 'b' in ion_name else l2-pos
                    ion_txt='β%s%d%s'%(ion_name.split('+')[0],ion_pos,'+'*ion_charge)
                    plt.plot([theo_mz,theo_mz], [0, relative_intensity], color=ion_color, lw=2)
                    plt.text(theo_mz, relative_intensity + 0.05, ion_txt, rotation = 90, color=ion_color, horizontalalignment="center",verticalalignment='bottom')
                    matched=True
        
        if not matched:
            non_matched_pids.add(pid)
    
    for pid in non_matched_pids:
        exp_mz,intensity=peaks[pid]
        relative_intensity=intensity/max_exp_intensity
        plt.plot([exp_mz,exp_mz], [0, relative_intensity], color='lightgray', lw=0.5)



    # plot pred spec
    # match alpha
    for ion_mzs, ion_charge, ion_name, ion_color,pred_intens in zip(alpha_ions, ion_charges, ion_names, ion_colors, alpha_preds):
        if prec_charge == 2 and ion_charge == 2:
            continue
        for pos,(theo_mz,pred_inten) in enumerate(zip(ion_mzs,pred_intens)):
            if pred_inten==0.0 or pred_inten==0:
                continue
            relative_intensity=max_exp_relative_intensity*pred_inten/max_pred_int
            ion_pos= pos+1 if 'b' in ion_name else l1-pos
            ion_txt='α%s%d%s'%(ion_name.split('+')[0],ion_pos,'+'*ion_charge)
            margin=0.25
            if ion_pos>=10 or ion_charge==2:
                margin=0.3
            plt.plot([theo_mz,theo_mz], [0, -relative_intensity], color=ion_color, lw=2)
            plt.text(theo_mz, -relative_intensity - margin, ion_txt, rotation = 90, color=ion_color, horizontalalignment="center",verticalalignment='bottom')

    # match beta
    for ion_mzs, ion_charge, ion_name, ion_color,pred_intens in zip(beta_ions, ion_charges, ion_names, ion_colors, beta_preds):
        if prec_charge == 2 and ion_charge == 2:
            continue
        for pos,(theo_mz,pred_inten) in enumerate(zip(ion_mzs,pred_intens)):
            if pred_inten==0.0 or pred_inten==0:
                continue
            relative_intensity=max_exp_relative_intensity*pred_inten/max_pred_int
            ion_pos= pos+1 if 'b' in ion_name else l2-pos
            ion_txt='β%s%d%s'%(ion_name.split('+')[0],ion_pos,'+'*ion_charge)
            margin=0.25
            if ion_pos>=10 or ion_charge==2:
                margin=0.3
            plt.plot([theo_mz,theo_mz], [0, -relative_intensity], color=ion_color, lw=2)
            plt.text(theo_mz, -relative_intensity - margin, ion_txt, rotation = 90, color=ion_color, horizontalalignment="center",verticalalignment='bottom')




    minx,maxx=180,1050
    # minx,maxx=190,1650
    plt.plot([0,maxx],[0,0],color='black',lw=0.5)

    # plt.title(fig_title)
    # plt.legend()

    plt.xlim(minx,maxx)
    plt.ylim(-1.5, 1.5)

    # 修改纵坐标
    ax = plt.gca()
    labels = ['150%','100%','50%','0','50%','100%','150%']
    ax.set_yticklabels(labels)


    plt.xlabel('m/z')
    plt.ylabel('Relative Abundance')
    plt.savefig(path_fig, format='svg', dpi=1200)
    plt.savefig(path_fig+'.png')




def pLink2_back2back(path_pf2, path_pred_ans, title, path_fig):
    pf2title, mpSpec = utils.load_pf2(path_pf2)
    CSMs,mpTitleLines,header=utils.ReadpLink2MatchInfoFile(path_pred_ans)
    spec=mpSpec[title]

    if 'Leiker' in path_pf2:
        title='ecoli_enri0228_'+title

    line=mpTitleLines[title]
    contents=line.strip().split('\t')

    pep_pair=contents[7:14]
    eval_idxs=set([2,3,5,6])
    for i in range(len(pep_pair)):
        if i in eval_idxs:
            pep_pair[i]=eval(pep_pair[i])
    
    LinkerName=pep_pair[0]
    if LinkerName=='DSSO' or LinkerName=='DSBU':
        pLink_clv_single_back2back(spec,pep_pair,[eval(contents[-2]), eval(contents[-1])], path_fig)
    else:
        pLink2_single_back2back(spec,pep_pair,[eval(contents[-2]), eval(contents[-1])], path_fig)



pLink2_back2back(path_pf2, path_pred_ans, title, path_fig)