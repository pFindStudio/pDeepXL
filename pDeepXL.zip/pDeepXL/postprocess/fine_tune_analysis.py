# 分析fine tune的结果
import sys
sys.path.append("..")
import utils
import matplotlib
matplotlib.use('AGG')#或者PDF, SVG或PS
import matplotlib.pyplot as plt
import seaborn as sns
from matplotlib.ticker import MaxNLocator
import numpy as np


#############################################################################################
# 1. 固定n=25%，选择不同epoch

# path_logs=[r'/data/zlchen/pDeepXL/code/pDeepXL/pt/XL-ft-non-clv-K562-1128-174500-n200/exp.log',
#            r'/data/zlchen/pDeepXL/code/pDeepXL/pt/XL-ft-clv-Ecoli-1128-180812-n200/exp.log']

# 1. 固定n=25%，选择不同epoch
# path_logs=[r'/data/zlchen/pDeepXL/code/pDeepXL/pt/XL-ft-non-clv-K562-1129-103813-n25/exp.log',
#            r'/data/zlchen/pDeepXL/code/pDeepXL/pt/XL-ft-clv-Ecoli-1129-104750-n25/exp.log']

# 1. 固定n=35%，选择不同epoch
path_logs=[r'/data/zlchen/pDeepXL/code/pDeepXL/pt/XL-ft-non-clv-K562-1129-103958-n35/exp.log',
           r'/data/zlchen/pDeepXL/code/pDeepXL/pt/XL-ft-clv-Ecoli-1129-105343-n35/exp.log']


data_names=['K562-Rappsilber-BS3','E.coli-Mechtler-DSSO']
colors=['r','g']
markers=['o','v']

init_pcc75s=[0.966553,0.907832]
init_pcc90s=[0.776077,0.656698]

path_pcc75_img=r'/data/zlchen/pDeepXL/code/pDeepXL/imgs/1129-n35-pcc75.svg'
path_pcc90_img=r'/data/zlchen/pDeepXL/code/pDeepXL/imgs/1129-n35-pcc90.svg'


epochs=[]

pcc75_values=[]
pcc90_values=[]

for p,init_pcc75,init_pcc90 in zip(path_logs,init_pcc75s,init_pcc90s):
    train_info,val_info=utils.ParseTrainLog(p, True)
    es=[0]
    pcc75s,pcc90s=[init_pcc75],[init_pcc90]
    for contents in val_info:
        if contents[0] > 15: # 只取前15个epoch
            continue
        es.append(contents[0])
        pcc75s.append(contents[6])
        pcc90s.append(contents[7])
    epochs.append(es)
    pcc75_values.append(pcc75s)
    pcc90_values.append(pcc90s)



plt.figure(figsize=(6, 4.8))
for name,es,pcc75s,c,m in zip(data_names,epochs,pcc75_values,colors,markers):
    plt.plot(es, pcc75s,c,label=name,marker=m)

plt.legend(loc = 'lower right')

plt.xlim(-0.5, 15.5)
plt.ylim(0.9, 0.98)
plt.yticks([i*0.01 for i in range(90,99,1)])

# 修改纵坐标
ax = plt.gca()
labels = ['%d'%i for i in range(90,99,1)]
ax.set_yticklabels(labels)


plt.xlabel('# epochs')
plt.ylabel('P(PCC>0.75) (%)')
plt.savefig(path_pcc75_img, format='svg', dpi=1200)
plt.savefig(path_pcc75_img+'.png')

#-------------------
plt.figure(figsize=(6, 4.8))
for name,es,pcc90s,c,m in zip(data_names,epochs,pcc90_values,colors,markers):
    plt.plot(es, pcc90s ,c,label=name,marker=m)

plt.legend(loc = 'lower right')

plt.xlim(-0.5, 15.5)
plt.ylim(0.65, 0.9)
# plt.yticks(np.arange(0.65,0.86,0.025))

# 修改纵坐标
ax = plt.gca()
labels = ['%d'%(i) for i in range(65,91,5)]
ax.set_yticklabels(labels)

plt.xlabel('# epochs')
plt.ylabel('P(PCC>0.90) (%)')
plt.savefig(path_pcc90_img, format='svg', dpi=1200)
plt.savefig(path_pcc90_img+'.png')
#############################################################################################






#############################################################################################
# 2. epoch=10，用不同规模的数据进行fine-tune

# train_nums=[50,100,200,300,400,500]

# path_logs=[[r'/data/zlchen/pDeepXL/code/pDeepXL/pt/XL-ft-non-clv-K562-1128-173930-n50/exp.log',
#             r'/data/zlchen/pDeepXL/code/pDeepXL/pt/XL-ft-non-clv-K562-1128-174122-n100/exp.log',
#             r'/data/zlchen/pDeepXL/code/pDeepXL/pt/XL-ft-non-clv-K562-1128-174500-n200/exp.log',
#             r'/data/zlchen/pDeepXL/code/pDeepXL/pt/XL-ft-non-clv-K562-1128-174852-n300/exp.log',
#             r'/data/zlchen/pDeepXL/code/pDeepXL/pt/XL-ft-non-clv-K562-1128-230758-n400/exp.log',
#             r'/data/zlchen/pDeepXL/code/pDeepXL/pt/XL-ft-non-clv-K562-1128-175053-n500/exp.log'],
#            [r'/data/zlchen/pDeepXL/code/pDeepXL/pt/XL-ft-clv-Ecoli-1128-175018-n50/exp.log',
#            r'/data/zlchen/pDeepXL/code/pDeepXL/pt/XL-ft-clv-Ecoli-1128-175638-n100/exp.log',
#            r'/data/zlchen/pDeepXL/code/pDeepXL/pt/XL-ft-clv-Ecoli-1128-180812-n200/exp.log',
#            r'/data/zlchen/pDeepXL/code/pDeepXL/pt/XL-ft-clv-Ecoli-1128-181946-n300/exp.log',
#            r'/data/zlchen/pDeepXL/code/pDeepXL/pt/XL-ft-clv-Ecoli-1128-231813-n400/exp.log',
#            r'/data/zlchen/pDeepXL/code/pDeepXL/pt/XL-ft-clv-Ecoli-1128-182604-n500/exp.log']]



train_nums=[i*0.01 for i in range(5,80,10)]

path_logs=[[r'/data/zlchen/pDeepXL/code/pDeepXL/pt/XL-ft-non-clv-K562-1129-103432-n5/exp.log',
            r'/data/zlchen/pDeepXL/code/pDeepXL/pt/XL-ft-non-clv-K562-1129-103621-n15/exp.log',
            r'/data/zlchen/pDeepXL/code/pDeepXL/pt/XL-ft-non-clv-K562-1129-103813-n25/exp.log',
            r'/data/zlchen/pDeepXL/code/pDeepXL/pt/XL-ft-non-clv-K562-1129-103958-n35/exp.log',
            r'/data/zlchen/pDeepXL/code/pDeepXL/pt/XL-ft-non-clv-K562-1129-104153-n45/exp.log',
            r'/data/zlchen/pDeepXL/code/pDeepXL/pt/XL-ft-non-clv-K562-1129-104346-n55/exp.log',
            r'/data/zlchen/pDeepXL/code/pDeepXL/pt/XL-ft-non-clv-K562-1129-104537-n65/exp.log',
            r'/data/zlchen/pDeepXL/code/pDeepXL/pt/XL-ft-non-clv-K562-1129-104727-n75/exp.log'],
           [r'/data/zlchen/pDeepXL/code/pDeepXL/pt/XL-ft-clv-Ecoli-1129-103533-n5/exp.log',
           r'/data/zlchen/pDeepXL/code/pDeepXL/pt/XL-ft-clv-Ecoli-1129-104143-n15/exp.log',
           r'/data/zlchen/pDeepXL/code/pDeepXL/pt/XL-ft-clv-Ecoli-1129-104750-n25/exp.log',
           r'/data/zlchen/pDeepXL/code/pDeepXL/pt/XL-ft-clv-Ecoli-1129-105343-n35/exp.log',
           r'/data/zlchen/pDeepXL/code/pDeepXL/pt/XL-ft-clv-Ecoli-1129-105956-n45/exp.log',
           r'/data/zlchen/pDeepXL/code/pDeepXL/pt/XL-ft-clv-Ecoli-1129-110549-n55/exp.log',
           r'/data/zlchen/pDeepXL/code/pDeepXL/pt/XL-ft-clv-Ecoli-1129-111149-n65/exp.log',
           r'/data/zlchen/pDeepXL/code/pDeepXL/pt/XL-ft-clv-Ecoli-1129-111802-n75/exp.log']]


path_logs=[[r'/data/zlchen/pDeepXL/code/pDeepXL/pt/XL-ft-non-clv-K562-1129-103432-n5/exp.log',
            r'/data/zlchen/pDeepXL/code/pDeepXL/pt/XL-ft-non-clv-K562-1129-103621-n15/exp.log',
            r'/data/zlchen/pDeepXL/code/pDeepXL/pt/XL-ft-non-clv-K562-1129-103813-n25/exp.log',
            r'/data/zlchen/pDeepXL/code/pDeepXL/pt/XL-ft-non-clv-K562-1129-103958-n35/exp.log',
            r'/data/zlchen/pDeepXL/code/pDeepXL/pt/XL-ft-non-clv-K562-1129-104153-n45/exp.log',
            r'/data/zlchen/pDeepXL/code/pDeepXL/pt/XL-ft-non-clv-K562-1129-165851-n55/exp.log',
            r'/data/zlchen/pDeepXL/code/pDeepXL/pt/XL-ft-non-clv-K562-1129-170045-n65/exp.log',
            r'/data/zlchen/pDeepXL/code/pDeepXL/pt/XL-ft-non-clv-K562-1129-104727-n75/exp.log'],
           [r'/data/zlchen/pDeepXL/code/pDeepXL/pt/XL-ft-clv-Ecoli-1129-103533-n5/exp.log',
           r'/data/zlchen/pDeepXL/code/pDeepXL/pt/XL-ft-clv-Ecoli-1129-104143-n15/exp.log',
           r'/data/zlchen/pDeepXL/code/pDeepXL/pt/XL-ft-clv-Ecoli-1129-104750-n25/exp.log',
           r'/data/zlchen/pDeepXL/code/pDeepXL/pt/XL-ft-clv-Ecoli-1129-105343-n35/exp.log',
           r'/data/zlchen/pDeepXL/code/pDeepXL/pt/XL-ft-clv-Ecoli-1129-105956-n45/exp.log',
           r'/data/zlchen/pDeepXL/code/pDeepXL/pt/XL-ft-clv-Ecoli-1129-110549-n55/exp.log',
           r'/data/zlchen/pDeepXL/code/pDeepXL/pt/XL-ft-clv-Ecoli-1129-111149-n65/exp.log',
           r'/data/zlchen/pDeepXL/code/pDeepXL/pt/XL-ft-clv-Ecoli-1129-111802-n75/exp.log']]


# train_nums=train_nums[:6]
# path_logs=[i[:6] for i in path_logs]

data_names=['K562-Rappsilber-BS3','E.coli-Mechtler-DSSO']
colors=['r','g']
markers=['o','v']

init_pcc75s=[0.966553,0.907832]
init_pcc90s=[0.776077,0.656698]

target_epoch=10# 提取该epoch结果

path_pcc75_img=r'/data/zlchen/pDeepXL/code/pDeepXL/imgs/1129-epoch%d-pcc75.svg'%target_epoch
path_pcc90_img=r'/data/zlchen/pDeepXL/code/pDeepXL/imgs/1129-epoch%d-pcc90.svg'%target_epoch


tns=[0]+train_nums
pcc75_values=[]
pcc90_values=[]


for i,paths in enumerate(path_logs):
    pcc75s,pcc90s=[init_pcc75s[i]],[init_pcc90s[i]]
    for p in paths:
        train_info,val_info=utils.ParseTrainLog(p, True)
        smoothed_75,smoothed_90=pcc75s[-1],pcc90s[-1]
        for contents in val_info:
            if contents[0]==target_epoch: 
                # smoothed_75=contents[6] # 不平滑
                # smoothed_90=contents[7]

                smoothed_75=max(smoothed_75,contents[6]) # 平滑操作
                smoothed_90=max(smoothed_90,contents[7])
                break
        pcc75s.append(smoothed_75)
        pcc90s.append(smoothed_90)
    
    pcc75_values.append(pcc75s)
    pcc90_values.append(pcc90s)


print(pcc75_values[0])
print(pcc90_values[0])

plt.figure(figsize=(6, 4.8))
for name,pcc75s,c,m in zip(data_names,pcc75_values,colors,markers):
    plt.plot(tns, pcc75s,c,label=name,marker=m)

plt.legend(loc = 'lower right')

# plt.xlim(0, 400)
plt.ylim(0.9, 0.98)
xlabels=[0]+[i*0.01 for i in range(5,80,10)]
plt.xticks(xlabels)

# # 修改纵坐标
ax = plt.gca()
labels = ['%d'%i for i in range(90,99,1)]
ax.set_yticklabels(labels)

xlabels_str = ['%d'%(i*100) for i in xlabels]
ax.set_xticklabels(xlabels_str)

plt.xlabel('precursors for fine-tuning (%)')
plt.ylabel('P(PCC>0.75) (%)')
plt.savefig(path_pcc75_img, format='svg', dpi=1200)
plt.savefig(path_pcc75_img+'.png')

#-------------------
plt.figure(figsize=(6, 4.8))
for name,pcc90s,c,m in zip(data_names,pcc90_values,colors,markers):
    plt.plot(tns, pcc90s ,c,label=name,marker=m)

plt.legend(loc = 'lower right')

# plt.xlim(-0.02, 0.67)
plt.ylim(0.65, 0.9)
# plt.xticks(range(0,20,2))
plt.xticks(xlabels)

# # 修改纵坐标
ax = plt.gca()
labels = ['%d'%(i) for i in range(65,91,5)]
ax.set_yticklabels(labels)

xlabels_str = ['%d'%(i*100) for i in xlabels]
ax.set_xticklabels(xlabels_str)


plt.xlabel('precursors for fine-tuning (%)')
plt.ylabel('P(PCC>0.90) (%)')
plt.savefig(path_pcc90_img, format='svg', dpi=1200)
plt.savefig(path_pcc90_img+'.png')

#############################################################################################