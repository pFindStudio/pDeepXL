# 分析pLink-clv的测试结果文件

import sys
sys.path.append("..")
import post_utils


path_test_ans=r'/data/zlchen/pDeepXL/code/pDeepXL/pt/XL-test-clv-1123-212739-overall-test-pretrained30/test_ans.csv'
path_test_ans=r'/data/zlchen/pDeepXL/code/pDeepXL/pt/XL-test-clv-1123-213107-overall-test-no_transfer/test_ans.csv'
path_test_ans=r'/data/zlchen/pDeepXL/code/pDeepXL/pt/XL-test-clv-1123-213200-overall-test-transfer30/test_ans.csv'



print('path_test_ans=%s'%path_test_ans)
mpData2PCCs=post_utils.get_data_pcc(path_test_ans)

for dataname, pccs in mpData2PCCs.items():
    filtered_sims, med, avg, std,ppcc75,ppcc90,pccs,percentages=post_utils.cal_metrics(pccs)
    print('dataname=%s, #non-nan=%d, median=%f, avg=%f, std=%f, ppcc75=%f, ppcc90=%f'%(dataname,len(filtered_sims), med,avg,std,ppcc75,ppcc90))
    print('next line: ppcc75,ppcc90,median, easy to paste to excel')
    print('%f,%f,%f'%(ppcc75,ppcc90,med))
