# 分析alpha和beta的顺序对PCC有影响吗？

import sys

from torch.nn.init import xavier_normal_
sys.path.append("..")
import matplotlib
matplotlib.use('AGG')#或者PDF, SVG或PS
import matplotlib.pyplot as plt
import seaborn as sns
from matplotlib.ticker import MaxNLocator
import post_utils
import numpy as np
from scipy import stats

# non-clv test ans
path_test_folder=r'/data/zlchen/pDeepXL/code/pDeepXL/pt/XL-test-non-clv-1123-212811-overall-test-transfer30'
path_test_ans=r'%s/test_ans.csv'%path_test_folder
path_fig=r'%s/non-clv-test-order-compare1205.svg'%path_test_folder


# clv test ans
# path_test_folder=r'/data/zlchen/pDeepXL/code/pDeepXL/pt/XL-test-clv-1123-213200-overall-test-transfer30'
# path_test_ans=r'%s/test_ans.csv'%path_test_folder
# path_fig=r'%s/clv-test-order-compare1205.svg'%path_test_folder


print('path_test_folder=%s'%path_test_folder)
ans=post_utils.read_test_ans(path_test_ans)
print('total=%d,half=%d'%(len(ans),len(ans)/2))

target_pccs,rev_pccs=[],[]

for title,pcc in ans:
    if '.dta1' in title:
        target_pccs.append(pcc)
    else:
        rev_pccs.append(pcc)

print('num_target=%d,num_rev=%d'%(len(target_pccs),len(rev_pccs)))

target_pccs, rev_pccs=np.array(target_pccs),np.array(rev_pccs)

plt.figure(figsize=(6, 4.8))

plt.plot(target_pccs, rev_pccs, '.', color='b', label='Test PCCs')

# https://docs.scipy.org/doc/scipy/reference/generated/scipy.stats.linregress.html
# fit a func: y=slope*x+intercept
slope, intercept, r_value, p_value, std_err = stats.linregress(target_pccs, rev_pccs)
print('slope=%f, intercept=%f, r_value=%f, p_value=%f, std_err=%f'%(slope, intercept, r_value, p_value, std_err))
print('r^2=%f'%(r_value**2))
x=np.array([0,1.05]) # 拟合曲线的两个点的x坐标
plt.plot(x, slope*x + intercept, linestyle="--", color='r', label='Fitted line')
# plt.plot([0,1],[0,1], linestyle="--", color='r')

# plt.title(fig_title)
plt.legend()

plt.xlim(0,1.05)
plt.ylim(0,1.05)

plt.xlabel(r'x = PCC of $\alpha$[SEP]$\beta$')
# plt.ylabel('Percentage of PCCs >= x (%)')
plt.ylabel(r'y = PCC of $\beta$[SEP]$\alpha$')
plt.savefig(path_fig, format='svg', dpi=1200)
plt.savefig(path_fig+'.png')