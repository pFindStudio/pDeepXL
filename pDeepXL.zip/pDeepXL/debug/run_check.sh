#! /bin/sh


cd /data/zlchen/pDeepXL/code/pDeepXL/debug

python /data/zlchen/pDeepXL/code/pDeepXL/debug/check_instrument_energy1.py > 1.log
python /data/zlchen/pDeepXL/code/pDeepXL/debug/check_instrument_energy2.py > 2.log
python /data/zlchen/pDeepXL/code/pDeepXL/debug/check_instrument_energy3.py > 3.log
