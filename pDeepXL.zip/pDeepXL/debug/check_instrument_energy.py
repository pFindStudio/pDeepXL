# -*- coding: utf-8 -*-
"""
Created on Mon Oct 19 21:27:57 2020

@author: Zhenlin
"""

#检查某一批数据集用了多少种能量和仪器

import os
import re
from tqdm import tqdm
from concurrent.futures import ThreadPoolExecutor, wait, ALL_COMPLETED, FIRST_COMPLETED, ProcessPoolExecutor
import sys
sys.path.append("..")
from utils import read_instrument_name, read_ms2_energy, absoluteFilePaths


pfolder=r'/data/zlchen/pDeepXL/data/PXD017620/crude_fresh/pf2'

def run(rawname):
    pid = os.getpid()
    print('pid=%s for %s'%(pid, rawname))

    path_instrument=r'%s/%s.sum.csv'%(pfolder,rawname)
    path_energy=r'%s/%s.csv'%(pfolder,rawname)

    instrument = read_instrument_name(path_instrument)
    mpMS2Energy=read_ms2_energy(path_energy)

    set_nce=set()

    for title,nces in mpMS2Energy.items():
        str_nce='-'.join(list(map(str,nces)))
        set_nce.add(str_nce)
    
    total_nce_str='|'.join(sorted(list(set_nce)))

    print('pid=%s, raw=%s, instrument=%s, total_nce=%s'%(pid, rawname, instrument, total_nce_str))
    return [rawname, instrument, total_nce_str]


if __name__ == "__main__":
    print('runing main...')

    executor = ProcessPoolExecutor(max_workers=32)
    processes = []
    files=absoluteFilePaths(pfolder)
    
    for f in files:
        fname,fext=os.path.splitext(f)
        if fext == '.pf2':
            rawname=os.path.basename(fname)[:-6]
            processes.append(executor.submit(run, rawname))
            
    executor.shutdown(wait=True)
    print("main done.")
    
    merged_ans=[]
    for p in processes:
        merged_ans.append(p.result())

    # print(merged_ans)

    set_inst_nce=set()
    for rawname, instrument, total_nce_str in merged_ans:
        set_inst_nce.add('%s@%s'%(instrument, total_nce_str))
    
    all_total_inst_nce='$'.join(sorted(list(set_inst_nce)))
    print('total instrument and nce = %s'%all_total_inst_nce)
    print('total number=%d'%len(set_inst_nce))
