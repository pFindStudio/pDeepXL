import os
import configparser
import pickle
from tqdm import tqdm
import sys
from peptide_featurer import PeptideFeaturer

config = configparser.ConfigParser()
config.read('/data/zlchen/pDeepXL/code/pDeepXL/config.ini')
pf = PeptideFeaturer(config)

MIN_PREC_CHARGE=int(config['DEFAULT']['min_prec_charge'])
MAX_PREC_CHARGE=int(config['DEFAULT']['max_prec_charge'])

MIN_PEPTIDE_LEN=int(config['DEFAULT']['min_peptide_len'])
MAX_PEPTIDE_LEN=int(config['DEFAULT']['max_peptide_len'])

def ConvertpFind3ToTensor(path_match_raw_info_pkl, path_match_formatted_dta, path_match_formatted_pkl):
    frawpkl = open(path_match_raw_info_pkl, 'rb')
    allPSMs = pickle.load(frawpkl)
    frawpkl.close()

    T,L,X,Y=[],[],[],[] # L表示总长度
    PT=[] # 肽段类型peptide type，0 for linear, 1 for non-clv, 2 for clv
    L1,L2,S1,S2=[],[],[],[] # α和β的长度，及交联位点，如果是单肽（P=0），则这几个值都是-1（无效）

    cur_pt,cur_l1,cur_l2,cur_s1,cur_s2=0,-1,-1,-1,-1

    fdtaout=open(path_match_formatted_dta,'w')
    for psm in tqdm(allPSMs):
        title,scan,prec_charge,seq,mods,inst,NCE_low,NCE_medium,NCE_high,matched_b1b2y1y2=psm
        lseq = len(seq)

        mints_norm=matched_b1b2y1y2
        b1s,b2s,y1s,y2s=mints_norm[:4]

        input_vec, seq_aa_mod_sum = pf.Sequence2Vec(seq,mods,prec_charge,inst,NCE_low,NCE_medium,NCE_high,'',-1,False)
        output_vec=[]
        
        for i in range(0, lseq-1):
            inten_vec = [b1s[i],b2s[i],y1s[i+1],y2s[i+1]]
            # inten_vec.extend([0.0]*12) # 其他离子强度都为0
            inten_vec.extend([0.0]*4) # 2020.11.17 总输出维度缩减为8维
            output_vec.append(inten_vec)

        # output_vec=pf.PaddingZero(output_vec)
        X.append(input_vec)
        Y.append(output_vec)
        L.append(lseq-1)
        T.append(title)

        PT.append(cur_pt)
        L1.append(cur_l1)
        L2.append(cur_l2)
        S1.append(cur_s1)
        S2.append(cur_s2)

        onesample=[title,cur_pt,lseq-1,cur_l1,cur_l2,cur_s1,cur_s2,input_vec,output_vec]
        fdtaout.write('\t'.join(map(str,onesample))+'\n')

        # if len(X) >= 100: # small dataset for debug!!!!!!!!!!!!!!!!
        #     break

    fdtaout.close()

    fpklout=open(path_match_formatted_pkl,'wb')
    pickle.dump([T,PT,L,L1,L2,S1,S2,X,Y],fpklout,protocol=4) # v4版协议速度更快、支持超大文件，只需要在dump时指定版本，load时会自动识别版本
    fpklout.close()

    print('collected %d samples'%len(T))


if __name__ == "__main__":

    print('runing main...')

    # 如果有命令行参数的话
    if len(sys.argv) == 3:
        print('有命令行参数')
        print('参数个数为:', len(sys.argv), '个参数。')
        print('参数列表:', str(sys.argv))
        path_data_home,usage=sys.argv[1:]
        print('path_data_home=%s'%path_data_home)
        print('usage=%s'%usage)
    else:
        print('无命令行参数，或参数个数不等于3')

        path_data_home = r'/data/zlchen/pDeepXL/data/PXD019926'
        # usage='_train'
        # usage='_test'
        usage='_val'
        # usage=''

    path_match_raw_info_pkl = r'%s/pFind3_data/pFind3_match_info_filtered%s.pkl'%(path_data_home,usage)

    path_match_formatted_dta = r'%s/pFind3_data/pFind3_filtered%s.dta'%(path_data_home,usage)
    path_match_formatted_pkl = r'%s/pFind3_data/pFind3_filtered%s.pkl'%(path_data_home,usage)

    ConvertpFind3ToTensor(path_match_raw_info_pkl, path_match_formatted_dta, path_match_formatted_pkl)