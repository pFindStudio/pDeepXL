# pLink-clv（pLink-DSSO） 预处理全流程外壳

import os

# path_data_homes=[r'/data/zlchen/pDeepXL/data/PXD019926/DSSO/HEK293',
#                  r'/data/zlchen/pDeepXL/data/PXD017711',
#                  r'/data/zlchen/pDeepXL/data/PXD012546']

path_data_homes=[r'/data/zlchen/pDeepXL/data/PXD011861/Ecoli']

#############################################################################################
# 1. 将pLink-clv（pLink-DSSO）鉴定结果进行肽谱匹配，提取出mic > pep_len的PSM，并输出匹配离子强度

# instruments=['Lumos','Lumos','QEPlus']
# NCE_lows=[21.0, 18.0, 27.0]
# NCE_mediums=[27.0, 24.0, 30.0]
# NCE_highs=[33.0, 30.0, 33.0]
# LinkerNames=['DSSO','DSSO','DSBU']

# 1.1 unseen test set
# instruments=['Lumos']
# NCE_lows=[21.0]
# NCE_mediums=[27.0]
# NCE_highs=[33.0]
# LinkerNames=['DSSO']

# path_py='pLink_clv_to_txt.py'
# for fid,(phome, inst, nce_low, nce_medium, nce_high, linker_name) in enumerate(zip(path_data_homes, instruments, NCE_lows, NCE_mediums, NCE_highs, LinkerNames)):
#     os.system('echo %d folder begin'%fid)
#     os.system('python %s %s %s %f %f %f %s'%(path_py, phome, inst, nce_low, nce_medium, nce_high, linker_name))
#     os.system('echo %d folder end'%fid)
#     os.system('echo ----------------------------------------------')

#############################################################################################



#############################################################################################
# 2. 使用电荷、长度进行过滤

# path_py='filter_txt.py'
# engine='pLink2'
# for fid,phome in enumerate(path_data_homes):
#     os.system('echo %d folder begin'%fid)
#     os.system('python %s %s %s'%(path_py, phome, engine))
#     os.system('echo %d folder end'%fid)
#     os.system('echo ----------------------------------------------')

#############################################################################################


#############################################################################################
# 3. 对每个数据集，划分训练集、验证集、测试集，比例是6:2:2
# 对于unseen test dataset，修改py让test ratio=1.0

# path_py='split_train_set_txt.py'
# engine='pLink2'
# for fid,phome in enumerate(path_data_homes):
#     os.system('echo %d folder begin'%fid)
#     os.system('python %s %s %s'%(path_py, phome, engine))
#     os.system('echo %d folder end'%fid)
#     os.system('echo ----------------------------------------------')

#############################################################################################


#############################################################################################
# 4. 合并所有数据集的训练集、验证集、测试集

# path_py='merge_txt.py'
# engine='pLink2'
# usages=['_train','_test','_val']
# concat_folders=' '.join(path_data_homes)
# for usage in usages:
#     pfinaltxt=r'/data/zlchen/pDeepXL/data/pLink_clv_data/%s_match_info_filtered%s.txt'%(engine,usage)
#     pfinalpkl=r'/data/zlchen/pDeepXL/data/pLink_clv_data/%s_match_info_filtered%s.pkl'%(engine,usage)
#     os.system('echo merge %s begin'%usage)
#     os.system('python %s %s %s %s %s %s'%(path_py, engine, usage, pfinaltxt, pfinalpkl, concat_folders))
#     os.system('echo merge %s end'%usage)
#     os.system('echo ----------------------------------------------')

#############################################################################################



#############################################################################################
# 5. 把匹配txt信息转换为网络输入dta格式

# path_py='pLink2_to_dta.py'
# path_py='pLink2_compact_dta.py'
# path_data_home=r'/data/zlchen/pDeepXL/data/PXD019926/DSSO/HEK293/pLink2_data'
# usages=['_train','_test','_val']
# consider=0 # 可碎裂，不考虑xlink离子
# for usage in usages:
#     os.system('echo convert %s begin'%usage)
#     os.system('python %s %s %s %d'%(path_py, path_data_home, usage, consider))
#     os.system('echo convert %s end'%usage)
#     os.system('echo ----------------------------------------------')

#############################################################################################





# for fine tune
#############################################################################################
# 6. 生成不同比例的fine tune数据集
# 只划分train和val

path_py='split_train_set_txt_2parts.py'
engine='pLink2'
# train_nums=[10,50,100,150,200,250,300,500]
train_nums=[i*0.01 for i in range(5,80,10)]
how=1 # 0绝对数，1比例

for fid,phome in enumerate(path_data_homes):
    for n in train_nums:
        os.system('echo %d folder %d begin'%(fid,n))
        if how==0:
            os.system('python %s %s %s %d %d'%(path_py, phome, engine, how, n))
        else:
            os.system('python %s %s %s %d %f'%(path_py, phome, engine, how, n))
        os.system('echo %d folder %d end'%(fid,n))
        os.system('echo ----------------------------------------------')

#############################################################################################



#############################################################################################
# 7. 把匹配txt信息转换为网络输入dta格式

path_py='pLink2_to_dta.py'

usages=['_train','_val']
consider=0 # 可碎裂，不考虑xlink离子
for path_data_home in path_data_homes:
    path_fine_tune_folder=r'%s/pLink2_data/fine-tune2'%path_data_home
    for usage in usages:
        for n in train_nums:
            str_train_num='_%d'%(n*100)
            os.system('echo convert %s begin'%usage)
            os.system('python %s %s %s %d %s'%(path_py, path_fine_tune_folder, usage, consider, str_train_num))
            os.system('echo convert %s end'%usage)
            os.system('echo ----------------------------------------------')

#############################################################################################