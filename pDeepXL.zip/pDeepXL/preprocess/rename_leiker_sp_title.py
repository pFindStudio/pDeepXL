# leiker-ecoli的数据集有些raw的名称相同，重命名，使得spectra title unique

import pickle
import sys
import os

set_txt_titles=set()
set_pkl_titles=set()

def ConvertOldToNewTxt(path_old_txt, path_new_txt, prefix):
    fin=open(path_old_txt)
    lines=fin.readlines()
    fin.close()

    fout=open(path_new_txt,'w')
    fout.write(lines[0])

    for i in range(1,len(lines)):
        contents=lines[i].split('\t')
        contents[0]=prefix+'_'+contents[0]

        if contents[0] in set_txt_titles:
            print(contents[0])
        else:
            set_txt_titles.add(contents[0])

        fout.write('\t'.join(contents))
    fout.close()


def ConvertOldToNewPkl(path_old_pkl, path_new_pkl, prefix):
    frawpkl = open(path_old_pkl, 'rb')
    allPSMs = pickle.load(frawpkl)
    frawpkl.close()

    for i in range(len(allPSMs)):
        allPSMs[i][0]=prefix+'_'+allPSMs[i][0]

        if allPSMs[i][0] in set_pkl_titles:
            print(allPSMs[i][0])
        else:
            set_pkl_titles.add(allPSMs[i][0])


    fout=open(path_new_pkl,'wb')
    pickle.dump(allPSMs,fout)
    fout.close()


if __name__ == "__main__":
    print('runing main...')

    # 如果有命令行参数的话
    if len(sys.argv) == 4:
        print('有命令行参数')
        print('参数个数为:', len(sys.argv), '个参数。')
        print('参数列表:', str(sys.argv))
        path_folder,rawname,engine=sys.argv[1:]
        print('path_folder=%s'%path_folder)
        print('rawname=%s'%rawname)
        print('engine=%s'%engine)
    else:
        print('无命令行参数，或参数个数不等于4')

        path_folder=r'/data/zlchen/pDeepXL/data/Leiker_elife/5.E.coli_lysates/enri0121_undigested_by_RNase'
        rawname='ecoli_enri0121'
        engine='pFind3'
        # engine='pLink2'

    path_original_txt=r'%s/%s_data/%s_match_info.txt'%(path_folder,engine,engine)
    path_original_pkl=r'%s/%s_data/%s_match_info.pkl'%(path_folder,engine,engine)

    path_old_txt=r'%s/%s_data/%s_match_info_old_name.txt'%(path_folder,engine,engine)
    path_old_pkl=r'%s/%s_data/%s_match_info_old_name.pkl'%(path_folder,engine,engine)

    os.rename(path_original_txt, path_old_txt) # 先重命名文件名为old_name
    os.rename(path_original_pkl, path_old_pkl)

    # path_new_txt=r'%s/%s_data/%s_match_info_new_name.txt'%(path_folder,engine,engine)
    # path_new_pkl=r'%s/%s_data/%s_match_info_new_name.pkl'%(path_folder,engine,engine)

    ConvertOldToNewTxt(path_old_txt, path_original_txt, rawname) # 再重命名内容
    ConvertOldToNewPkl(path_old_pkl, path_original_pkl, rawname)


