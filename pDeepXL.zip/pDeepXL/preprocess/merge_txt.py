# 合并pFind3_to_txt.py或pLink2_to_txt整理出来的match_info文件
# 形成一个大的训练数据集

import pickle
import sys

def MergeTxts(ptxts,pfinaltxt):
    print('merging txt files...')
    n=0
    first=True
    fout=open(pfinaltxt,'w')
    for p in ptxts:
        fin=open(p)
        lines=fin.readlines()
        fin.close()
        print('txt=%s,#lines=%d'%(p,len(lines)-1))
        if first:
            fout.write(lines[0])
            first=False
        for i in range(1,len(lines)):
            n+=1
            fout.write(lines[i])
    fout.close()
    print('merge txt done, total lines=%d'%n)

def MergePkls(ppkls,pfinalpkl):
    print('merging pkl files...')
    PSMs=[]
    for p in ppkls:
        frawpkl = open(p, 'rb')
        curPSMs = pickle.load(frawpkl)
        frawpkl.close()
        print('pkl=%s,size=%d'%(p,len(curPSMs)))
        PSMs.extend(curPSMs)

    fpklout=open(pfinalpkl,'wb')
    pickle.dump(PSMs,fpklout)
    fpklout.close()

    print('merge pkl done, total size=%d'%len(PSMs))


if __name__ == "__main__":
    print('runing main...')

    # 如果有命令行参数的话
    if len(sys.argv) >= 6:
        print('有命令行参数')
        print('参数个数为:', len(sys.argv), '个参数。')
        print('参数列表:', str(sys.argv))
        engine,usage,pfinaltxt,pfinalpkl=sys.argv[1:5]
        path_sub_folders=sys.argv[5:]
        print('engine=%s'%engine)
        print('usage=%s'%usage)
        print('pfinaltxt=%s'%pfinaltxt)
        print('pfinalpkl=%s'%pfinalpkl)
        print('path_sub_folders=%s'%str(path_sub_folders))
    else:
        print('无命令行参数，或参数个数小于6')

        # engine='pFind3'
        engine='pLink2'

        # usage='_train'
        usage='_test'
        # usage='_val'

        pfinaltxt=r'/data/zlchen/pDeepXL/data/pLink_all/%s_match_info_filtered%s.txt'%(engine,usage)
        pfinalpkl=r'/data/zlchen/pDeepXL/data/pLink_all/%s_match_info_filtered%s.pkl'%(engine,usage)

        path_sub_folders=[r'/data/zlchen/pDeepXL/data/pLink2_data',
                            r'/data/zlchen/pDeepXL/data/pLink_clv_data']

    ptxts=[]
    ppkls=[]
    for path_folder in path_sub_folders:
        path_sub_folder = r'%s/%s_data'%(path_folder, engine)
        path_txt=r'%s/%s_match_info_filtered%s.txt'%(path_sub_folder, engine,usage) # 对于其他数据和ecoli-leiker数据，
        path_pkl=r'%s/%s_match_info_filtered%s.pkl'%(path_sub_folder, engine,usage) # 可能需要添加或删除_filtered
        ptxts.append(path_txt)
        ppkls.append(path_pkl)

    MergeTxts(ptxts,pfinaltxt)
    MergePkls(ppkls,pfinalpkl)
