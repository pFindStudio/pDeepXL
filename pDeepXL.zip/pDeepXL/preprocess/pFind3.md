1. pFind3_to_txt.py: 将pFind3鉴定结果中匹配比较好的PSM提取出来
2. pFind3_explore.py: 观察电荷与长度分布
3. 在config.ini中指定合适的电荷约束与长度约束
4. pFind3_to_dta.py: 将满足电荷与长度约束的PSM转换为向量/矩阵形式，可直接输入到神经网络中