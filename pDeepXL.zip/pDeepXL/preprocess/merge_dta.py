# 合并pFind3_to_dta.py或pLink2_to_dta整理出来的dta文件
# 形成一个大的训练数据集

import pickle

# for pFind3 all
# pdtas=[r'/data/zlchen/pDeepXL/data/PXD017620/pFind3_data/pFind3.dta',
#         r'/data/zlchen/pDeepXL/data/PXD016554/DSS/pFind3_data/pFind3.dta',
#         r'/data/zlchen/pDeepXL/data/PXD019926/DSS/pFind3_data/pFind3.dta',
#         r'/data/zlchen/pDeepXL/data/PXD017695/pFind3_data/pFind3.dta',
#         r'/data/zlchen/pDeepXL/data/PXD014675/pFind3_data/pFind3.dta',
#         r'/data/zlchen/pDeepXL/data/lili/pFind3_data/pFind3.dta',
#         r'/data/zlchen/pDeepXL/data/Leiker_elife/pFind3_data/pFind3.dta']

# ppkls=[r'/data/zlchen/pDeepXL/data/PXD017620/pFind3_data/pFind3.pkl',
#         r'/data/zlchen/pDeepXL/data/PXD016554/DSS/pFind3_data/pFind3.pkl',
#         r'/data/zlchen/pDeepXL/data/PXD019926/DSS/pFind3_data/pFind3.pkl',
#         r'/data/zlchen/pDeepXL/data/PXD017695/pFind3_data/pFind3.pkl',
#         r'/data/zlchen/pDeepXL/data/PXD014675/pFind3_data/pFind3.pkl',
#         r'/data/zlchen/pDeepXL/data/lili/pFind3_data/pFind3.pkl',
#         r'/data/zlchen/pDeepXL/data/Leiker_elife/pFind3_data/pFind3.pkl']

# pfinaldta=r'/data/zlchen/pDeepXL/data/pFind3_data/pFind3.dta'
# pfinalpkl=r'/data/zlchen/pDeepXL/data/pFind3_data/pFind3.pkl'
# ----------------------------------

# for all
path_sub_folders=[r'/data/zlchen/pDeepXL/data/PXD017620',
                  r'/data/zlchen/pDeepXL/data/PXD016554/DSS/B_subtilis',
                  r'/data/zlchen/pDeepXL/data/PXD016554/DSS/B_cereus',
                  r'/data/zlchen/pDeepXL/data/PXD019926/DSS/HEK293',
                #   r'/data/zlchen/pDeepXL/data/PXD019926/DSS/8PM',
                  r'/data/zlchen/pDeepXL/data/PXD017695',
                  r'/data/zlchen/pDeepXL/data/PXD014675',
                  r'/data/zlchen/pDeepXL/data/lili',
                  r'/data/zlchen/pDeepXL/data/Leiker_elife/5.E.coli_lysates'
                #   r'/data/zlchen/pDeepXL/data/Leiker_elife/6.C.elegans_lysates/N2'
                  ]

# engine='pFind3'
engine='pLink2'

usage='train'
# usage='test'

pfinaldta=r'/data/zlchen/pDeepXL/data/%s_data/%s_%s-1025.dta'%(engine,engine,usage)
pfinalpkl=r'/data/zlchen/pDeepXL/data/%s_data/%s_%s-1025.pkl'%(engine,engine,usage)
# ----------------------------------


# for pFind3 @ PXD017620
# pdtas=[r'/data/zlchen/pDeepXL/data/PXD017620/crude_fresh/pFind3_data/pFind3.dta',
#         r'/data/zlchen/pDeepXL/data/PXD017620/d0d4/pFind3_data/pFind3.dta',
#         r'/data/zlchen/pDeepXL/data/PXD017620/I_Parfentev/pFind3_data/pFind3.dta',
#         r'/data/zlchen/pDeepXL/data/PXD017620/XL/pFind3_data/pFind3.dta']

# ppkls=[r'/data/zlchen/pDeepXL/data/PXD017620/crude_fresh/pFind3_data/pFind3.pkl',
#         r'/data/zlchen/pDeepXL/data/PXD017620/d0d4/pFind3_data/pFind3.pkl',
#         r'/data/zlchen/pDeepXL/data/PXD017620/I_Parfentev/pFind3_data/pFind3.pkl',
#         r'/data/zlchen/pDeepXL/data/PXD017620/XL/pFind3_data/pFind3.pkl']

# pfinaldta=r'/data/zlchen/pDeepXL/data/PXD017620/pFind3_data/pFind3.dta'
# pfinalpkl=r'/data/zlchen/pDeepXL/data/PXD017620/pFind3_data/pFind3.pkl'
#-------------------------

# for pLink2 @ PXD017620
# pdtas=[r'/data/zlchen/pDeepXL/data/PXD017620/crude_fresh/pLink2_data/pLink2-1025.dta',
#         r'/data/zlchen/pDeepXL/data/PXD017620/d0d4/pLink2_data/pLink2-1025.dta',
#         r'/data/zlchen/pDeepXL/data/PXD017620/I_Parfentev/pLink2_data/pLink2-1025.dta',
#         r'/data/zlchen/pDeepXL/data/PXD017620/XL/pLink2_data/pLink2-1025.dta']

# ppkls=[r'/data/zlchen/pDeepXL/data/PXD017620/crude_fresh/pLink2_data/pLink2-1025.pkl',
#         r'/data/zlchen/pDeepXL/data/PXD017620/d0d4/pLink2_data/pLink2-1025.pkl',
#         r'/data/zlchen/pDeepXL/data/PXD017620/I_Parfentev/pLink2_data/pLink2-1025.pkl',
#         r'/data/zlchen/pDeepXL/data/PXD017620/XL/pLink2_data/pLink2-1025.pkl']

# pfinaldta=r'/data/zlchen/pDeepXL/data/PXD017620/pLink2_data/pLink2-1025.dta'
# pfinalpkl=r'/data/zlchen/pDeepXL/data/PXD017620/pLink2_data/pLink2-1025.pkl'


# for pLink2 @ Leiker-eLife Ecoli
# pdtas=[r'/data/zlchen/pDeepXL/data/Leiker_elife/5.E.coli_lysates/enri0121_undigested_by_RNase/pLink2_data/pLink2-1025.dta',
#         r'/data/zlchen/pDeepXL/data/Leiker_elife/5.E.coli_lysates/enri0228/pLink2_data/pLink2-1025.dta',
#         r'/data/zlchen/pDeepXL/data/Leiker_elife/5.E.coli_lysates/enri0302/pLink2_data/pLink2-1025.dta',
#         r'/data/zlchen/pDeepXL/data/Leiker_elife/5.E.coli_lysates/ribofree/frac/150821/pLink2_data/pLink2-1025.dta',
#         r'/data/zlchen/pDeepXL/data/Leiker_elife/5.E.coli_lysates/ribofree/frac/150830/pLink2_data/pLink2-1025.dta']

# ppkls=[r'/data/zlchen/pDeepXL/data/Leiker_elife/5.E.coli_lysates/enri0121_undigested_by_RNase/pLink2_data/pLink2-1025.pkl',
#         r'/data/zlchen/pDeepXL/data/Leiker_elife/5.E.coli_lysates/enri0228/pLink2_data/pLink2-1025.pkl',
#         r'/data/zlchen/pDeepXL/data/Leiker_elife/5.E.coli_lysates/enri0302/pLink2_data/pLink2-1025.pkl',
#         r'/data/zlchen/pDeepXL/data/Leiker_elife/5.E.coli_lysates/ribofree/frac/150821/pLink2_data/pLink2-1025.pkl',
#         r'/data/zlchen/pDeepXL/data/Leiker_elife/5.E.coli_lysates/ribofree/frac/150830/pLink2_data/pLink2-1025.pkl']

# pfinaldta=r'/data/zlchen/pDeepXL/data/Leiker_elife/5.E.coli_lysates/pLink2_data/pLink2-1025.dta'
# pfinalpkl=r'/data/zlchen/pDeepXL/data/Leiker_elife/5.E.coli_lysates/pLink2_data/pLink2-1025.pkl'



# for pLink2 @ Leiker-eLife Worm
# pdtas=[r'/data/zlchen/pDeepXL/data/Leiker_elife/6.C.elegans_lysates/N2/E_bin/pLink2_data/pLink2-1025.dta',
#         r'/data/zlchen/pDeepXL/data/Leiker_elife/6.C.elegans_lysates/N2/unfrac/pLink2_data/pLink2-1025.dta',
#         r'/data/zlchen/pDeepXL/data/Leiker_elife/6.C.elegans_lysates/N2/unfrac2/pLink2_data/pLink2-1025.dta']

# ppkls=[r'/data/zlchen/pDeepXL/data/Leiker_elife/6.C.elegans_lysates/N2/E_bin/pLink2_data/pLink2-1025.pkl',
#         r'/data/zlchen/pDeepXL/data/Leiker_elife/6.C.elegans_lysates/N2/unfrac/pLink2_data/pLink2-1025.pkl',
#         r'/data/zlchen/pDeepXL/data/Leiker_elife/6.C.elegans_lysates/N2/unfrac2/pLink2_data/pLink2-1025.pkl']

# pfinaldta=r'/data/zlchen/pDeepXL/data/Leiker_elife/6.C.elegans_lysates/N2/pLink2_data/pLink2-1025.dta'
# pfinalpkl=r'/data/zlchen/pDeepXL/data/Leiker_elife/6.C.elegans_lysates/N2/pLink2_data/pLink2-1025.pkl'
# ----------------------------------


# for pLink2 @ PXD014675
# pdtas=[r'/data/zlchen/pDeepXL/data/PXD014675/A_TA/pLink2_data/pLink2-1025.dta',
#         r'/data/zlchen/pDeepXL/data/PXD014675/B_TC/pLink2_data/pLink2-1025.dta',
#         r'/data/zlchen/pDeepXL/data/PXD014675/C_TG/pLink2_data/pLink2-1025.dta',
#         r'/data/zlchen/pDeepXL/data/PXD014675/D_T/pLink2_data/pLink2-1025.dta']

# ppkls=[r'/data/zlchen/pDeepXL/data/PXD014675/A_TA/pLink2_data/pLink2-1025.pkl',
#         r'/data/zlchen/pDeepXL/data/PXD014675/B_TC/pLink2_data/pLink2-1025.pkl',
#         r'/data/zlchen/pDeepXL/data/PXD014675/C_TG/pLink2_data/pLink2-1025.pkl',
#         r'/data/zlchen/pDeepXL/data/PXD014675/D_T/pLink2_data/pLink2-1025.pkl']

# pfinaldta=r'/data/zlchen/pDeepXL/data/PXD014675/pLink2_data/pLink2-1025.dta'
# pfinalpkl=r'/data/zlchen/pDeepXL/data/PXD014675/pLink2_data/pLink2-1025.pkl'
# ----------------------------------



# for pLink2 @ PXD017695
# pdtas=[r'/data/zlchen/pDeepXL/data/PXD017695/dataset1_DSS_SCX_SEC/pLink2_data/pLink2-1025.dta',
#         r'/data/zlchen/pDeepXL/data/PXD017695/dataset2_DSS_inCell_SEC/pLink2_data/pLink2-1025.dta',
#         r'/data/zlchen/pDeepXL/data/PXD017695/dataset3_DSS_SEC_hSAX/pLink2_data/pLink2-1025.dta']

# ppkls=[r'/data/zlchen/pDeepXL/data/PXD017695/dataset1_DSS_SCX_SEC/pLink2_data/pLink2-1025.pkl',
#         r'/data/zlchen/pDeepXL/data/PXD017695/dataset2_DSS_inCell_SEC/pLink2_data/pLink2-1025.pkl',
#         r'/data/zlchen/pDeepXL/data/PXD017695/dataset3_DSS_SEC_hSAX/pLink2_data/pLink2-1025.pkl']

# pfinaldta=r'/data/zlchen/pDeepXL/data/PXD017695/pLink2_data/pLink2-1025.dta'
# pfinalpkl=r'/data/zlchen/pDeepXL/data/PXD017695/pLink2_data/pLink2-1025.pkl'
# ----------------------------------




# for pFind3 @ PXD014675
# pdtas=[r'/data/zlchen/pDeepXL/data/PXD014675/A_TA/pFind3_data/pFind3.dta',
#         r'/data/zlchen/pDeepXL/data/PXD014675/B_TC/pFind3_data/pFind3.dta',
#         r'/data/zlchen/pDeepXL/data/PXD014675/C_TG/pFind3_data/pFind3.dta',
#         r'/data/zlchen/pDeepXL/data/PXD014675/D_T/pFind3_data/pFind3.dta']

# ppkls=[r'/data/zlchen/pDeepXL/data/PXD014675/A_TA/pFind3_data/pFind3.pkl',
#         r'/data/zlchen/pDeepXL/data/PXD014675/B_TC/pFind3_data/pFind3.pkl',
#         r'/data/zlchen/pDeepXL/data/PXD014675/C_TG/pFind3_data/pFind3.pkl',
#         r'/data/zlchen/pDeepXL/data/PXD014675/D_T/pFind3_data/pFind3.pkl']

# pfinaldta=r'/data/zlchen/pDeepXL/data/PXD014675/pFind3_data/pFind3.dta'
# pfinalpkl=r'/data/zlchen/pDeepXL/data/PXD014675/pFind3_data/pFind3.pkl'
# ----------------------------------

# # for pFind3 @ PXD016554
# pdtas=[r'/data/zlchen/pDeepXL/data/PXD016554/DSS/B_cereus/pFind3_data/pFind3.dta',
#         r'/data/zlchen/pDeepXL/data/PXD016554/DSS/B_subtilis/pFind3_data/pFind3.dta']

# ppkls=[r'/data/zlchen/pDeepXL/data/PXD016554/DSS/B_cereus/pFind3_data/pFind3.pkl',
#         r'/data/zlchen/pDeepXL/data/PXD016554/DSS/B_subtilis/pFind3_data/pFind3.pkl']

# pfinaldta=r'/data/zlchen/pDeepXL/data/PXD016554/DSS/pFind3_data/pFind3.dta'
# pfinalpkl=r'/data/zlchen/pDeepXL/data/PXD016554/DSS/pFind3_data/pFind3.pkl'
# # ----------------------------------

# # for pFind3 @ PXD019926
# pdtas=[r'/data/zlchen/pDeepXL/data/PXD019926/DSS/8PM/pFind3_data/pFind3.dta',
#         r'/data/zlchen/pDeepXL/data/PXD019926/DSS/HEK293/pFind3_data/pFind3.dta']

# ppkls=[r'/data/zlchen/pDeepXL/data/PXD019926/DSS/8PM/pFind3_data/pFind3.pkl',
#         r'/data/zlchen/pDeepXL/data/PXD019926/DSS/HEK293/pFind3_data/pFind3.pkl']

# pfinaldta=r'/data/zlchen/pDeepXL/data/PXD019926/DSS/pFind3_data/pFind3.dta'
# pfinalpkl=r'/data/zlchen/pDeepXL/data/PXD019926/DSS/pFind3_data/pFind3.pkl'
# # ----------------------------------

# # for pFind3 @ PXD017695
# pdtas=[r'/data/zlchen/pDeepXL/data/PXD017695/dataset1_DSS_SCX_SEC/pFind3_data/pFind3.dta',
#         r'/data/zlchen/pDeepXL/data/PXD017695/dataset2_DSS_inCell_SEC/pFind3_data/pFind3.dta',
#         r'/data/zlchen/pDeepXL/data/PXD017695/dataset3_DSS_SEC_hSAX/pFind3_data/pFind3.dta']

# ppkls=[r'/data/zlchen/pDeepXL/data/PXD017695/dataset1_DSS_SCX_SEC/pFind3_data/pFind3.pkl',
#         r'/data/zlchen/pDeepXL/data/PXD017695/dataset2_DSS_inCell_SEC/pFind3_data/pFind3.pkl',
#         r'/data/zlchen/pDeepXL/data/PXD017695/dataset3_DSS_SEC_hSAX/pFind3_data/pFind3.pkl']

# pfinaldta=r'/data/zlchen/pDeepXL/data/PXD017695/pFind3_data/pFind3.dta'
# pfinalpkl=r'/data/zlchen/pDeepXL/data/PXD017695/pFind3_data/pFind3.pkl'
# # ----------------------------------


# # for pFind3 @ Leiker-Ecoli
# pdtas=[r'/data/zlchen/pDeepXL/data/Leiker_elife/5.E.coli_lysates/enri0121_undigested_by_RNase/pFind3_data/pFind3.dta',
#         r'/data/zlchen/pDeepXL/data/Leiker_elife/5.E.coli_lysates/enri0228/pFind3_data/pFind3.dta',
#         r'/data/zlchen/pDeepXL/data/Leiker_elife/5.E.coli_lysates/enri0302/pFind3_data/pFind3.dta',
#         r'/data/zlchen/pDeepXL/data/Leiker_elife/5.E.coli_lysates/ribofree/frac/150821/pFind3_data/pFind3.dta',
#         r'/data/zlchen/pDeepXL/data/Leiker_elife/5.E.coli_lysates/ribofree/frac/150830/pFind3_data/pFind3.dta']

# ppkls=[r'/data/zlchen/pDeepXL/data/Leiker_elife/5.E.coli_lysates/enri0121_undigested_by_RNase/pFind3_data/pFind3.pkl',
#         r'/data/zlchen/pDeepXL/data/Leiker_elife/5.E.coli_lysates/enri0228/pFind3_data/pFind3.pkl',
#         r'/data/zlchen/pDeepXL/data/Leiker_elife/5.E.coli_lysates/enri0302/pFind3_data/pFind3.pkl',
#         r'/data/zlchen/pDeepXL/data/Leiker_elife/5.E.coli_lysates/ribofree/frac/150821/pFind3_data/pFind3.pkl',
#         r'/data/zlchen/pDeepXL/data/Leiker_elife/5.E.coli_lysates/ribofree/frac/150830/pFind3_data/pFind3.pkl']

# pfinaldta=r'/data/zlchen/pDeepXL/data/Leiker_elife/5.E.coli_lysates/pFind3_data/pFind3.dta'
# pfinalpkl=r'/data/zlchen/pDeepXL/data/Leiker_elife/5.E.coli_lysates/pFind3_data/pFind3.pkl'
# # ----------------------------------


# # for pFind3 @ Leiker-Worm
# pdtas=[r'/data/zlchen/pDeepXL/data/Leiker_elife/6.C.elegans_lysates/N2/E_bin/pFind3_data/pFind3.dta',
#         r'/data/zlchen/pDeepXL/data/Leiker_elife/6.C.elegans_lysates/N2/unfrac/pFind3_data/pFind3.dta',
#         r'/data/zlchen/pDeepXL/data/Leiker_elife/6.C.elegans_lysates/N2/unfrac2/pFind3_data/pFind3.dta']

# ppkls=[r'/data/zlchen/pDeepXL/data/Leiker_elife/6.C.elegans_lysates/N2/E_bin/pFind3_data/pFind3.pkl',
#         r'/data/zlchen/pDeepXL/data/Leiker_elife/6.C.elegans_lysates/N2/unfrac/pFind3_data/pFind3.pkl',
#         r'/data/zlchen/pDeepXL/data/Leiker_elife/6.C.elegans_lysates/N2/unfrac2/pFind3_data/pFind3.pkl']

# pfinaldta=r'/data/zlchen/pDeepXL/data/Leiker_elife/6.C.elegans_lysates/N2/pFind3_data/pFind3.dta'
# pfinalpkl=r'/data/zlchen/pDeepXL/data/Leiker_elife/6.C.elegans_lysates/N2/pFind3_data/pFind3.pkl'
# # ----------------------------------

# # for pFind3 @ Leiker-all
# pdtas=[r'/data/zlchen/pDeepXL/data/Leiker_elife/5.E.coli_lysates/pFind3_data/pFind3.dta',
#         r'/data/zlchen/pDeepXL/data/Leiker_elife/6.C.elegans_lysates/N2/pFind3_data/pFind3.dta']

# ppkls=[r'/data/zlchen/pDeepXL/data/Leiker_elife/5.E.coli_lysates/pFind3_data/pFind3.pkl',
#         r'/data/zlchen/pDeepXL/data/Leiker_elife/6.C.elegans_lysates/N2/pFind3_data/pFind3.pkl']

# pfinaldta=r'/data/zlchen/pDeepXL/data/Leiker_elife/pFind3_data/pFind3.dta'
# pfinalpkl=r'/data/zlchen/pDeepXL/data/Leiker_elife/pFind3_data/pFind3.pkl'
# # ----------------------------------

def MergeDtas(pdtas,pfinaldta):
    print('merging dta files...')
    n=0
    fout=open(pfinaldta,'w')
    for p in pdtas:
        fin=open(p)
        lines=fin.readlines()
        fin.close()
        print('dta=%s,#lines=%d'%(p,len(lines)))
        for l in lines:
            n+=1
            fout.write(l)
    fout.close()
    print('merge dta done, total lines=%d'%n)

def MergePkls(ppkls,pfinalpkl):
    print('merging pkl files...')
    T,L,X,Y=[],[],[],[]
    for p in ppkls:
        fformattedpkl = open(p, 'rb')
        curT,curL,curX,curY = pickle.load(fformattedpkl)
        fformattedpkl.close()
        print('pkl=%s,size=%d'%(p,len(curT)))
        T.extend(curT)
        L.extend(curL)
        X.extend(curX)
        Y.extend(curY)
    
    fpklout=open(pfinalpkl,'wb')
    pickle.dump([T,L,X,Y],fpklout)
    fpklout.close()

    print('merge pkl done, total size=%d'%len(T))


pdtas=[]
ppkls=[]
for path_folder in path_sub_folders:
    path_sub_folder = r'%s/%s_data'%(path_folder, engine)
    path_dta=r'%s/%s_%s.dta'%(path_sub_folder, engine, usage)
    path_pkl=r'%s/%s_%s.pkl'%(path_sub_folder, engine, usage)
    pdtas.append(path_dta)
    ppkls.append(path_pkl)


MergeDtas(pdtas,pfinaldta)
MergePkls(ppkls,pfinalpkl)
