# pLink2 预处理全流程外壳

import os
import time

#############################################################################################
# 1. 将pLink2鉴定结果进行肽谱匹配，提取出mic > pep_len的PSM，并输出匹配离子强度
# leiker-ecoli有重名raw，单独处理

# path_data_homes=[r'/data/zlchen/pDeepXL/data/PXD017620',
#                  r'/data/zlchen/pDeepXL/data/PXD016554/DSS/B_subtilis',
#                  r'/data/zlchen/pDeepXL/data/PXD016554/DSS/B_cereus',
#                  r'/data/zlchen/pDeepXL/data/PXD019926/DSS/HEK293',
#                  r'/data/zlchen/pDeepXL/data/PXD017695',
#                  r'/data/zlchen/pDeepXL/data/PXD014675',
#                  r'/data/zlchen/pDeepXL/data/lili']

# instruments=['Fusion','QEHFX','QEHFX','Lumos','Lumos','Lumos','QE']
# NCE_lows=[0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0]
# NCE_mediums=[30.0, 30.0, 30.0, 30.0, 28.0, 28.0, 28.0]
# NCE_highs=[0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0]
# LinkerNames=['DSS']*len(path_data_homes)



# 1.1 unseen test set
# path_data_homes=[r'/data/zlchen/pDeepXL/data/PXD008550/HumanFOMix_BS3',
#                  r'/data/zlchen/pDeepXL/data/Leiker_elife/6.C.elegans_lysates/N2']

# instruments=['Lumos','QE']
# NCE_lows=[0.0, 0.0]
# NCE_mediums=[30.0, 27.0]
# NCE_highs=[0.0, 0.0]
# LinkerNames=['DSS', 'Leiker']

# 1.2 Mechtler-DSS
path_data_homes=[r'/data/zlchen/pDeepXL/data/PXD014337/QEx-HFX_DSS']

# instruments=['QEHFX']
# NCE_lows=[0.0]
# NCE_mediums=[28.0]
# NCE_highs=[0.0]
# LinkerNames=['DSS']


# path_py='pLink2_to_txt.py'
# for fid,(phome, inst, nce_low, nce_medium, nce_high, linker_name) in enumerate(zip(path_data_homes, instruments, NCE_lows, NCE_mediums, NCE_highs, LinkerNames)):
    
#     localtime = time.asctime( time.localtime(time.time()) )
#     print ("开始时间 :", localtime)
#     start = time.time()

#     os.system('echo %d folder begin'%fid)
#     os.system('python %s %s %s %f %f %f %s'%(path_py, phome, inst, nce_low, nce_medium, nce_high, linker_name))
#     os.system('echo %d folder end'%fid)

#     localtime = time.asctime( time.localtime(time.time()) )
#     print ("结束时间 :", localtime)
#     end = time.time()
#     print('run time=%f s'%(end-start))

#     os.system('echo ----------------------------------------------')
#############################################################################################



#############################################################################################
# 2. 将pLink2鉴定结果进行肽谱匹配，提取出mic > pep_len的PSM，并输出匹配离子强度

# leiker-ecoli有重名raw，单独处理

# path_data_homes=[r'/data/zlchen/pDeepXL/data/Leiker_elife/5.E.coli_lysates/enri0121_undigested_by_RNase',
#                   r'/data/zlchen/pDeepXL/data/Leiker_elife/5.E.coli_lysates/enri0228',
#                   r'/data/zlchen/pDeepXL/data/Leiker_elife/5.E.coli_lysates/enri0302',
#                   r'/data/zlchen/pDeepXL/data/Leiker_elife/5.E.coli_lysates/ribofree/frac/150821',
#                   r'/data/zlchen/pDeepXL/data/Leiker_elife/5.E.coli_lysates/ribofree/frac/150830'
#                   ]

# instruments=['QE']*len(path_data_homes)
# NCE_lows=[0.0]*len(path_data_homes)
# NCE_mediums=[27.0]*len(path_data_homes)
# NCE_highs=[0.0]*len(path_data_homes)
# LinkerNames=['Leiker']*len(path_data_homes)

# path_py='pLink2_to_txt.py'
# for fid,(phome, inst, nce_low, nce_medium, nce_high, linker_name) in enumerate(zip(path_data_homes, instruments, NCE_lows, NCE_mediums, NCE_highs, LinkerNames)):
#     os.system('echo %d folder begin'%fid)
#     os.system('python %s %s %s %f %f %f %s'%(path_py, phome, inst, nce_low, nce_medium, nce_high, linker_name))
#     os.system('echo %d folder end'%fid)
#     os.system('echo ----------------------------------------------')

#############################################################################################




#############################################################################################
# 3. 重命名ecoli-leiker每个子数据集的raw名称，使得spectrum title unique

# path_data_homes=[r'/data/zlchen/pDeepXL/data/Leiker_elife/5.E.coli_lysates/enri0121_undigested_by_RNase',
#                   r'/data/zlchen/pDeepXL/data/Leiker_elife/5.E.coli_lysates/enri0228',
#                   r'/data/zlchen/pDeepXL/data/Leiker_elife/5.E.coli_lysates/enri0302',
#                   r'/data/zlchen/pDeepXL/data/Leiker_elife/5.E.coli_lysates/ribofree/frac/150821',
#                   r'/data/zlchen/pDeepXL/data/Leiker_elife/5.E.coli_lysates/ribofree/frac/150830'
#                   ]
# raw_names=['ecoli_enri0121','ecoli_enri0228','ecoli_enri0302','ecoli_frac_150821','ecoli_frac_150830']

# path_py='rename_leiker_sp_title.py'
# engine='pLink2'
# for path_folder,rawname in zip(path_data_homes,raw_names):
#     os.system('echo rename %s begin'%path_folder)
#     os.system('python %s %s %s %s'%(path_py, path_folder, rawname, engine))
#     os.system('echo rename %s end'%path_folder)
#     os.system('echo ----------------------------------------------')

#############################################################################################




#############################################################################################
# 4. 合并ecoli-leiker的txt

# path_data_homes=[r'/data/zlchen/pDeepXL/data/Leiker_elife/5.E.coli_lysates/enri0121_undigested_by_RNase',
#                   r'/data/zlchen/pDeepXL/data/Leiker_elife/5.E.coli_lysates/enri0228',
#                   r'/data/zlchen/pDeepXL/data/Leiker_elife/5.E.coli_lysates/enri0302',
#                   r'/data/zlchen/pDeepXL/data/Leiker_elife/5.E.coli_lysates/ribofree/frac/150821',
#                   r'/data/zlchen/pDeepXL/data/Leiker_elife/5.E.coli_lysates/ribofree/frac/150830'
#                   ]

# path_py='merge_txt.py' # 可能需要删除该py的path_txt和path_pkl路径中的_filtered
# engine='pLink2'
# concat_folders=' '.join(path_data_homes)
# pfinaltxt=r'/data/zlchen/pDeepXL/data/Leiker_elife/5.E.coli_lysates/pLink2_data/%s_match_info.txt'%(engine)
# pfinalpkl=r'/data/zlchen/pDeepXL/data/Leiker_elife/5.E.coli_lysates/pLink2_data/%s_match_info.pkl'%(engine)
# os.system('echo merge all begin')
# os.system('python %s %s "" %s %s %s'%(path_py, engine, pfinaltxt, pfinalpkl, concat_folders))
# os.system('echo merge all end')
# os.system('echo ----------------------------------------------')

#############################################################################################



# 后续操作可以把ecoli-leiker数据集和其他数据集放到一起批量处理了
# path_data_homes=[r'/data/zlchen/pDeepXL/data/PXD017620',
#                  r'/data/zlchen/pDeepXL/data/PXD016554/DSS/B_subtilis',
#                  r'/data/zlchen/pDeepXL/data/PXD016554/DSS/B_cereus',
#                  r'/data/zlchen/pDeepXL/data/PXD019926/DSS/HEK293',
#                  r'/data/zlchen/pDeepXL/data/PXD017695',
#                  r'/data/zlchen/pDeepXL/data/PXD014675',
#                  r'/data/zlchen/pDeepXL/data/lili',
#                  r'/data/zlchen/pDeepXL/data/Leiker_elife/5.E.coli_lysates']



#############################################################################################
# 5. 使用电荷、长度进行过滤

# path_py='filter_txt.py'
# engine='pLink2'
# for fid,phome in enumerate(path_data_homes):
#     os.system('echo %d folder begin'%fid)
#     os.system('python %s %s %s'%(path_py, phome, engine))
#     os.system('echo %d folder end'%fid)
#     os.system('echo ----------------------------------------------')

#############################################################################################




#############################################################################################
# 6. 对每个数据集，划分训练集、验证集、测试集，比例是6:2:2
# 对于unseen test dataset，修改py让test ratio=1.0
# 对于fine tune数据集，train:val:test=3:1:6


# path_py='split_train_set_txt.py'
# engine='pLink2'
# for fid,phome in enumerate(path_data_homes):
#     os.system('echo %d folder begin'%fid)
#     os.system('python %s %s %s'%(path_py, phome, engine))
#     os.system('echo %d folder end'%fid)
#     os.system('echo ----------------------------------------------')

#############################################################################################





#############################################################################################
# 7. 合并所有数据集的训练集、验证集、测试集

# path_py='merge_txt.py' # 可能需要添加该py的path_txt和path_pkl路径中的_filtered
# engine='pLink2'
# usages=['_train','_test','_val']
# concat_folders=' '.join(path_data_homes)
# for usage in usages:
#     pfinaltxt=r'/data/zlchen/pDeepXL/data/pLink2_data/%s_match_info_filtered%s.txt'%(engine,usage)
#     pfinalpkl=r'/data/zlchen/pDeepXL/data/pLink2_data/%s_match_info_filtered%s.pkl'%(engine,usage)
#     os.system('echo merge %s begin'%usage)
#     os.system('python %s %s %s %s %s %s'%(path_py, engine, usage, pfinaltxt, pfinalpkl, concat_folders))
#     os.system('echo merge %s end'%usage)
#     os.system('echo ----------------------------------------------')

#############################################################################################



#############################################################################################
# 8. 把匹配txt信息转换为网络输入dta格式

# # path_py='pLink2_to_dta.py'
# path_py='pLink2_compact_dta.py'
# # # path_data_home=r'/data/zlchen/pDeepXL/data/pLink2_data'

# # # path_data_home=r'/data/zlchen/pDeepXL/data/PXD008550/HumanFOMix_BS3/pLink2_data'
# # path_data_home=r'/data/zlchen/pDeepXL/data/Leiker_elife/6.C.elegans_lysates/N2/pLink2_data'

# path_data_home=r'/data/zlchen/pDeepXL/data/PXD019926/DSS/HEK293/pLink2_data'

# usages=['_train','_test','_val']
# consider=1 # 不可碎裂，考虑xlink离子
# for usage in usages:
#     os.system('echo convert %s begin'%usage)
#     os.system('python %s %s %s %d'%(path_py, path_data_home, usage, consider))
#     os.system('echo convert %s end'%usage)
#     os.system('echo ----------------------------------------------')

#############################################################################################



# for fine tune
#############################################################################################
# 9. 生成不同比例的fine tune数据集
# 只划分train和val

path_py='split_train_set_txt_2parts.py'
engine='pLink2'

# train_nums=[10,50,100,150,200,250,300,500]
# train_nums=[i*0.01 for i in range(5,80,10)]

# train_nums=[i*0.01 for i in range(55,70,10)]
# how=1 # 0绝对数，1比例

train_nums=[100]
how=0 # 0绝对数，1比例

for fid,phome in enumerate(path_data_homes):
    for n in train_nums:
        os.system('echo %d folder %d begin'%(fid,n))
        if how==0:
            os.system('python %s %s %s %d %d'%(path_py, phome, engine, how, n))
        else:
            os.system('python %s %s %s %d %f'%(path_py, phome, engine, how, n))
        os.system('echo %d folder %d end'%(fid,n))
        os.system('echo ----------------------------------------------')

#############################################################################################



#############################################################################################
# 10. 把匹配txt信息转换为网络输入dta格式

path_py='pLink2_to_dta.py'

usages=['_train','_val']
consider=1 # 不可碎裂，考虑xlink离子
for path_data_home in path_data_homes:
    path_fine_tune_folder=r'%s/pLink2_data/fine-tune'%path_data_home
    for usage in usages:
        for n in train_nums:
            if how==1:
                str_train_num='_%d'%(n*100)
            else:
                str_train_num='_%d'%(n)
            os.system('echo convert %s begin'%usage)
            os.system('python %s %s %s %d %s'%(path_py, path_fine_tune_folder, usage, consider, str_train_num))
            os.system('echo convert %s end'%usage)
            os.system('echo ----------------------------------------------')

#############################################################################################
