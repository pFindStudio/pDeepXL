# 将每个子数据集划分为训练集和测试集
# 以母离子为单位进行划分，母离子=序列（交联位点）、修饰、电荷

import pickle
from sklearn.model_selection import train_test_split
from tqdm import tqdm

path_sub_folders=[r'/data/zlchen/pDeepXL/data/PXD017620',
                    r'/data/zlchen/pDeepXL/data/PXD016554/DSS/B_subtilis',
                    r'/data/zlchen/pDeepXL/data/PXD016554/DSS/B_cereus',
                    r'/data/zlchen/pDeepXL/data/PXD019926/DSS/HEK293',
                    r'/data/zlchen/pDeepXL/data/PXD017695',
                    r'/data/zlchen/pDeepXL/data/PXD014675',
                    r'/data/zlchen/pDeepXL/data/lili',
                    r'/data/zlchen/pDeepXL/data/Leiker_elife/5.E.coli_lysates']

consider_xlink_ion = True
total_str_xlion='1-yes-xlion' if consider_xlink_ion else '2-no-xlion'
train_str_xlion='3-yes-xlion-train' if consider_xlink_ion else '4-no-xlion-train'
test_str_xlion='5-yes-xlion-test' if consider_xlink_ion else '6-no-xlion-test'

# engine='pFind3'
engine='pLink2'


def read_dta(path_dta):
    fdtain=open(path_dta)
    dta_lines=fdtain.readlines()
    fdtain.close()
    return dta_lines

def write_dta(path_dta, lines):
    fdtaout=open(path_dta,'w')
    for line in lines:
        fdtaout.write(line)
    fdtaout.close()

def read_pkl(path_pkl):
    fformattedpkl = open(path_pkl, 'rb')
    T,L,X,Y = pickle.load(fformattedpkl)
    fformattedpkl.close()
    return T,L,X,Y


def write_pkl(path_pkl, T, L, X, Y):
    fpklout=open(path_pkl,'wb')
    pickle.dump([T,L,X,Y],fpklout)
    fpklout.close()


total_train,total_test=0,0

for path_folder in tqdm(path_sub_folders):

    print('working for %s...'%path_folder)

    path_sub_folder = r'%s/%s_data'%(path_folder, engine)
    path_dta=r'%s/%s-%s.dta'%(path_sub_folder, engine, total_str_xlion)
    path_pkl=r'%s/%s-%s.pkl'%(path_sub_folder, engine, total_str_xlion)

    dta_lines=read_dta(path_dta)
    print('dta=%s,#lines=%d'%(path_dta,len(dta_lines)))

    T,L,X,Y = read_pkl(path_pkl)
    print('pkl=%s,size=%d'%(path_pkl,len(T)))

    dta_train, dta_test, T_train, T_test, L_train, L_test, X_train, X_test, Y_train, Y_test = train_test_split(dta_lines,T,L,X,Y , test_size=0.2, random_state=42)

    total_train+=len(dta_train)
    print('train #dtas=%d, #pkls=%d'%(len(dta_train), len(T_train)))
    path_train_dta=r'%s/%s-%s.dta'%(path_sub_folder,engine,train_str_xlion)
    path_train_pkl=r'%s/%s-%s.pkl'%(path_sub_folder,engine,train_str_xlion)
    write_dta(path_train_dta, dta_train)
    write_pkl(path_train_pkl, T_train, L_train, X_train, Y_train)
    
    total_test+=len(dta_test)
    print('test #dtas=%d, #pkls=%d'%(len(dta_test), len(T_test)))
    path_test_dta=r'%s/%s-%s.dta'%(path_sub_folder,engine,test_str_xlion)
    path_test_pkl=r'%s/%s-%s.pkl'%(path_sub_folder,engine,test_str_xlion)
    write_dta(path_test_dta, dta_test)
    write_pkl(path_test_pkl, T_test, L_test, X_test, Y_test)


print('total_instance=%d, total_train=%d, total_test=%d'%(total_train + total_test, total_train,total_test))