# 调试各种预处理问题

# 检查pLink2输入维度哪个数据不是130维
import pickle

pdta=r'/data/zlchen/pDeepXL/data/Leiker_elife/5.E.coli_lysates/pLink2_data/pLink2.dta'

fin=open(pdta)
lines=fin.readlines()
fin.close()

print(len(lines))

ppkl=r'/data/zlchen/pDeepXL/data/Leiker_elife/5.E.coli_lysates/pLink2_data/pLink2.pkl'

fformattedpkl = open(ppkl, 'rb')
T,L,X,Y = pickle.load(fformattedpkl)
fformattedpkl.close()

for i,(title,l,x,y) in enumerate(zip(T,L,X,Y)):
    found=False
    for j,x_ts in enumerate(x):
        if len(x_ts) != 130:
            print('line ', i,' ',title,'timestep ',j)
            found=True
            break
    if found:
        break