# 过滤非法PSM、CSM

import os
import configparser
import pickle
from tqdm import tqdm
import sys
from peptide_featurer import PeptideFeaturer

config = configparser.ConfigParser()
config.read('/data/zlchen/pDeepXL/code/pDeepXL/config.ini')
pf = PeptideFeaturer(config)

MIN_PREC_CHARGE=int(config['DEFAULT']['min_prec_charge'])
MAX_PREC_CHARGE=int(config['DEFAULT']['max_prec_charge'])

MIN_PEPTIDE_LEN=int(config['DEFAULT']['min_peptide_len'])
MAX_PEPTIDE_LEN=int(config['DEFAULT']['max_peptide_len'])


def is_csm_valid(prec_charge,seq1,seq2):
    l1,l2 = len(seq1),len(seq2)
    if not (prec_charge >= MIN_PREC_CHARGE and prec_charge <= MAX_PREC_CHARGE \
            and l1 >= MIN_PEPTIDE_LEN and l1 <= MAX_PEPTIDE_LEN \
            and l2 >= MIN_PEPTIDE_LEN and l2 <= MAX_PEPTIDE_LEN): # 电荷与长度的约束
        return False
    if (not pf.IsSeqValid(seq1)) or (not pf.IsSeqValid(seq2)): # 序列包含非法字符
        return False
    return True


def is_psm_valid(prec_charge, seq):
    lseq = len(seq)
    if not (prec_charge >= MIN_PREC_CHARGE and prec_charge <= MAX_PREC_CHARGE \
            and lseq >= MIN_PEPTIDE_LEN and lseq <= MAX_PEPTIDE_LEN): # 电荷与长度的约束
        return False
    if not pf.IsSeqValid(seq): # 序列包含非法字符
        return False
    return True


def filter_txt(path_txt, path_filter_txt, engine):
    fin=open(path_txt)
    lines=fin.readlines()
    fin.close()
    
    total,valid=len(lines)-1,0

    fout=open(path_filter_txt,'w')
    fout.write(lines[0])
    
    if engine=='pLink2':
        for i in range(1,len(lines)):
            contents=lines[i].split('\t')
            prec_charge=int(contents[2])
            seq1=contents[8].strip()
            seq2=contents[11].strip()
            if is_csm_valid(prec_charge, seq1, seq2):
                valid+=1
                fout.write(lines[i])
    else:
        for i in range(1,len(lines)):
            contents=lines[i].split('\t')
            prec_charge=int(contents[2])
            seq=contents[3].strip()
            if is_psm_valid(prec_charge, seq):
                valid+=1
                fout.write(lines[i])

    fout.close()
    print('txt=%s,total=%d,valid=%d,validpercentage=%f'%(path_txt,total,valid,valid/total))

def filter_pkl(path_pkl, path_filter_pkl, engine):
    frawpkl = open(path_pkl, 'rb')
    PSMs = pickle.load(frawpkl)
    frawpkl.close()

    total,valid=len(PSMs),0

    filtered_psms=[]
    if engine=='pLink2':
        for psm in PSMs:
            title,scan,prec_charge,instrument,NCE_low, NCE_medium, NCE_high,LinkerName,seq1,mods1,linksite1,seq2,mods2,linksite2,alpha_mints_norm,beta_mints_norm=psm
            if is_csm_valid(prec_charge, seq1, seq2):
                valid+=1
                filtered_psms.append(psm)
    else:
        for psm in PSMs:
            title,scan,prec_charge,seq,mods,inst,NCE_low,NCE_medium,NCE_high,matched_b1b2y1y2=psm
            if is_psm_valid(prec_charge, seq):
                valid+=1
                filtered_psms.append(psm)

    fpklout=open(path_filter_pkl,'wb')
    pickle.dump(filtered_psms,fpklout)
    fpklout.close()

    print('pkl=%s,total=%d,valid=%d,validpercentage=%f'%(path_txt,total,valid,valid/total))


if __name__ == "__main__":
    print('runing main...')

    # 如果有命令行参数的话
    if len(sys.argv) == 3:
        print('有命令行参数')
        print('参数个数为:', len(sys.argv), '个参数。')
        print('参数列表:', str(sys.argv))
        path_folder,engine=sys.argv[1],sys.argv[2]
        print('path_folder=%s'%path_folder)
        print('engine=%s'%engine)
    else:
        print('无命令行参数，或参数个数不等于3')
        path_folder=r'/data/zlchen/pDeepXL/data/PXD019926/DSS/HEK293'
        engine='pFind3'
        # engine='pLink2'

    path_sub_folder = r'%s/%s_data'%(path_folder, engine)
    path_txt=r'%s/%s_match_info.txt'%(path_sub_folder, engine)
    path_pkl=r'%s/%s_match_info.pkl'%(path_sub_folder, engine)

    path_filter_txt=r'%s/%s_match_info_filtered.txt'%(path_sub_folder, engine)
    path_filter_pkl=r'%s/%s_match_info_filtered.pkl'%(path_sub_folder, engine)
    filter_txt(path_txt, path_filter_txt, engine)
    filter_pkl(path_pkl, path_filter_pkl, engine)

