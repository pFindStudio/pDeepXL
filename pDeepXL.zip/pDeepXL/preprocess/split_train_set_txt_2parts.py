# 划分txt文件
# 将每个子数据集划分为训练集、验证集和测试集
# 以母离子为单位进行划分，母离子=序列（交联位点）、修饰、电荷
# 只划分train和validation，且传入train的绝对数目，总数-train=validation

import pickle
from sklearn.model_selection import train_test_split
from tqdm import tqdm
import sys
import random

def get_precursor_str(psm, engine):
    precursor_str=''
    if engine=='pLink2':
        title,scan,prec_charge,instrument,NCE_low, NCE_medium, NCE_high,LinkerName,seq1,mods1,linksite1,seq2,mods2,linksite2,alpha_mints_norm,beta_mints_norm=psm
        contents=[seq1,str(mods1),str(linksite1),seq2,str(mods2),str(linksite2),str(prec_charge)]
        precursor_str='|'.join(contents)
    else:
        title,scan,prec_charge,seq,mods,inst,NCE_low,NCE_medium,NCE_high,matched_b1b2y1y2=psm
        contents=[seq,str(mods),str(prec_charge)]
        precursor_str='|'.join(contents)
    return precursor_str

def get_precursor_dict(mpPklPSMs, engine):
    mpPrecursor2PSMs={}
    for title,psm in mpPklPSMs.items():
        precursor_str=get_precursor_str(psm, engine)
        if precursor_str not in mpPrecursor2PSMs:
            mpPrecursor2PSMs[precursor_str]=[]
        mpPrecursor2PSMs[precursor_str].append(psm)
    return mpPrecursor2PSMs

def read_txt(path_txt):
    ftxtin=open(path_txt)
    txt_lines=ftxtin.readlines()
    ftxtin.close()
    header=txt_lines[0]
    mpTxtPSMs={}
    for i in range(1,len(txt_lines)):
        title=txt_lines[i].split('\t')[0]
        mpTxtPSMs[title]=txt_lines[i]
    return mpTxtPSMs,header

def write_txt(path_txt, lines):
    ftxtout=open(path_txt,'w')
    for line in lines:
        ftxtout.write(line)
    ftxtout.close()

def read_pkl(path_pkl):
    frawpkl = open(path_pkl, 'rb')
    allPSMs = pickle.load(frawpkl)
    frawpkl.close()
    mpPklPSMs={}
    for psm in allPSMs:
        title=psm[0]
        mpPklPSMs[title]=psm
    return mpPklPSMs
    

def write_pkl(path_pkl, allPSMs):
    fpklout=open(path_pkl,'wb')
    pickle.dump(allPSMs,fpklout)
    fpklout.close()

def write_precursors(path_txt, precursors):
    fout=open(path_txt,'w')
    fout.write('\n'.join(precursors))
    fout.close()



if __name__ == "__main__":
    print('runing main...')

    # 如果有命令行参数的话
    if len(sys.argv) == 5:
        print('有命令行参数')
        print('参数个数为:', len(sys.argv), '个参数。')
        print('参数列表:', str(sys.argv))
        path_folder,engine,how,num_train=sys.argv[1:]
        how=int(how)
        print('path_folder=%s'%path_folder)
        print('engine=%s'%engine)
        print('how=%d'%how)
        if how==0:
            num_train=int(num_train) # 绝对数
            print('num_train=%d'%num_train)
            subfolder='fine-tune'
        else:
            num_train=float(num_train) # 比例
            print('num_train=%f'%num_train)
            #####如果按比例划分
            subfolder='fine-tune'
            num_train*=100
            ###
    else:
        print('无命令行参数，或参数个数不等于5')
        path_folder=r'/data/zlchen/pDeepXL/data/PXD019926/DSS/HEK293'
        engine='pFind3'
        # engine='pLink2'
        num_train=100
        subfolder=''


    print('\n\n-------\nworking for %s...'%path_folder)
    path_sub_folder = r'%s/%s_data'%(path_folder, engine)
    path_txt=r'%s/%s_match_info_filtered.txt'%(path_sub_folder, engine)
    path_pkl=r'%s/%s_match_info_filtered.pkl'%(path_sub_folder, engine)

    mpTxtPSMs,txt_header=read_txt(path_txt)
    print('txt=%s,#psms=%d'%(path_txt,len(mpTxtPSMs)))

    mpPklPSMs = read_pkl(path_pkl)
    print('pkl=%s,size=%d'%(path_pkl,len(mpPklPSMs)))

    assert len(mpTxtPSMs) == len(mpPklPSMs)

    mpPrecursor2PSMs=get_precursor_dict(mpPklPSMs, engine)
    all_precursors=list(mpPrecursor2PSMs.keys())

    #--------------------------2020.11.28
    precursor_train, precursor_val = train_test_split(all_precursors, train_size=num_train, random_state=19) # 42 对母离子进行划分训练和测试
    precursor_test=[]
    #--------------------------

    train_psms_for_pkl, test_psms_for_pkl, val_psms_for_pkl=[],[],[]
    train_psms_for_txt, test_psms_for_txt, val_psms_for_txt=[txt_header],[txt_header],[txt_header]

    MAX_NUM_SPEC = 10 # 每个母离子最多采样MAX_NUM_SPEC张谱图，既减小了数据量，又避免了数据分布过于不均衡
    for p in precursor_train:
        psms = mpPrecursor2PSMs[p]
        if len(psms) > MAX_NUM_SPEC:
            psms=random.sample(psms, MAX_NUM_SPEC)
        for psm in psms:
            title=psm[0]
            train_psms_for_pkl.append(psm)
            train_psms_for_txt.append(mpTxtPSMs[title])
    
    for p in precursor_test:
        psms = mpPrecursor2PSMs[p]
        if len(psms) > MAX_NUM_SPEC:
            psms=random.sample(psms, MAX_NUM_SPEC)
        for psm in psms:
            title=psm[0]
            test_psms_for_pkl.append(psm)
            test_psms_for_txt.append(mpTxtPSMs[title])

    for p in precursor_val:
        psms = mpPrecursor2PSMs[p]
        if len(psms) > MAX_NUM_SPEC:
            psms=random.sample(psms, MAX_NUM_SPEC)
        for psm in psms:
            title=psm[0]
            val_psms_for_pkl.append(psm)
            val_psms_for_txt.append(mpTxtPSMs[title])


    # print('train #psms=%d,#precursors=%d'%(len(train_psms_for_pkl),len(precursor_train)))
    path_train_txt=r'%s/%s/%s_match_info_filtered_train_%d.txt'%(path_sub_folder,subfolder,engine,num_train)
    path_train_pkl=r'%s/%s/%s_match_info_filtered_train_%d.pkl'%(path_sub_folder,subfolder,engine,num_train)
    write_txt(path_train_txt, train_psms_for_txt)
    write_pkl(path_train_pkl,train_psms_for_pkl)
    
    # print('test #psms=%d,#precursors=%d'%(len(test_psms_for_pkl),len(precursor_test)))
    path_test_txt=r'%s/%s/%s_match_info_filtered_test_%d.txt'%(path_sub_folder,subfolder,engine,num_train)
    path_test_pkl=r'%s/%s/%s_match_info_filtered_test_%d.pkl'%(path_sub_folder,subfolder,engine,num_train)
    write_txt(path_test_txt, test_psms_for_txt)
    write_pkl(path_test_pkl, test_psms_for_pkl)

    # print('val #psms=%d,#precursors=%d'%(len(val_psms_for_pkl),len(precursor_val)))
    path_val_txt=r'%s/%s/%s_match_info_filtered_val_%d.txt'%(path_sub_folder,subfolder,engine,num_train)
    path_val_pkl=r'%s/%s/%s_match_info_filtered_val_%d.pkl'%(path_sub_folder,subfolder,engine,num_train)
    write_txt(path_val_txt, val_psms_for_txt)
    write_pkl(path_val_pkl, val_psms_for_pkl)

    # 打印表格，方便复制粘贴
    print('#train psms,#train precursors,#val psms,#val precursors,#test psms,#test precursors')
    print('%d,%d,%d,%d,%d,%d'%(len(train_psms_for_pkl),len(precursor_train),len(val_psms_for_pkl),len(precursor_val),len(test_psms_for_pkl),len(precursor_test)))

    path_train_precursor=r'%s/%s/%s_filtered_train_precursors_%d.txt'%(path_sub_folder,subfolder,engine,num_train)
    path_test_precursor=r'%s/%s/%s_filtered_test_precursors_%d.txt'%(path_sub_folder,subfolder,engine,num_train)
    path_val_precursor=r'%s/%s/%s_filtered_val_precursors_%d.txt'%(path_sub_folder,subfolder,engine,num_train)
    write_precursors(path_train_precursor, precursor_train)
    write_precursors(path_test_precursor, precursor_test)
    write_precursors(path_val_precursor, precursor_val)

