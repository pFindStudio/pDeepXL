# 针对Iwan, Henning的数据
# 合并pLink2两种数据库的鉴定结果

path_prodb_csv=r'/data/zlchen/pDeepXL/data/PXD016554/DSS/B_subtilis/pLink2_search/reports/26SProteasome_Scerevisiae_2020.07.24.filtered_cross-linked_spectra.csv'
path_pepdb_csv=r'/data/zlchen/pDeepXL/data/PXD016554/DSS/B_subtilis/pLink2_search_rev_pep/reports/26SProteasome_Scerevisiae_2020.07.24.filtered_cross-linked_spectra.csv'

path_merged_csv=r'/data/zlchen/pDeepXL/data/PXD016554/DSS/B_subtilis/pLink2_id_psm/prodb_pepdb_merged.csv'

def read1csv(path):
    fin=open(path)
    lines=fin.readlines()
    fin.close()

    mpAns={}
    for i in range(1,len(lines)):
        contents=lines[i].split(',')
        title=contents[1].strip()
        mpAns[title]=lines[i]
    return lines[0],mpAns


header,mpProAns=read1csv(path_prodb_csv)
header,mpPepAns=read1csv(path_pepdb_csv)

print(len(mpProAns))
print(len(mpPepAns))

n=0
fout=open(path_merged_csv,'w')
fout.write(header)
for title,line in mpProAns.items():
    fout.write(line)
    n+=1

for title,line in mpPepAns.items(): # 合并pep db单独多鉴定到的csm
    if title not in mpProAns:
        fout.write(line)
        n+=1

fout.close()
print(n)

