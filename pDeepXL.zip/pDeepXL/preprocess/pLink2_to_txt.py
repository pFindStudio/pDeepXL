import sys
sys.path.append("..")
import utils
import mass_util
import os
from concurrent.futures import ThreadPoolExecutor, wait, ALL_COMPLETED, FIRST_COMPLETED, ProcessPoolExecutor
import configparser
import pickle

# 读取pLink2过滤后的CSM，进行肽谱匹配
# 对于匹配比较好的CSM，输出匹配到的b/y离子强度

# 如果有命令行参数的话
if len(sys.argv) == 7:
    print('有命令行参数')
    print('参数个数为:', len(sys.argv), '个参数。')
    print('参数列表:', str(sys.argv))
    path_data_home,instrument=sys.argv[1],sys.argv[2]
    NCE_low,NCE_medium,NCE_high=list(map(float,sys.argv[3:6]))
    LinkerName=sys.argv[6]
    print('path_data_home=%s'%path_data_home)
    print('instrument=%s'%instrument)
    print('NCE_low=%f,NCE_medium=%f,NCE_high=%f'%(NCE_low,NCE_medium,NCE_high))
    print('LinkerName=%s'%LinkerName)
else:
    print('无命令行参数，或参数个数不等于7')
    path_data_home = r'/data/zlchen/pDeepXL/data/PXD019926/DSS/HEK293'
    LinkerName='DSS'
    instrument = 'Lumos'
    # 目前只支持单能量或三能量
    NCE_low = 0.0
    NCE_medium = 30.0
    NCE_high = 0.0


path_pLink2_id_folder = r'%s/pLink2_id_psm'%path_data_home
path_pf2_folder = r'%s/pf2'%path_data_home
path_match_raw_info_txt = r'%s/pLink2_data/pLink2_match_info.txt'%path_data_home
path_match_raw_info_pkl = r'%s/pLink2_data/pLink2_match_info.pkl'%path_data_home


allpsms=[]
path_ids=os.listdir(path_pLink2_id_folder)
for pid in path_ids:
    cur_psms = utils.ReadpLinkFilteredPSM5(r'%s/%s'%(path_pLink2_id_folder,pid))
    print('f=%s,len=%d'%(pid,len(cur_psms)))
    allpsms.extend(cur_psms)

print('allpsms=%d'%len(allpsms))

def run(path_pf2):
    pid = os.getpid()
    rawname = os.path.basename(path_pf2)[:-10]
    print('pid=%s,reading pf2=%s'%(pid, rawname))
    pf2title, mpSpec = utils.load_pf2(path_pf2)

    subinstrument = instrument
    prefix_path = os.path.splitext(path_pf2)[0][:-6]
    instrument_summary_path = r'%s.sum.csv'%prefix_path
    if os.path.exists(instrument_summary_path):
        subinstrument = utils.read_instrument_name(instrument_summary_path)
        print('pid=%s,pf2=%s,subinstrument=%s'%(pid, rawname, subinstrument))

    mpMS2Energy={}
    energy_info_path = r'%s.csv'%prefix_path
    if os.path.exists(energy_info_path):
        mpMS2Energy = utils.read_ms2_energy(energy_info_path)
        print('pid=%s,pf2=%s,loaded own ms2 energy info'%(pid, rawname))

    print('pid=%s,matching psm'%(pid))
    ans = []

    nn=len(allpsms)
    batchsize=int(nn/10)

    for mm,psm in enumerate(allpsms):
        if mm%batchsize==0:
            print('pid=%s,progress=%d/%d'%(pid,mm,nn))
            
        title,scan,prec_charge,exp_mh,seq1,mods1,linksite1,seq2,mods2,linksite2=psm
        curraw=title.split('.')[0]
        if curraw != rawname or prec_charge < 2:
            continue
        
        if not utils.is_mod_valid(mods1) or not utils.is_mod_valid(mods2): # 不考虑特殊修饰
            continue
        
        b1mass1,b2mass1,y1mass1,y2mass1,b1mass2,b2mass2,y1mass2,y2mass2=mass_util.calfragmass4xl(seq1,mods1,linksite1,seq2,mods2,linksite2,LinkerName)

        alpha_ions=[b1mass1,b2mass1,y1mass1,y2mass1]
        beta_ions=[b1mass2,b2mass2,y1mass2,y2mass2]

        ion_charges=(1,2,1,2)
        ion_names=('b1','b2','y1','y2')

        alpha_mints, beta_mints=[],[]
        spec = mpSpec[title]

        #------匹配alpha--------
        mic=0
        for ion_mzs, ion_charge, ion_name in zip(alpha_ions, ion_charges, ion_names):
            if prec_charge == 2 and ion_charge == 2: # 2+母离子只匹配1+碎片离子
                alpha_mints.append([0.0]*len(ion_mzs))
            else:
                cur_mint=utils.matchbatch(spec,ion_mzs,ion_charge)
                alpha_mints.append(cur_mint)
                mic+=sum([1 if m >0.0 else 0 for m in cur_mint])

        if mic < len(seq1): # 要求匹配谱峰数不小于肽段长度
            continue
        
        #------匹配beta--------
        mic=0
        for ion_mzs, ion_charge, ion_name in zip(beta_ions, ion_charges, ion_names):
            if prec_charge == 2 and ion_charge == 2: # 2+母离子只匹配1+碎片离子
                beta_mints.append([0.0]*len(ion_mzs))
            else:
                cur_mint=utils.matchbatch(spec,ion_mzs,ion_charge)
                beta_mints.append(cur_mint)
                mic+=sum([1 if m >0.0 else 0 for m in cur_mint])

        if mic < len(seq2): # 要求匹配谱峰数不小于肽段长度
            continue

        alpha_max_int=max([max(i) for i in alpha_mints])
        beta_max_int=max([max(i) for i in beta_mints])
        cur_max_int=max(alpha_max_int,beta_max_int)

        alpha_mints_norm=[[i/cur_max_int for i in j] for j in alpha_mints]
        beta_mints_norm=[[i/cur_max_int for i in j] for j in beta_mints]

        # 2020.11.18，交联离子占位单肽离子位置，方便transfer
        # 需要新增clv-short的Padding全0向量
        alpha_clv_shorts=[[0.0]*len(seq1) for i in range(4)]
        beta_clv_shorts=[[0.0]*len(seq2) for i in range(4)]
        alpha_norm=alpha_mints_norm+alpha_clv_shorts
        beta_norm=beta_mints_norm+beta_clv_shorts
        ########################

        # 2020.11.5，把匹配离子拆开成单肽和交联离子
        # 每个都包含b1+,b2+,y1+,y2+
        # alpha_linears,alpha_xlinks=[],[]
        # beta_linears,beta_xlinks=[],[]
        # for i in range(2): # b ions
        #     a_linear,a_xlink=[0.0]*len(seq1),[0.0]*len(seq1)
        #     b_linear,b_xlink=[0.0]*len(seq2),[0.0]*len(seq2)

        #     a_linear[:linksite1]=alpha_mints_norm[i][:linksite1]
        #     a_xlink[linksite1:]=alpha_mints_norm[i][linksite1:]
        #     alpha_linears.append(a_linear)
        #     alpha_xlinks.append(a_xlink)

        #     b_linear[:linksite2]=beta_mints_norm[i][:linksite2]
        #     b_xlink[linksite2:]=beta_mints_norm[i][linksite2:]
        #     beta_linears.append(b_linear)
        #     beta_xlinks.append(b_xlink)

        # for i in range(2,4): # y ions
        #     a_linear,a_xlink=[0.0]*len(seq1),[0.0]*len(seq1)
        #     b_linear,b_xlink=[0.0]*len(seq2),[0.0]*len(seq2)

        #     a_linear[linksite1+1:]=alpha_mints_norm[i][linksite1+1:]
        #     a_xlink[:linksite1+1]=alpha_mints_norm[i][:linksite1+1]
        #     alpha_linears.append(a_linear)
        #     alpha_xlinks.append(a_xlink)

        #     b_linear[linksite2+1:]=beta_mints_norm[i][linksite2+1:]
        #     b_xlink[:linksite2+1]=beta_mints_norm[i][:linksite2+1]
        #     beta_linears.append(b_linear)
        #     beta_xlinks.append(b_xlink)

        # alpha_clv_long_shorts=[[0.0]*len(seq1) for i in range(8)]
        # beta_clv_long_shorts=[[0.0]*len(seq2) for i in range(8)]

        # alpha_norm=alpha_linears+alpha_xlinks+alpha_clv_long_shorts
        # beta_norm=beta_linears+beta_xlinks+beta_clv_long_shorts
        #####################

        subNCE_low, subNCE_medium, subNCE_high = NCE_low, NCE_medium, NCE_high

        if len(mpMS2Energy) != 0:
            if scan in mpMS2Energy:
                subNCE_low, subNCE_medium, subNCE_high=mpMS2Energy[scan]
            else:
                continue # 有能量文件，但这个scan不在该能量文件内，说明该scan的碎裂不是hcd
        
        # 没有能量文件，则用默认手工设定的能量

        ans.append([title,scan,prec_charge,subinstrument,subNCE_low, subNCE_medium, subNCE_high,LinkerName,seq1,mods1,linksite1,seq2,mods2,linksite2,alpha_norm,beta_norm])

        # for debug!!!!!!!!!!!!!!!!
        # if len(ans) >= 10:
        #     break

    print('pid=%s,done'%(pid))
    return ans
    

if __name__ == "__main__":
    print('runing main...')

    executor = ProcessPoolExecutor(max_workers=16)
    processes = []
    files=os.listdir(path_pf2_folder)
    
    for f in files:
        fname,fext=os.path.splitext(f)
        if fext=='.pf2':
            path_pf2 = r'%s/%s'%(path_pf2_folder,f)
            processes.append(executor.submit(run, path_pf2))
    
    executor.shutdown(wait=True)
    print("main done.")
    
    merged_ans=[]
    for p in processes:
        merged_ans.extend(p.result())
    
    header=['title','scan','charge','instrument','NCE_low', 'NCE_medium', 'NCE_high','crosslinker','seq1','mods1','linksite1','seq2','mods2','linksite2','seq1_matched_linear-b1b2y1y2|xlink-b1b2y1y2|clv-long-b1b2y1y2|clv-short-b1b2y1y2','seq2_matched_linear-b1b2y1y2|xlink-b1b2y1y2|clv-long-b1b2y1y2|clv-short-b1b2y1y2']
    fout=open(path_match_raw_info_txt,'w')
    fout.write('\t'.join(header)+'\n')
    
    for psm in merged_ans:
        fout.write('\t'.join(map(str,psm))+'\n')
    fout.close()
    
    fout=open(path_match_raw_info_pkl,'wb')
    pickle.dump(merged_ans,fout,protocol=4)
    fout.close()
