import sys
sys.path.append("..")
import os
import pickle
import matplotlib.pyplot as plt
import pandas as pd

path_data_home = r'/data/zlchen/pDeepXL/data/Leiker_elife/5.E.coli_lysates/enri0121_undigested_by_RNase'
path_match_raw_info_txt = r'%s/pLink2_data/pLink2_match_info.txt'%path_data_home


df = pd.read_csv(path_match_raw_info_txt, sep='\t')
df['length1'] = df.apply(lambda row: len(row['seq1']), axis=1)
df['length2'] = df.apply(lambda row: len(row['seq2']), axis=1)

print(df.columns)
print(df['charge'].value_counts())
print(df['length1'].value_counts())
print(df['length2'].value_counts())