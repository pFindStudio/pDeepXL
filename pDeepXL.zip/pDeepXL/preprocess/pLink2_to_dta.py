import os
import configparser
import pickle
from tqdm import tqdm
import sys
from peptide_featurer import PeptideFeaturer

config = configparser.ConfigParser()
config.read('/data/zlchen/pDeepXL/code/pDeepXL/config.ini')
pf = PeptideFeaturer(config)

MIN_PREC_CHARGE=int(config['DEFAULT']['min_prec_charge'])
MAX_PREC_CHARGE=int(config['DEFAULT']['max_prec_charge'])

MIN_PEPTIDE_LEN=int(config['DEFAULT']['min_peptide_len'])
MAX_PEPTIDE_LEN=int(config['DEFAULT']['max_peptide_len'])

def ConvertpLink2ToTensor(path_match_raw_info_pkl, path_match_formatted_dta, path_match_formatted_pkl, consider_xlink_ion):
    frawpkl = open(path_match_raw_info_pkl, 'rb')
    allPSMs = pickle.load(frawpkl)
    frawpkl.close()

    T,L,X,Y=[],[],[],[] # L表示总长度
    PT=[] # 肽段类型peptide type，0 for linear, 1 for non-clv, 2 for clv
    L1,L2,S1,S2=[],[],[],[] # α和β的长度，及交联位点，如果是单肽（P=0），则这几个值都是-1（无效）

    cur_pt=1 if consider_xlink_ion else 2

    fdtaout=open(path_match_formatted_dta,'w')
    for psm in tqdm(allPSMs):
        title,scan,prec_charge,instrument,NCE_low, NCE_medium, NCE_high,LinkerName,seq1,mods1,linksite1,seq2,mods2,linksite2,alpha_mints_norm,beta_mints_norm=psm
        l1,l2 = len(seq1),len(seq2)

        # seq1_linear_b1s,seq1_linear_b2s,seq1_linear_y1s,seq1_linear_y2s,\
        # seq1_xlink_b1s,seq1_xlink_b2s,seq1_xlink_y1s,seq1_xlink_y2s, \
        # seq1_clv_long_b1s,seq1_clv_long_b2s,seq1_clv_long_y1s,seq1_clv_long_y2s, \
        # seq1_clv_short_b1s,seq1_clv_short_b2s,seq1_clv_short_y1s,seq1_clv_short_y2s \
        # =alpha_mints_norm

        # seq2_linear_b1s,seq2_linear_b2s,seq2_linear_y1s,seq2_linear_y2s, \
        # seq2_xlink_b1s,seq2_xlink_b2s,seq2_xlink_y1s,seq2_xlink_y2s, \
        # seq2_clv_long_b1s,seq2_clv_long_b2s,seq2_clv_long_y1s,seq2_clv_long_y2s, \
        # seq2_clv_short_b1s,seq2_clv_short_b2s,seq2_clv_short_y1s,seq2_clv_short_y2s, \
        # =beta_mints_norm

        seq1_vec,seq1_aa_mod_sum = pf.Sequence2Vec(seq1,mods1,prec_charge,instrument,NCE_low, NCE_medium, NCE_high,LinkerName,linksite1,False)
        seq2_vec,seq2_aa_mod_sum = pf.Sequence2Vec(seq2,mods2,prec_charge,instrument,NCE_low, NCE_medium, NCE_high,LinkerName,linksite2,False)

        # 对于不可碎裂交联剂，累加和需要考虑互补肽段
        if consider_xlink_ion:
            seq1_vec = pf.AddAnotherSeq(seq1_vec, linksite1, seq2_aa_mod_sum)
            seq2_vec = pf.AddAnotherSeq(seq2_vec, linksite2, seq1_aa_mod_sum)

        intensity1_vec,intensity2_vec=[],[]
        
        for i in range(0, l1-1):
            # inten_vec = [seq1_b1s[i],seq1_b2s[i],seq1_y1s[i+1],seq1_y2s[i+1]]
            inten_vec = []
            for j in range(len(alpha_mints_norm)):
                if j%4<=1: # b1+,b2+
                    inten_vec.append(alpha_mints_norm[j][i])
                else: # y1+, y2+
                    inten_vec.append(alpha_mints_norm[j][i+1])

            intensity1_vec.append(inten_vec)
        # intensity1_vec=pf.PaddingZero(intensity1_vec)

        for i in range(0, l2-1):
            # inten_vec = [seq2_b1s[i],seq2_b2s[i],seq2_y1s[i+1],seq2_y2s[i+1]]
            inten_vec = []
            for j in range(len(beta_mints_norm)):
                if j%4<=1: # b1+,b2+
                    inten_vec.append(beta_mints_norm[j][i])
                else: # y1+, y2+
                    inten_vec.append(beta_mints_norm[j][i+1])
            intensity2_vec.append(inten_vec)
        # intensity2_vec=pf.PaddingZero(intensity2_vec)

        linker_symbol_vec = [pf.LinkerSymbol2Vec()]
        linker_symbol_intensity_vec = [[0]*len(intensity1_vec[0])]

        X.append(seq1_vec+linker_symbol_vec+seq2_vec)
        Y.append(intensity1_vec+linker_symbol_intensity_vec+intensity2_vec)
        L.append(l1-1+l2-1+1)
        T.append(title+'1') # title标记是正序还是反序

        PT.append(cur_pt)
        L1.append(l1-1)
        L2.append(l2-1)
        S1.append(linksite1)
        S2.append(linksite2)

        onesample=[title+'1',cur_pt,l1-1+l2-1+1,l1-1,l2-1,linksite1,linksite2,seq1_vec+linker_symbol_vec+seq2_vec,intensity1_vec+linker_symbol_intensity_vec+intensity2_vec]
        fdtaout.write('\t'.join(map(str,onesample))+'\n')

        # 数据增强，交换alpha和beta的顺序
        X.append(seq2_vec+linker_symbol_vec+seq1_vec)
        Y.append(intensity2_vec+linker_symbol_intensity_vec+intensity1_vec)
        L.append(l1-1+l2-1+1)
        T.append(title+'2')

        PT.append(cur_pt)
        L1.append(l2-1)
        L2.append(l1-1)
        S1.append(linksite2)
        S2.append(linksite1)

        onesample=[title+'2',cur_pt,l1-1+l2-1+1,l2-1,l1-1,linksite2,linksite1,seq2_vec+linker_symbol_vec+seq1_vec,intensity2_vec+linker_symbol_intensity_vec+intensity1_vec]
        fdtaout.write('\t'.join(map(str,onesample))+'\n')

        # if len(X) >= 10000: # small dataset for debug!!!!!!!!!!!!!!!!
        #     break

    fdtaout.close()

    fpklout=open(path_match_formatted_pkl,'wb')
    pickle.dump([T,PT,L,L1,L2,S1,S2,X,Y],fpklout,protocol=4)
    fpklout.close()

    print('collected %d samples'%len(T))


if __name__ == "__main__":

    print('runing main...')

    # 如果有命令行参数的话
    if len(sys.argv) == 5:
        print('有命令行参数')
        print('参数个数为:', len(sys.argv), '个参数。')
        print('参数列表:', str(sys.argv))
        path_data_home,usage,consider,str_train_num=sys.argv[1:]
        print('path_data_home=%s'%path_data_home)
        print('usage=%s'%usage)
        print('consider=%s'%consider)
        print('str_train_num=%s'%str_train_num)
        consider=int(consider.strip())
        consider_xlink_ion = True if consider==1 else False
        print('consider_xlink_ion=%d'%consider_xlink_ion)
    else:
        print('无命令行参数，或参数个数不等于3')
        path_data_home=r'/data/zlchen/pDeepXL/data/PXD019926/DSS/HEK293'
        # usage='_train'
        # usage='_test'
        usage='_val'
        # usage=''
        consider_xlink_ion = True
        str_train_num=''


    str_xlion='1-yes-xlink' if consider_xlink_ion else '2-no-xlink'
    path_match_raw_info_pkl = r'%s/pLink2_match_info_filtered%s%s.pkl'%(path_data_home,usage,str_train_num)
    path_match_formatted_dta = r'%s/pLink2_filtered-%s%s%s.dta'%(path_data_home,str_xlion,usage,str_train_num)
    path_match_formatted_pkl = r'%s/pLink2_filtered-%s%s%s.pkl'%(path_data_home,str_xlion,usage,str_train_num)

    ConvertpLink2ToTensor(path_match_raw_info_pkl, path_match_formatted_dta, path_match_formatted_pkl, consider_xlink_ion)