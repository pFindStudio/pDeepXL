import sys
sys.path.append("..")
import utils
import mass_util
import os
from concurrent.futures import ThreadPoolExecutor, wait, ALL_COMPLETED, FIRST_COMPLETED, ProcessPoolExecutor
import configparser
import pickle

# 读取pFind3过滤后的PSM，进行肽谱匹配
# 对于匹配比较好的PSM，输出匹配到的b/y离子强度


# 如果有命令行参数的话
if len(sys.argv) == 6:
    print('有命令行参数')
    print('参数个数为:', len(sys.argv), '个参数。')
    print('参数列表:', str(sys.argv))
    path_data_home,instrument=sys.argv[1],sys.argv[2]
    NCE_low,NCE_medium,NCE_high=list(map(float,sys.argv[3:]))
    print('path_data_home=%s'%path_data_home)
    print('instrument=%s'%instrument)
    print('NCE_low=%f,NCE_medium=%f,NCE_high=%f'%(NCE_low,NCE_medium,NCE_high))
else:
    print('无命令行参数，或参数个数不等于6')

    path_data_home = r'/data/zlchen/pDeepXL/data/PXD019926/DSSO/8PM'
    # 如果pf2文件夹内有同名的csv文件，则读取该csv文件决定仪器类型和每张ms2的能量
    instrument = 'Lumos'
    # 目前只支持单能量或三能量
    NCE_low = 0.0
    NCE_medium = 30.0
    NCE_high = 0.0


path_pFind3_id_folder = r'%s/pFind3_id_psm'%path_data_home
path_pf2_folder = r'%s/pf2'%path_data_home
path_match_raw_info_txt = r'%s/pFind3_data/pFind3_match_info.txt'%path_data_home
path_match_raw_info_pkl = r'%s/pFind3_data/pFind3_match_info.pkl'%path_data_home


config = configparser.ConfigParser()
config.read('../config.ini')
good_mods=set(config['DEFAULT']['valid_mods'].split(','))
print('good mods: ', str(good_mods))

allpsms=[]
path_ids=os.listdir(path_pFind3_id_folder)
for pid in path_ids:
    cur_psms = utils.load_pfind3_filtered(r'%s/%s'%(path_pFind3_id_folder,pid))
    print('f=%s,len=%d'%(pid,len(cur_psms)))
    allpsms.extend(cur_psms)

print('allpsms=%d'%len(allpsms))


def run(path_pf2):
    pid = os.getpid()
    rawname = os.path.basename(path_pf2)[:-10]
    print('pid=%s,reading pf2=%s'%(pid, rawname))
    pf2title, mpSpec = utils.load_pf2(path_pf2)

    subinstrument = instrument
    prefix_path = os.path.splitext(path_pf2)[0][:-6]
    instrument_summary_path = r'%s.sum.csv'%prefix_path
    if os.path.exists(instrument_summary_path):
        subinstrument = utils.read_instrument_name(instrument_summary_path)
        print('pid=%s,pf2=%s,subinstrument=%s'%(pid, rawname, subinstrument))

    mpMS2Energy={}
    energy_info_path = r'%s.csv'%prefix_path
    if os.path.exists(energy_info_path):
        mpMS2Energy = utils.read_ms2_energy(energy_info_path)
        print('pid=%s,pf2=%s,loaded own ms2 energy info'%(pid, rawname))

    print('pid=%s,matching psm'%(pid))
    ans = []

    nn=len(allpsms)
    batchsize=int(nn/10)

    for mm,psm in enumerate(allpsms):
        if mm%batchsize==0:
            print('pid=%s,progress=%d/%d'%(pid,mm,nn))
            
        title,scan,prec_charge,exp_mh,seq,mods=psm
        curraw=title.split('.')[0]
        if curraw != rawname or prec_charge < 2:
            continue
        
        if not utils.is_mod_valid(mods): # 不考虑特殊修饰
            continue

        ion_mzss=mass_util.calfragmass4regular(seq,mods)
        ion_charges=(1,2,1,2)
        ion_names=('b1','b2','y1','y2')
        vmints=[]

        spec = mpSpec[title]
        mic=0
        for ion_mzs, ion_charge, ion_name in zip(ion_mzss, ion_charges, ion_names):
            if prec_charge == 2 and ion_charge == 2: # 2+母离子只匹配1+碎片离子
                vmints.append([0.0]*len(ion_mzs))
            else:
                cur_mint=utils.matchbatch(spec,ion_mzs,ion_charge)
                vmints.append(cur_mint)
                mic+=sum([1 if m >0.0 else 0 for m in cur_mint])

        if mic < len(seq): # 要求匹配谱峰数不小于肽段长度
            continue
        
        cur_max_int=max([max(i) for i in vmints])
        vmints_norm=[[i/cur_max_int for i in j] for j in vmints]

        for i in range(12): # 设置xlink、clv-long、clv-short匹配强度全0
            vmints_norm.append([0.0]*len(seq))

        subNCE_low, subNCE_medium, subNCE_high = NCE_low, NCE_medium, NCE_high

        if len(mpMS2Energy) != 0:
            if scan in mpMS2Energy:
                subNCE_low, subNCE_medium, subNCE_high=mpMS2Energy[scan]
            else:
                continue # 有能量文件，但这个scan不在该能量文件内，说明该scan的碎裂不是hcd
        
        # 没有能量文件，则用默认手工设定的能量
        
        ans.append([title,scan,prec_charge,seq,mods,subinstrument,subNCE_low, subNCE_medium, subNCE_high,vmints_norm])

        # for debug!!!!!!!!!!!!!!!!
        # if len(ans) >= 10:
        #     break

    print('pid=%s,done'%(pid))
    return ans
    

if __name__ == "__main__":
    print('runing main...')

    executor = ProcessPoolExecutor(max_workers=30)
    processes = []
    files=os.listdir(path_pf2_folder)
    
    for f in files:
        fname,fext=os.path.splitext(f)
        if fext=='.pf2':
            path_pf2 = r'%s/%s'%(path_pf2_folder,f)
            processes.append(executor.submit(run, path_pf2))
    
    executor.shutdown(wait=True)
    print("main done.")
    
    merged_ans=[]
    for p in processes:
        merged_ans.extend(p.result())
    
    header=['title','scan','charge','seq','mods','instrument', 'NCE_low', 'NCE_medium', 'NCE_high','matched_linear-b1b2y1y2|xlink-b1b2y1y2|clv-long-b1b2y1y2|clv-short-b1b2y1y2']
    fout=open(path_match_raw_info_txt,'w')
    fout.write('\t'.join(header)+'\n')
    
    for psm in merged_ans:
        fout.write('\t'.join(map(str,psm))+'\n')
    fout.close()
    
    fout=open(path_match_raw_info_pkl,'wb')
    pickle.dump(merged_ans,fout,protocol=4)
    fout.close()
