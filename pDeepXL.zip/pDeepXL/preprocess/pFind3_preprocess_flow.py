# pFind3 预处理全流程外壳

import os
import time

#############################################################################################
# 1. 将pFind3鉴定结果进行肽谱匹配，提取出mic > pep_len的PSM，并输出匹配离子强度
# leiker-ecoli有重名raw，单独处理


path_data_homes=[r'/data/zlchen/pDeepXL/data/PXD017620',
                 r'/data/zlchen/pDeepXL/data/PXD016554/DSS/B_subtilis',
                 r'/data/zlchen/pDeepXL/data/PXD016554/DSS/B_cereus',
                 r'/data/zlchen/pDeepXL/data/PXD019926/DSS/HEK293',
                 r'/data/zlchen/pDeepXL/data/PXD017695',
                 r'/data/zlchen/pDeepXL/data/PXD014675',
                 r'/data/zlchen/pDeepXL/data/lili',
                 r'/data/zlchen/pDeepXL/data/PXD019926/DSSO/HEK293',
                 r'/data/zlchen/pDeepXL/data/PXD017711',
                 r'/data/zlchen/pDeepXL/data/PXD012546',
                 r'/data/zlchen/pDeepXL/data/PXD001468',
                 r'/data/zlchen/pDeepXL/data/PXD001250',
                 r'/data/zlchen/pDeepXL/data/PXD014877',
                 r'/data/zlchen/pDeepXL/data/PXD004732/3xHCD',
                 r'/data/zlchen/pDeepXL/data/PXD009384/MEL',
                 r'/data/zlchen/pDeepXL/data/PXD008252']

instruments=['Fusion','QEHFX','QEHFX','Lumos','Lumos','Lumos','QE','Lumos','Lumos','QEPlus','QE','QEHF','QEHFX','Lumos','QEPlus','Fusion']
NCE_lows=[0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 21.0, 18.0, 27.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0]
NCE_mediums=[30.0, 30.0, 30.0, 30.0, 28.0, 28.0, 28.0, 27.0, 24.0, 30.0, 25.0, 27.0, 27.0, 30.0, 27.0, 28.0]
NCE_highs=[0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 33.0, 30.0, 33.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0]

# path_py='pFind3_to_txt.py'
# for fid,(phome, inst, nce_low, nce_medium, nce_high) in enumerate(zip(path_data_homes, instruments, NCE_lows, NCE_mediums, NCE_highs)):
#     # if fid == 0 or fid == 9 or fid == 13: # 这几个数据集太大了，进程数太多导致内存爆炸，后续调低进程数重跑了
#     if fid == 1:
#         localtime = time.asctime( time.localtime(time.time()) )
#         print ("开始时间 :", localtime)
#         start = time.time()

#         os.system('echo %d folder begin'%fid)
#         os.system('python %s %s %s %f %f %f'%(path_py, phome, inst, nce_low, nce_medium, nce_high))
#         os.system('echo %d folder end'%fid)

#         localtime = time.asctime( time.localtime(time.time()) )
#         print ("结束时间 :", localtime)
#         end = time.time()
#         print('run time=%f s'%(end-start))

#         os.system('echo ----------------------------------------------')

#############################################################################################





#############################################################################################
# 2. 将pFind3鉴定结果进行肽谱匹配，提取出mic > pep_len的PSM，并输出匹配离子强度

# leiker-ecoli有重名raw，单独处理

# path_data_homes=[r'/data/zlchen/pDeepXL/data/Leiker_elife/5.E.coli_lysates/enri0121_undigested_by_RNase',
#                   r'/data/zlchen/pDeepXL/data/Leiker_elife/5.E.coli_lysates/enri0228',
#                   r'/data/zlchen/pDeepXL/data/Leiker_elife/5.E.coli_lysates/enri0302',
#                   r'/data/zlchen/pDeepXL/data/Leiker_elife/5.E.coli_lysates/ribofree/frac/150821',
#                   r'/data/zlchen/pDeepXL/data/Leiker_elife/5.E.coli_lysates/ribofree/frac/150830'
#                   ]

# instruments=['QE']*len(path_data_homes)
# NCE_lows=[0.0]*len(path_data_homes)
# NCE_mediums=[27.0]*len(path_data_homes)
# NCE_highs=[0.0]*len(path_data_homes)

# path_py='pFind3_to_txt.py'
# for fid,(phome, inst, nce_low, nce_medium, nce_high) in enumerate(zip(path_data_homes, instruments, NCE_lows, NCE_mediums, NCE_highs)):
#     os.system('echo %d folder begin'%fid)
#     os.system('python %s %s %s %f %f %f'%(path_py, phome, inst, nce_low, nce_medium, nce_high))
#     os.system('echo %d folder end'%fid)
#     os.system('echo ----------------------------------------------')

#############################################################################################




#############################################################################################
# 3. 重命名ecoli-leiker每个子数据集的raw名称，使得spectrum title unique

# path_data_homes=[r'/data/zlchen/pDeepXL/data/Leiker_elife/5.E.coli_lysates/enri0121_undigested_by_RNase',
#                   r'/data/zlchen/pDeepXL/data/Leiker_elife/5.E.coli_lysates/enri0228',
#                   r'/data/zlchen/pDeepXL/data/Leiker_elife/5.E.coli_lysates/enri0302',
#                   r'/data/zlchen/pDeepXL/data/Leiker_elife/5.E.coli_lysates/ribofree/frac/150821',
#                   r'/data/zlchen/pDeepXL/data/Leiker_elife/5.E.coli_lysates/ribofree/frac/150830'
#                   ]
# raw_names=['ecoli_enri0121','ecoli_enri0228','ecoli_enri0302','ecoli_frac_150821','ecoli_frac_150830']

# path_py='rename_leiker_sp_title.py'
# engine='pFind3'
# for path_folder,rawname in zip(path_data_homes,raw_names):
#     os.system('echo rename %s begin'%path_folder)
#     os.system('python %s %s %s %s'%(path_py, path_folder, rawname, engine))
#     os.system('echo rename %s end'%path_folder)
#     os.system('echo ----------------------------------------------')

#############################################################################################



#############################################################################################
# 4. 合并ecoli-leiker的txt

# path_data_homes=[r'/data/zlchen/pDeepXL/data/Leiker_elife/5.E.coli_lysates/enri0121_undigested_by_RNase',
#                   r'/data/zlchen/pDeepXL/data/Leiker_elife/5.E.coli_lysates/enri0228',
#                   r'/data/zlchen/pDeepXL/data/Leiker_elife/5.E.coli_lysates/enri0302',
#                   r'/data/zlchen/pDeepXL/data/Leiker_elife/5.E.coli_lysates/ribofree/frac/150821',
#                   r'/data/zlchen/pDeepXL/data/Leiker_elife/5.E.coli_lysates/ribofree/frac/150830'
#                   ]

# path_py='merge_txt.py' # 可能需要删除该merge_txt.py的path_txt和path_pkl路径中的_filtered
# engine='pFind3'
# concat_folders=' '.join(path_data_homes)
# pfinaltxt=r'/data/zlchen/pDeepXL/data/Leiker_elife/5.E.coli_lysates/pFind3_data/%s_match_info.txt'%(engine)
# pfinalpkl=r'/data/zlchen/pDeepXL/data/Leiker_elife/5.E.coli_lysates/pFind3_data/%s_match_info.pkl'%(engine)
# os.system('echo merge all begin')
# os.system('python %s %s "" %s %s %s'%(path_py, engine, pfinaltxt, pfinalpkl, concat_folders))
# os.system('echo merge all end')
# os.system('echo ----------------------------------------------')

#############################################################################################


# 后续操作可以把ecoli-leiker数据集和其他数据集放到一起批量处理了
path_data_homes=[r'/data/zlchen/pDeepXL/data/PXD017620',
                 r'/data/zlchen/pDeepXL/data/PXD016554/DSS/B_subtilis',
                 r'/data/zlchen/pDeepXL/data/PXD016554/DSS/B_cereus',
                 r'/data/zlchen/pDeepXL/data/PXD019926/DSS/HEK293',
                 r'/data/zlchen/pDeepXL/data/PXD017695',
                 r'/data/zlchen/pDeepXL/data/PXD014675',
                 r'/data/zlchen/pDeepXL/data/lili',
                 r'/data/zlchen/pDeepXL/data/Leiker_elife/5.E.coli_lysates',
                 r'/data/zlchen/pDeepXL/data/PXD019926/DSSO/HEK293',
                 r'/data/zlchen/pDeepXL/data/PXD017711',
                 r'/data/zlchen/pDeepXL/data/PXD012546',
                 r'/data/zlchen/pDeepXL/data/PXD001468',
                 r'/data/zlchen/pDeepXL/data/PXD001250',
                 r'/data/zlchen/pDeepXL/data/PXD014877',
                 r'/data/zlchen/pDeepXL/data/PXD004732/3xHCD',
                 r'/data/zlchen/pDeepXL/data/PXD009384/MEL',
                 r'/data/zlchen/pDeepXL/data/PXD008252']

#############################################################################################
# 5. 使用电荷、长度进行过滤

# path_py='filter_txt.py'
# engine='pFind3'
# for fid,phome in enumerate(path_data_homes):
#     os.system('echo %d folder begin'%fid)
#     os.system('python %s %s %s'%(path_py, phome, engine))
#     os.system('echo %d folder end'%fid)
#     os.system('echo ----------------------------------------------')

#############################################################################################



#############################################################################################
# 6. 对每个数据集，以母离子为单位，划分训练集、验证集、测试集，比例是train:val:test=6:2:2
# 每个母离子最多采样MAX_NUM_SPEC张谱图，既减小了数据量，又避免了数据分布过于不均衡
# 对于PT数据（PXD004732），数据集太大，划分比例是train:val:test=3:1:6

# path_py='split_train_set_txt.py'
# engine='pFind3'
# for fid,phome in enumerate(path_data_homes):
#     os.system('echo %d folder begin'%fid)
#     os.system('python %s %s %s'%(path_py, phome, engine))
#     os.system('echo %d folder end'%fid)
#     os.system('echo ----------------------------------------------')

#############################################################################################



#############################################################################################
# 7. 合并所有数据集的训练集、验证集、测试集

# path_py='merge_txt.py' # 可能需要添加该py的path_txt和path_pkl路径中的_filtered
# engine='pFind3'
# usages=['_train','_test','_val']
# concat_folders=' '.join(path_data_homes)
# for usage in usages:
#     pfinaltxt=r'/data/zlchen/pDeepXL/data/pFind3_data/%s_match_info_filtered%s.txt'%(engine,usage)
#     pfinalpkl=r'/data/zlchen/pDeepXL/data/pFind3_data/%s_match_info_filtered%s.pkl'%(engine,usage)
#     os.system('echo merge %s begin'%usage)
#     os.system('python %s %s %s %s %s %s'%(path_py, engine, usage, pfinaltxt, pfinalpkl, concat_folders))
#     os.system('echo merge %s end'%usage)
#     os.system('echo ----------------------------------------------')

#############################################################################################



#############################################################################################
# 8. 把匹配txt信息转换为网络输入dta格式

path_py='pFind3_to_dta.py'
path_data_home=r'/data/zlchen/pDeepXL/data/PXD004732/3xHCD'
usages=['_train','_test','_val']
for usage in usages:
    os.system('echo convert %s begin'%usage)
    os.system('python %s %s %s'%(path_py, path_data_home, usage))
    os.system('echo convert %s end'%usage)
    os.system('echo ----------------------------------------------')

#############################################################################################