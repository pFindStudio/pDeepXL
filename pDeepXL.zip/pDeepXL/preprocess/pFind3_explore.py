import sys
sys.path.append("..")
import os
import pickle
import matplotlib.pyplot as plt
import pandas as pd

path_data_home = r'/data/zlchen/pDeepXL/data/PXD008550/HumanFOMix_BS3'
path_match_raw_info_txt = r'%s/data/pFind3_match_info.txt'%path_data_home


df = pd.read_csv(path_match_raw_info_txt, sep='\t')
df['length'] = df.apply(lambda row: len(row['seq']), axis=1)

print(df.columns)
print(df['charge'].value_counts())
print(df['length'].value_counts())