#! /bin/sh


cd /data/zlchen/pDeepXL/code/pDeepXL/preprocess

python /data/zlchen/pDeepXL/code/pDeepXL/preprocess/pFind3_to_txt1.py
python /data/zlchen/pDeepXL/code/pDeepXL/preprocess/pFind3_to_txt2.py
python /data/zlchen/pDeepXL/code/pDeepXL/preprocess/pFind3_to_txt3.py
# python /data/zlchen/pDeepXL/code/pDeepXL/preprocess/pFind3_to_txt4.py
# python /data/zlchen/pDeepXL/code/pDeepXL/preprocess/pFind3_to_txt5.py
# python /data/zlchen/pDeepXL/code/pDeepXL/preprocess/pFind3_to_txt6.py
# python /data/zlchen/pDeepXL/code/pDeepXL/preprocess/pFind3_to_txt7.py
# python /data/zlchen/pDeepXL/code/pDeepXL/preprocess/pFind3_to_txt8.py


# python /data/zlchen/pDeepXL/code/pDeepXL/preprocess/pFind3_to_dta1.py
# python /data/zlchen/pDeepXL/code/pDeepXL/preprocess/pFind3_to_dta2.py
# python /data/zlchen/pDeepXL/code/pDeepXL/preprocess/pFind3_to_dta3.py
# python /data/zlchen/pDeepXL/code/pDeepXL/preprocess/pFind3_to_dta4.py
# python /data/zlchen/pDeepXL/code/pDeepXL/preprocess/pFind3_to_dta5.py
# python /data/zlchen/pDeepXL/code/pDeepXL/preprocess/pFind3_to_dta6.py
# python /data/zlchen/pDeepXL/code/pDeepXL/preprocess/pFind3_to_dta7.py
# python /data/zlchen/pDeepXL/code/pDeepXL/preprocess/pFind3_to_dta8.py